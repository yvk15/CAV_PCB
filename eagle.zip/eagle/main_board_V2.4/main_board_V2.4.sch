<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.3.1">
<drawing>
<settings>
<setting alwaysvectorfont="yes"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="1" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="Route15" color="4" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="24" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="9" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="1" fill="9" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="no" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="5" fill="1" visible="yes" active="yes"/>
<layer number="100" name="help" color="7" fill="1" visible="yes" active="yes"/>
<layer number="101" name="DOC" color="7" fill="1" visible="yes" active="yes"/>
<layer number="102" name="bot_pads" color="7" fill="1" visible="yes" active="yes"/>
<layer number="103" name="tMap" color="7" fill="1" visible="no" active="yes"/>
<layer number="104" name="S_DOKU" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="no" active="yes"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="no" active="yes"/>
<layer number="107" name="Crop" color="7" fill="1" visible="no" active="yes"/>
<layer number="108" name="tplace-old" color="10" fill="1" visible="yes" active="yes"/>
<layer number="109" name="ref-old" color="11" fill="1" visible="yes" active="yes"/>
<layer number="110" name="fp0" color="7" fill="1" visible="yes" active="yes"/>
<layer number="111" name="LPC17xx" color="7" fill="1" visible="yes" active="yes"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="113" name="IDFDebug" color="7" fill="1" visible="yes" active="yes"/>
<layer number="114" name="Badge_Outline" color="7" fill="1" visible="no" active="yes"/>
<layer number="115" name="ReferenceISLANDS" color="7" fill="1" visible="no" active="yes"/>
<layer number="116" name="Patch_BOT" color="7" fill="1" visible="yes" active="yes"/>
<layer number="117" name="mPads" color="7" fill="1" visible="yes" active="yes"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="yes" active="yes"/>
<layer number="119" name="mUnrouted" color="7" fill="1" visible="yes" active="yes"/>
<layer number="120" name="mDimension" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="no" active="yes"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="129" name="Mask" color="7" fill="1" visible="yes" active="yes"/>
<layer number="130" name="mbStop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="133" name="mtFinish" color="7" fill="1" visible="yes" active="yes"/>
<layer number="134" name="mbFinish" color="7" fill="1" visible="yes" active="yes"/>
<layer number="135" name="mtGlue" color="7" fill="1" visible="yes" active="yes"/>
<layer number="136" name="mbGlue" color="7" fill="1" visible="yes" active="yes"/>
<layer number="137" name="mtTest" color="7" fill="1" visible="yes" active="yes"/>
<layer number="138" name="mbTest" color="7" fill="1" visible="yes" active="yes"/>
<layer number="139" name="mtKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="140" name="mbKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="141" name="mtRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="142" name="mbRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="143" name="mvRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="no" active="yes"/>
<layer number="145" name="mHoles" color="7" fill="1" visible="yes" active="yes"/>
<layer number="146" name="mMilling" color="7" fill="1" visible="yes" active="yes"/>
<layer number="147" name="mMeasures" color="7" fill="1" visible="yes" active="yes"/>
<layer number="148" name="mDocument" color="7" fill="1" visible="yes" active="yes"/>
<layer number="149" name="mReference" color="7" fill="1" visible="yes" active="yes"/>
<layer number="150" name="Notes" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="no" active="yes"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="153" name="FabDoc1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="154" name="FabDoc2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="155" name="FabDoc3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="191" name="mNets" color="7" fill="1" visible="yes" active="yes"/>
<layer number="192" name="mBusses" color="7" fill="1" visible="yes" active="yes"/>
<layer number="193" name="mPins" color="7" fill="1" visible="yes" active="yes"/>
<layer number="194" name="mSymbols" color="7" fill="1" visible="yes" active="yes"/>
<layer number="195" name="mNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="196" name="mValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="yes" active="yes"/>
<layer number="201" name="201bmp" color="2" fill="10" visible="yes" active="yes"/>
<layer number="202" name="202bmp" color="3" fill="10" visible="no" active="yes"/>
<layer number="203" name="203bmp" color="4" fill="10" visible="no" active="yes"/>
<layer number="204" name="204bmp" color="5" fill="10" visible="no" active="yes"/>
<layer number="205" name="205bmp" color="6" fill="10" visible="no" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="10" visible="no" active="yes"/>
<layer number="207" name="207bmp" color="8" fill="10" visible="no" active="yes"/>
<layer number="208" name="208bmp" color="9" fill="10" visible="no" active="yes"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="217" name="217bmp" color="18" fill="1" visible="no" active="no"/>
<layer number="218" name="218bmp" color="19" fill="1" visible="no" active="no"/>
<layer number="219" name="219bmp" color="20" fill="1" visible="no" active="no"/>
<layer number="220" name="220bmp" color="21" fill="1" visible="no" active="no"/>
<layer number="221" name="221bmp" color="22" fill="1" visible="no" active="no"/>
<layer number="222" name="222bmp" color="23" fill="1" visible="no" active="no"/>
<layer number="223" name="223bmp" color="24" fill="1" visible="no" active="no"/>
<layer number="224" name="224bmp" color="25" fill="1" visible="no" active="no"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="227" name="227bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="228" name="228bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="229" name="229bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="230" name="230bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="231" name="231bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="232" name="Eagle3D_PG2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="233" name="Eagle3D_PG3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="248" name="Housing" color="7" fill="1" visible="yes" active="yes"/>
<layer number="249" name="Edge" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="254" name="OrgLBR" color="7" fill="1" visible="yes" active="yes"/>
<layer number="255" name="HELP" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="supply1" urn="urn:adsk.eagle:library:371">
<description>&lt;b&gt;Supply Symbols&lt;/b&gt;&lt;p&gt;
 GND, VCC, 0V, +5V, -5V, etc.&lt;p&gt;
 Please keep in mind, that these devices are necessary for the
 automatic wiring of the supply signals.&lt;p&gt;
 The pin name defined in the symbol is identical to the net which is to be wired automatically.&lt;p&gt;
 In this library the device names are the same as the pin names of the symbols, therefore the correct signal names appear next to the supply symbols in the schematic.&lt;p&gt;
 &lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
</packages>
<symbols>
<symbol name="GND" urn="urn:adsk.eagle:symbol:26925/1" library_version="1">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="+5V" urn="urn:adsk.eagle:symbol:26929/1" library_version="1">
<wire x1="1.27" y1="-1.905" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="-1.905" width="0.254" layer="94"/>
<text x="-2.54" y="-5.08" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="+5V" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
<symbol name="+3V3" urn="urn:adsk.eagle:symbol:26950/1" library_version="1">
<wire x1="1.27" y1="-1.905" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="-1.905" width="0.254" layer="94"/>
<text x="-2.54" y="-5.08" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="+3V3" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" urn="urn:adsk.eagle:component:26954/1" prefix="GND" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+5V" urn="urn:adsk.eagle:component:26963/1" prefix="P+" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="+5V" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+3V3" urn="urn:adsk.eagle:component:26981/1" prefix="+3V3" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="G$1" symbol="+3V3" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="embedded" urn="urn:adsk.eagle:library:10681391">
<packages>
<package name="SOT223" urn="urn:adsk.eagle:footprint:10681908/2" library_version="64">
<description>&lt;b&gt;SOT-223&lt;/b&gt;</description>
<wire x1="3.2766" y1="1.651" x2="3.2766" y2="-1.651" width="0.2032" layer="21"/>
<wire x1="3.2766" y1="-1.651" x2="-3.2766" y2="-1.651" width="0.2032" layer="21"/>
<wire x1="-3.2766" y1="-1.651" x2="-3.2766" y2="1.651" width="0.2032" layer="21"/>
<wire x1="-3.2766" y1="1.651" x2="3.2766" y2="1.651" width="0.2032" layer="21"/>
<smd name="1" x="-2.3114" y="-3.0988" dx="1.2192" dy="2.2352" layer="1"/>
<smd name="2" x="0" y="-3.0988" dx="1.2192" dy="2.2352" layer="1"/>
<smd name="3" x="2.3114" y="-3.0988" dx="1.2192" dy="2.2352" layer="1"/>
<smd name="4" x="0" y="3.099" dx="3.6" dy="2.2" layer="1"/>
<text x="-0.8255" y="4.5085" size="0.8128" layer="25">&gt;NAME</text>
<text x="-1.0795" y="-0.1905" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6002" y1="1.8034" x2="1.6002" y2="3.6576" layer="51"/>
<rectangle x1="-0.4318" y1="-3.6576" x2="0.4318" y2="-1.8034" layer="51"/>
<rectangle x1="-2.7432" y1="-3.6576" x2="-1.8796" y2="-1.8034" layer="51"/>
<rectangle x1="1.8796" y1="-3.6576" x2="2.7432" y2="-1.8034" layer="51"/>
<rectangle x1="-1.6002" y1="1.8034" x2="1.6002" y2="3.6576" layer="51"/>
<rectangle x1="-0.4318" y1="-3.6576" x2="0.4318" y2="-1.8034" layer="51"/>
<rectangle x1="-2.7432" y1="-3.6576" x2="-1.8796" y2="-1.8034" layer="51"/>
<rectangle x1="1.8796" y1="-3.6576" x2="2.7432" y2="-1.8034" layer="51"/>
</package>
<package name="R0201" urn="urn:adsk.eagle:footprint:10736678/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt; chip&lt;p&gt;
Source: http://www.vishay.com/docs/20008/dcrcw.pdf</description>
<smd name="1" x="-0.255" y="0" dx="0.28" dy="0.43" layer="1"/>
<smd name="2" x="0.255" y="0" dx="0.28" dy="0.43" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.3" y1="-0.15" x2="-0.15" y2="0.15" layer="51"/>
<rectangle x1="0.15" y1="-0.15" x2="0.3" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="-0.15" x2="0.15" y2="0.15" layer="21"/>
<wire x1="-0.508" y1="-0.3048" x2="-0.508" y2="0.3048" width="0.0508" layer="39"/>
<wire x1="-0.508" y1="0.3048" x2="0.508" y2="0.3048" width="0.0508" layer="39"/>
<wire x1="0.508" y1="0.3048" x2="0.508" y2="-0.3048" width="0.0508" layer="39"/>
<wire x1="0.508" y1="-0.3048" x2="-0.508" y2="-0.3048" width="0.0508" layer="39"/>
</package>
<package name="R0402" urn="urn:adsk.eagle:footprint:10736677/1" library_version="41">
<description>&lt;b&gt;Chip RESISTOR 0402 EIA (1005 Metric)&lt;/b&gt;</description>
<wire x1="-0.245" y1="0.224" x2="0.245" y2="0.224" width="0.1524" layer="51"/>
<wire x1="0.245" y1="-0.224" x2="-0.245" y2="-0.224" width="0.1524" layer="51"/>
<wire x1="-0.9492" y1="0.483" x2="0.9492" y2="0.483" width="0.0508" layer="39"/>
<wire x1="0.9492" y1="0.483" x2="0.9492" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="0.9492" y1="-0.483" x2="-0.9492" y2="-0.483" width="0.0508" layer="39"/>
<wire x1="-0.9492" y1="-0.483" x2="-0.9492" y2="0.483" width="0.0508" layer="39"/>
<smd name="1" x="-0.5" y="0" dx="0.6" dy="0.7" layer="1"/>
<smd name="2" x="0.5" y="0" dx="0.6" dy="0.7" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.2951" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.2951" layer="51"/>
<rectangle x1="-0.1999" y1="-0.35" x2="0.1999" y2="0.35" layer="35"/>
</package>
<package name="R0603" urn="urn:adsk.eagle:footprint:10736679/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="-0.432" y1="-0.356" x2="0.432" y2="-0.356" width="0.1524" layer="51"/>
<wire x1="0.432" y1="0.356" x2="-0.432" y2="0.356" width="0.1524" layer="51"/>
<wire x1="-1.473" y1="0.6782" x2="1.473" y2="0.6782" width="0.0508" layer="39"/>
<wire x1="1.473" y1="0.6782" x2="1.473" y2="-0.6782" width="0.0508" layer="39"/>
<wire x1="1.473" y1="-0.6782" x2="-1.473" y2="-0.6782" width="0.0508" layer="39"/>
<wire x1="-1.473" y1="-0.6782" x2="-1.473" y2="0.6782" width="0.0508" layer="39"/>
<smd name="1" x="-0.85" y="0" dx="1" dy="1.1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1" dy="1.1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="0.4318" y1="-0.4318" x2="0.8382" y2="0.4318" layer="51"/>
<rectangle x1="-0.8382" y1="-0.4318" x2="-0.4318" y2="0.4318" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="R0805" urn="urn:adsk.eagle:footprint:10736687/2" library_version="63">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;&lt;p&gt;</description>
<wire x1="-0.41" y1="0.635" x2="0.41" y2="0.635" width="0.1524" layer="51"/>
<wire x1="-0.41" y1="-0.635" x2="0.41" y2="-0.635" width="0.1524" layer="51"/>
<wire x1="-1.8714" y1="0.983" x2="1.8714" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.8714" y1="0.983" x2="1.8714" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.8714" y1="-0.983" x2="-1.8714" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.8714" y1="-0.983" x2="-1.8714" y2="0.983" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="0.8636" x2="0.9652" y2="0.8636" width="0.0762" layer="21"/>
<wire x1="0.9652" y1="-0.8636" x2="-0.9652" y2="-0.8636" width="0.0762" layer="21"/>
<smd name="1" x="-0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="0.4064" y1="-0.6985" x2="1.0564" y2="0.7015" layer="51"/>
<rectangle x1="-1.0668" y1="-0.6985" x2="-0.4168" y2="0.7015" layer="51"/>
<rectangle x1="-0.1999" y1="-0.5001" x2="0.1999" y2="0.5001" layer="35"/>
</package>
<package name="R1206" urn="urn:adsk.eagle:footprint:10736682/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="0.9525" y1="-0.8128" x2="-0.9652" y2="-0.8128" width="0.1524" layer="51"/>
<wire x1="0.9525" y1="0.8128" x2="-0.9652" y2="0.8128" width="0.1524" layer="51"/>
<wire x1="-2.4222" y1="1.0846" x2="2.4222" y2="1.0846" width="0.0508" layer="39"/>
<wire x1="2.4222" y1="1.0846" x2="2.4222" y2="-1.0846" width="0.0508" layer="39"/>
<wire x1="2.4222" y1="-1.0846" x2="-2.4222" y2="-1.0846" width="0.0508" layer="39"/>
<wire x1="-2.4222" y1="-1.0846" x2="-2.4222" y2="1.0846" width="0.0508" layer="39"/>
<smd name="2" x="1.422" y="0" dx="1.6" dy="1.803" layer="1"/>
<smd name="1" x="-1.422" y="0" dx="1.6" dy="1.803" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6891" y1="-0.8763" x2="-0.9525" y2="0.8763" layer="51"/>
<rectangle x1="0.9525" y1="-0.8763" x2="1.6891" y2="0.8763" layer="51"/>
<rectangle x1="-0.3" y1="-0.7" x2="0.3" y2="0.7" layer="35"/>
</package>
<package name="R1210" urn="urn:adsk.eagle:footprint:10736681/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="-0.913" y1="1.219" x2="0.939" y2="1.219" width="0.1524" layer="51"/>
<wire x1="-0.913" y1="-1.219" x2="0.939" y2="-1.219" width="0.1524" layer="51"/>
<wire x1="-2.473" y1="1.5338" x2="2.473" y2="1.5338" width="0.0508" layer="39"/>
<wire x1="2.473" y1="1.5338" x2="2.473" y2="-1.5338" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-1.5338" x2="-2.473" y2="-1.5338" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-1.5338" x2="-2.473" y2="1.5338" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-2.54" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.651" y1="-1.3081" x2="-0.9009" y2="1.2918" layer="51"/>
<rectangle x1="0.9144" y1="-1.3081" x2="1.6645" y2="1.2918" layer="51"/>
<rectangle x1="-0.3" y1="-0.8999" x2="0.3" y2="0.8999" layer="35"/>
</package>
<package name="R2012" urn="urn:adsk.eagle:footprint:10736680/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="-0.41" y1="0.635" x2="0.41" y2="0.635" width="0.1524" layer="51"/>
<wire x1="-0.41" y1="-0.635" x2="0.41" y2="-0.635" width="0.1524" layer="51"/>
<wire x1="-1.719" y1="0.983" x2="1.719" y2="0.983" width="0.0508" layer="39"/>
<wire x1="1.719" y1="0.983" x2="1.719" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="1.719" y1="-0.983" x2="-1.719" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-1.719" y1="-0.983" x2="-1.719" y2="0.983" width="0.0508" layer="39"/>
<smd name="1" x="-0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="0.4064" y1="-0.6985" x2="1.0564" y2="0.7015" layer="51"/>
<rectangle x1="-1.0668" y1="-0.6985" x2="-0.4168" y2="0.7015" layer="51"/>
<rectangle x1="-0.1001" y1="-0.5999" x2="0.1001" y2="0.5999" layer="35"/>
</package>
<package name="R2512" urn="urn:adsk.eagle:footprint:23055/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="-2.362" y1="1.473" x2="2.387" y2="1.473" width="0.1524" layer="51"/>
<wire x1="-2.362" y1="-1.473" x2="2.387" y2="-1.473" width="0.1524" layer="51"/>
<wire x1="-3.973" y1="1.983" x2="3.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="3.973" y1="1.983" x2="3.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="3.973" y1="-1.983" x2="-3.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-3.973" y1="-1.983" x2="-3.973" y2="1.983" width="0.0508" layer="39"/>
<smd name="1" x="-2.8" y="0" dx="1.8" dy="3.2" layer="1"/>
<smd name="2" x="2.8" y="0" dx="1.8" dy="3.2" layer="1"/>
<text x="-2.54" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-3.2004" y1="-1.5494" x2="-2.3505" y2="1.5507" layer="51"/>
<rectangle x1="2.3622" y1="-1.5494" x2="3.2121" y2="1.5507" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="R3216" urn="urn:adsk.eagle:footprint:10736683/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="-0.913" y1="0.8" x2="0.888" y2="0.8" width="0.1524" layer="51"/>
<wire x1="-0.913" y1="-0.8" x2="0.888" y2="-0.8" width="0.1524" layer="51"/>
<wire x1="-2.4222" y1="1.0846" x2="2.4222" y2="1.0846" width="0.0508" layer="39"/>
<wire x1="2.4222" y1="1.0846" x2="2.4222" y2="-1.0846" width="0.0508" layer="39"/>
<wire x1="2.4222" y1="-1.0846" x2="-2.4222" y2="-1.0846" width="0.0508" layer="39"/>
<wire x1="-2.4222" y1="-1.0846" x2="-2.4222" y2="1.0846" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.905" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.651" y1="-0.8763" x2="-0.9009" y2="0.8738" layer="51"/>
<rectangle x1="0.889" y1="-0.8763" x2="1.6391" y2="0.8738" layer="51"/>
<rectangle x1="-0.3" y1="-0.7" x2="0.3" y2="0.7" layer="35"/>
</package>
<package name="R3225" urn="urn:adsk.eagle:footprint:10736685/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="-0.913" y1="1.219" x2="0.939" y2="1.219" width="0.1524" layer="51"/>
<wire x1="-0.913" y1="-1.219" x2="0.939" y2="-1.219" width="0.1524" layer="51"/>
<wire x1="-2.473" y1="1.5846" x2="2.473" y2="1.5846" width="0.0508" layer="39"/>
<wire x1="2.473" y1="1.5846" x2="2.473" y2="-1.5846" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-1.5846" x2="-2.473" y2="-1.5846" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-1.5846" x2="-2.473" y2="1.5846" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-2.54" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.651" y1="-1.3081" x2="-0.9009" y2="1.2918" layer="51"/>
<rectangle x1="0.9144" y1="-1.3081" x2="1.6645" y2="1.2918" layer="51"/>
<rectangle x1="-0.3" y1="-1" x2="0.3" y2="1" layer="35"/>
</package>
<package name="R4527" urn="urn:adsk.eagle:footprint:10736686/1" library_version="41">
<description>&lt;b&gt;Package 4527&lt;/b&gt;&lt;p&gt;
Source: http://www.vishay.com/docs/31059/wsrhigh.pdf</description>
<wire x1="-5.675" y1="-3.375" x2="5.65" y2="-3.375" width="0.2032" layer="21"/>
<wire x1="5.65" y1="-3.375" x2="5.65" y2="3.375" width="0.2032" layer="51"/>
<wire x1="5.65" y1="3.375" x2="-5.675" y2="3.375" width="0.2032" layer="21"/>
<wire x1="-5.675" y1="3.375" x2="-5.675" y2="-3.375" width="0.2032" layer="51"/>
<wire x1="-6.8072" y1="-3.7592" x2="-6.8072" y2="3.7592" width="0.0508" layer="39"/>
<wire x1="-6.8072" y1="3.7592" x2="6.8072" y2="3.7592" width="0.0508" layer="39"/>
<wire x1="6.8072" y1="3.7592" x2="6.8072" y2="-3.7592" width="0.0508" layer="39"/>
<wire x1="6.8072" y1="-3.7592" x2="-6.8072" y2="-3.7592" width="0.0508" layer="39"/>
<smd name="1" x="-4.575" y="0" dx="3.94" dy="5.84" layer="1"/>
<smd name="2" x="4.575" y="0" dx="3.94" dy="5.84" layer="1"/>
<text x="-5.715" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-5.715" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="R5025" urn="urn:adsk.eagle:footprint:10736684/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<wire x1="-1.662" y1="1.245" x2="1.662" y2="1.245" width="0.1524" layer="51"/>
<wire x1="-1.637" y1="-1.245" x2="1.687" y2="-1.245" width="0.1524" layer="51"/>
<wire x1="-3.473" y1="1.5846" x2="3.473" y2="1.5846" width="0.0508" layer="39"/>
<wire x1="3.473" y1="1.5846" x2="3.473" y2="-1.5846" width="0.0508" layer="39"/>
<wire x1="3.473" y1="-1.5846" x2="-3.473" y2="-1.5846" width="0.0508" layer="39"/>
<wire x1="-3.473" y1="-1.5846" x2="-3.473" y2="1.5846" width="0.0508" layer="39"/>
<smd name="1" x="-2.2" y="0" dx="1.8" dy="2.7" layer="1"/>
<smd name="2" x="2.2" y="0" dx="1.8" dy="2.7" layer="1"/>
<text x="-3.175" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.175" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.4892" y1="-1.3208" x2="-1.6393" y2="1.3292" layer="51"/>
<rectangle x1="1.651" y1="-1.3208" x2="2.5009" y2="1.3292" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="R6332" urn="urn:adsk.eagle:footprint:23063/1" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;&lt;p&gt;
Source: http://download.siliconexpert.com/pdfs/2005/02/24/Semi_Ap/2/VSH/Resistor/dcrcwfre.pdf</description>
<wire x1="-2.362" y1="1.473" x2="2.387" y2="1.473" width="0.1524" layer="51"/>
<wire x1="-2.362" y1="-1.473" x2="2.387" y2="-1.473" width="0.1524" layer="51"/>
<wire x1="-3.973" y1="1.983" x2="3.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="3.973" y1="1.983" x2="3.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="3.973" y1="-1.983" x2="-3.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-3.973" y1="-1.983" x2="-3.973" y2="1.983" width="0.0508" layer="39"/>
<smd name="1" x="-3.1" y="0" dx="1" dy="3.2" layer="1"/>
<smd name="2" x="3.1" y="0" dx="1" dy="3.2" layer="1"/>
<text x="-2.54" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-3.2004" y1="-1.5494" x2="-2.3505" y2="1.5507" layer="51"/>
<rectangle x1="2.3622" y1="-1.5494" x2="3.2121" y2="1.5507" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="WSL_10G" urn="urn:adsk.eagle:footprint:10681396/3" library_version="71">
<description>&lt;b&gt;CONNECTOR&lt;/b&gt;&lt;p&gt;
series 057 contact pc board low profile headers&lt;p&gt;
straight</description>
<wire x1="-1.9" y1="-3.32" x2="-1.9" y2="-4.03" width="0.2032" layer="21"/>
<wire x1="1.9" y1="-3.32" x2="1.9" y2="-4.03" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="-4.1" x2="-10.21" y2="4.1" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="-4.1" x2="10.21" y2="-4.1" width="0.2032" layer="21"/>
<wire x1="10.21" y1="-4.1" x2="10.21" y2="4.1" width="0.2032" layer="21"/>
<wire x1="10.21" y1="4.1" x2="-10.21" y2="4.1" width="0.2032" layer="21"/>
<wire x1="-9.41" y1="-3.3" x2="-9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="-9.41" y1="3.3" x2="9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="9.41" y1="3.3" x2="9.41" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="9.41" y1="-3.3" x2="1.9" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="-1.9" y1="-3.3" x2="-9.41" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="4.1" x2="-9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="-4.1" x2="-9.41" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="10.21" y1="4.1" x2="9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="9.41" y1="-3.3" x2="10.21" y2="-4.1" width="0.2032" layer="21"/>
<pad name="1" x="-5.08" y="-1.27" drill="1" shape="octagon"/>
<pad name="2" x="-5.08" y="1.27" drill="1" shape="octagon"/>
<pad name="3" x="-2.54" y="-1.27" drill="1" shape="octagon"/>
<pad name="4" x="-2.54" y="1.27" drill="1" shape="octagon"/>
<pad name="5" x="0" y="-1.27" drill="1" shape="octagon"/>
<pad name="6" x="0" y="1.27" drill="1" shape="octagon"/>
<pad name="7" x="2.54" y="-1.27" drill="1" shape="octagon"/>
<pad name="8" x="2.54" y="1.27" drill="1" shape="octagon"/>
<pad name="9" x="5.08" y="-1.27" drill="1" shape="octagon"/>
<pad name="10" x="5.08" y="1.27" drill="1" shape="octagon"/>
<text x="2.56" y="-6.88" size="1.778" layer="25">&gt;NAME</text>
<text x="-8.35" y="4.55" size="1.778" layer="27">&gt;VALUE</text>
<circle x="-6.858" y="-2.286" radius="0.254" width="0.508" layer="21"/>
</package>
<package name="2X05" urn="urn:adsk.eagle:footprint:22358/1" library_version="41">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-6.35" y1="-1.905" x2="-5.715" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="-2.54" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.905" x2="-3.175" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-2.54" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="-0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-2.54" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-2.54" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="-1.905" x2="-6.35" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="1.905" x2="-5.715" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="2.54" x2="-4.445" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="2.54" x2="-3.81" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.905" x2="-3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="2.54" x2="-1.905" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="2.54" x2="-1.27" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="1.905" x2="-0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="2.54" x2="0.635" y2="2.54" width="0.1524" layer="21"/>
<wire x1="0.635" y1="2.54" x2="1.27" y2="1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="1.905" x2="1.905" y2="2.54" width="0.1524" layer="21"/>
<wire x1="1.905" y1="2.54" x2="3.175" y2="2.54" width="0.1524" layer="21"/>
<wire x1="3.175" y1="2.54" x2="3.81" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.905" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="1.905" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="1.905" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="1.905" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-2.54" x2="3.175" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-2.54" x2="0.635" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-2.54" x2="-1.905" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="-2.54" x2="-4.445" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="4.445" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="5.715" y1="-2.54" x2="6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="1.905" x2="4.445" y2="2.54" width="0.1524" layer="21"/>
<wire x1="4.445" y1="2.54" x2="5.715" y2="2.54" width="0.1524" layer="21"/>
<wire x1="5.715" y1="2.54" x2="6.35" y2="1.905" width="0.1524" layer="21"/>
<wire x1="6.35" y1="1.905" x2="6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="4.445" y1="-2.54" x2="5.715" y2="-2.54" width="0.1524" layer="21"/>
<pad name="1" x="-5.08" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="2" x="-5.08" y="1.27" drill="1.016" shape="octagon"/>
<pad name="3" x="-2.54" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="4" x="-2.54" y="1.27" drill="1.016" shape="octagon"/>
<pad name="5" x="0" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="6" x="0" y="1.27" drill="1.016" shape="octagon"/>
<pad name="7" x="2.54" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="8" x="2.54" y="1.27" drill="1.016" shape="octagon"/>
<pad name="9" x="5.08" y="-1.27" drill="1.016" shape="octagon"/>
<pad name="10" x="5.08" y="1.27" drill="1.016" shape="octagon"/>
<text x="-6.35" y="3.175" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-6.35" y="-4.445" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-5.334" y1="-1.524" x2="-4.826" y2="-1.016" layer="51"/>
<rectangle x1="-5.334" y1="1.016" x2="-4.826" y2="1.524" layer="51"/>
<rectangle x1="-2.794" y1="1.016" x2="-2.286" y2="1.524" layer="51"/>
<rectangle x1="-2.794" y1="-1.524" x2="-2.286" y2="-1.016" layer="51"/>
<rectangle x1="-0.254" y1="1.016" x2="0.254" y2="1.524" layer="51"/>
<rectangle x1="-0.254" y1="-1.524" x2="0.254" y2="-1.016" layer="51"/>
<rectangle x1="2.286" y1="1.016" x2="2.794" y2="1.524" layer="51"/>
<rectangle x1="2.286" y1="-1.524" x2="2.794" y2="-1.016" layer="51"/>
<rectangle x1="4.826" y1="1.016" x2="5.334" y2="1.524" layer="51"/>
<rectangle x1="4.826" y1="-1.524" x2="5.334" y2="-1.016" layer="51"/>
</package>
<package name="2X05/90" urn="urn:adsk.eagle:footprint:22359/1" library_version="41">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-6.35" y1="-1.905" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.905" x2="-3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="0.635" x2="-6.35" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="0.635" x2="-6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="6.985" x2="-5.08" y2="1.27" width="0.762" layer="21"/>
<wire x1="-3.81" y1="-1.905" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="6.985" x2="-2.54" y2="1.27" width="0.762" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.27" y1="0.635" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="6.985" x2="0" y2="1.27" width="0.762" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="3.81" y1="0.635" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="6.985" x2="2.54" y2="1.27" width="0.762" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="6.35" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="6.35" y1="-1.905" x2="6.35" y2="0.635" width="0.1524" layer="21"/>
<wire x1="6.35" y1="0.635" x2="3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="6.985" x2="5.08" y2="1.27" width="0.762" layer="21"/>
<pad name="2" x="-5.08" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="4" x="-2.54" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="6" x="0" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="8" x="2.54" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="10" x="5.08" y="-3.81" drill="1.016" shape="octagon"/>
<pad name="1" x="-5.08" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="3" x="-2.54" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="5" x="0" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="7" x="2.54" y="-6.35" drill="1.016" shape="octagon"/>
<pad name="9" x="5.08" y="-6.35" drill="1.016" shape="octagon"/>
<text x="-6.985" y="-3.81" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="8.255" y="-3.81" size="1.27" layer="27" rot="R90">&gt;VALUE</text>
<rectangle x1="-5.461" y1="0.635" x2="-4.699" y2="1.143" layer="21"/>
<rectangle x1="-2.921" y1="0.635" x2="-2.159" y2="1.143" layer="21"/>
<rectangle x1="-0.381" y1="0.635" x2="0.381" y2="1.143" layer="21"/>
<rectangle x1="2.159" y1="0.635" x2="2.921" y2="1.143" layer="21"/>
<rectangle x1="4.699" y1="0.635" x2="5.461" y2="1.143" layer="21"/>
<rectangle x1="-5.461" y1="-2.921" x2="-4.699" y2="-1.905" layer="21"/>
<rectangle x1="-2.921" y1="-2.921" x2="-2.159" y2="-1.905" layer="21"/>
<rectangle x1="-5.461" y1="-5.461" x2="-4.699" y2="-4.699" layer="21"/>
<rectangle x1="-5.461" y1="-4.699" x2="-4.699" y2="-2.921" layer="51"/>
<rectangle x1="-2.921" y1="-4.699" x2="-2.159" y2="-2.921" layer="51"/>
<rectangle x1="-2.921" y1="-5.461" x2="-2.159" y2="-4.699" layer="21"/>
<rectangle x1="-0.381" y1="-2.921" x2="0.381" y2="-1.905" layer="21"/>
<rectangle x1="2.159" y1="-2.921" x2="2.921" y2="-1.905" layer="21"/>
<rectangle x1="-0.381" y1="-5.461" x2="0.381" y2="-4.699" layer="21"/>
<rectangle x1="-0.381" y1="-4.699" x2="0.381" y2="-2.921" layer="51"/>
<rectangle x1="2.159" y1="-4.699" x2="2.921" y2="-2.921" layer="51"/>
<rectangle x1="2.159" y1="-5.461" x2="2.921" y2="-4.699" layer="21"/>
<rectangle x1="4.699" y1="-2.921" x2="5.461" y2="-1.905" layer="21"/>
<rectangle x1="4.699" y1="-5.461" x2="5.461" y2="-4.699" layer="21"/>
<rectangle x1="4.699" y1="-4.699" x2="5.461" y2="-2.921" layer="51"/>
</package>
<package name="2X05/JTAG" urn="urn:adsk.eagle:footprint:10681397/2" library_version="41">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-5.849" y1="-2.986" x2="-5.149" y2="-4.056" width="0.2032" layer="21"/>
<wire x1="-5.149" y1="-4.056" x2="-4.449" y2="-2.986" width="0.2032" layer="21"/>
<wire x1="-4.449" y1="-2.986" x2="-5.849" y2="-2.986" width="0.2032" layer="21"/>
<wire x1="1.27" y1="-4.064" x2="-1.27" y2="-4.064" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-2.54" x2="-6.731" y2="-2.54" width="0.2032" layer="21"/>
<wire x1="-6.731" y1="-2.54" x2="-6.731" y2="2.54" width="0.2032" layer="21"/>
<wire x1="-6.731" y1="2.54" x2="6.731" y2="2.54" width="0.2032" layer="21"/>
<wire x1="6.731" y1="2.54" x2="6.731" y2="-2.54" width="0.2032" layer="21"/>
<wire x1="6.731" y1="-2.54" x2="1.27" y2="-2.54" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-2.54" x2="-1.27" y2="-4.064" width="0.2032" layer="21"/>
<wire x1="1.27" y1="-2.54" x2="1.27" y2="-4.064" width="0.2032" layer="21"/>
<pad name="1" x="-5.08" y="-1.27" drill="1" shape="octagon"/>
<pad name="2" x="-5.08" y="1.27" drill="1" shape="octagon"/>
<pad name="3" x="-2.54" y="-1.27" drill="1" shape="octagon"/>
<pad name="4" x="-2.54" y="1.27" drill="1" shape="octagon"/>
<pad name="5" x="0" y="-1.27" drill="1" shape="octagon"/>
<pad name="6" x="0" y="1.27" drill="1" shape="octagon"/>
<pad name="7" x="2.54" y="-1.27" drill="1" shape="octagon"/>
<pad name="8" x="2.54" y="1.27" drill="1" shape="octagon"/>
<pad name="9" x="5.08" y="-1.27" drill="1" shape="octagon"/>
<pad name="10" x="5.08" y="1.27" drill="1" shape="octagon"/>
<text x="2.032" y="-4.064" size="1.016" layer="25">&gt;NAME</text>
<text x="-6.382" y="3.07" size="1.016" layer="27">&gt;VALUE</text>
</package>
<package name="RN04" urn="urn:adsk.eagle:footprint:10682941/1" library_version="42">
<description>&lt;b&gt;RESISTOR NETWORK&lt;/b&gt;</description>
<wire x1="6.35" y1="-1.27" x2="6.35" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="1.27" x2="-6.35" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="-1.27" x2="-5.715" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="1.27" x2="-5.715" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.27" x2="-4.445" y2="0.635" width="0.1524" layer="21"/>
<wire x1="6.35" y1="1.27" x2="-3.81" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.27" x2="-4.445" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-6.35" y1="-1.27" x2="-3.81" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.27" x2="-6.35" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.27" x2="6.35" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-5.6896" y1="0.6096" x2="-4.4704" y2="-0.6096" width="0.1524" layer="51"/>
<wire x1="-5.6896" y1="-0.6096" x2="-4.4704" y2="0.6096" width="0.1524" layer="51"/>
<pad name="1" x="-5.08" y="0" drill="0.8128" shape="long" rot="R90"/>
<pad name="2" x="-2.54" y="0" drill="0.8128" shape="long" rot="R90"/>
<pad name="3" x="0" y="0" drill="0.8128" shape="long" rot="R90"/>
<pad name="4" x="2.54" y="0" drill="0.8128" shape="long" rot="R90"/>
<pad name="5" x="5.08" y="0" drill="0.8128" shape="long" rot="R90"/>
<text x="-3.81" y="-2.921" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
<text x="-3.81" y="1.651" size="1.27" layer="25" ratio="10">&gt;NAME</text>
</package>
<package name="TQFP100" urn="urn:adsk.eagle:footprint:10682026/1" library_version="42">
<description>&lt;b&gt;100-lead Thin Quad Flat Pack Package Outline&lt;/b&gt;</description>
<wire x1="-7" y1="6.25" x2="-6.25" y2="7" width="0.254" layer="21"/>
<wire x1="-6.25" y1="7" x2="6.75" y2="7" width="0.254" layer="21"/>
<wire x1="6.75" y1="7" x2="7" y2="6.75" width="0.254" layer="21"/>
<wire x1="7" y1="6.75" x2="7" y2="-6.75" width="0.254" layer="21"/>
<wire x1="7" y1="-6.75" x2="6.75" y2="-7" width="0.254" layer="21"/>
<wire x1="6.75" y1="-7" x2="-6.75" y2="-7" width="0.254" layer="21"/>
<wire x1="-6.75" y1="-7" x2="-7" y2="-6.75" width="0.254" layer="21"/>
<wire x1="-7" y1="-6.75" x2="-7" y2="6.25" width="0.254" layer="21"/>
<wire x1="0.39" y1="0.9299" x2="-0.0099" y2="1.3298" width="0.1016" layer="51" curve="90"/>
<circle x="-6" y="6" radius="0.2499" width="0.254" layer="21"/>
<circle x="3.59" y="-0.7699" radius="0.4999" width="0.1016" layer="51"/>
<smd name="1" x="-8" y="6" dx="1.5" dy="0.35" layer="1"/>
<smd name="2" x="-8" y="5.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="3" x="-8" y="5" dx="1.5" dy="0.35" layer="1"/>
<smd name="4" x="-8" y="4.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="5" x="-8" y="4" dx="1.5" dy="0.35" layer="1"/>
<smd name="6" x="-8" y="3.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="7" x="-8" y="3" dx="1.5" dy="0.35" layer="1"/>
<smd name="8" x="-8" y="2.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="9" x="-8" y="2" dx="1.5" dy="0.35" layer="1"/>
<smd name="10" x="-8" y="1.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="11" x="-8" y="1" dx="1.5" dy="0.35" layer="1"/>
<smd name="12" x="-8" y="0.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="13" x="-8" y="0" dx="1.5" dy="0.35" layer="1"/>
<smd name="14" x="-8" y="-0.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="15" x="-8" y="-1" dx="1.5" dy="0.35" layer="1"/>
<smd name="16" x="-8" y="-1.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="17" x="-8" y="-2" dx="1.5" dy="0.35" layer="1"/>
<smd name="18" x="-8" y="-2.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="19" x="-8" y="-3" dx="1.5" dy="0.35" layer="1"/>
<smd name="20" x="-8" y="-3.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="21" x="-8" y="-4" dx="1.5" dy="0.35" layer="1"/>
<smd name="22" x="-8" y="-4.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="23" x="-8" y="-5" dx="1.5" dy="0.35" layer="1"/>
<smd name="24" x="-8" y="-5.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="25" x="-8" y="-6" dx="1.5" dy="0.35" layer="1"/>
<smd name="26" x="-6" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="27" x="-5.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="28" x="-5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="29" x="-4.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="30" x="-4" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="31" x="-3.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="32" x="-3" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="33" x="-2.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="34" x="-2" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="35" x="-1.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="36" x="-1" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="37" x="-0.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="38" x="0" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="39" x="0.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="40" x="1" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="41" x="1.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="42" x="2" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="43" x="2.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="44" x="3" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="45" x="3.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="46" x="4" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="47" x="4.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="48" x="5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="49" x="5.5" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="50" x="6" y="-8" dx="0.35" dy="1.5" layer="1"/>
<smd name="51" x="8" y="-6" dx="1.5" dy="0.35" layer="1"/>
<smd name="52" x="8" y="-5.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="53" x="8" y="-5" dx="1.5" dy="0.35" layer="1"/>
<smd name="54" x="8" y="-4.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="55" x="8" y="-4" dx="1.5" dy="0.35" layer="1"/>
<smd name="56" x="8" y="-3.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="57" x="8" y="-3" dx="1.5" dy="0.35" layer="1"/>
<smd name="58" x="8" y="-2.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="59" x="8" y="-2" dx="1.5" dy="0.35" layer="1"/>
<smd name="60" x="8" y="-1.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="61" x="8" y="-1" dx="1.5" dy="0.35" layer="1"/>
<smd name="62" x="8" y="-0.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="63" x="8" y="0" dx="1.5" dy="0.35" layer="1"/>
<smd name="64" x="8" y="0.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="65" x="8" y="1" dx="1.5" dy="0.35" layer="1"/>
<smd name="66" x="8" y="1.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="67" x="8" y="2" dx="1.5" dy="0.35" layer="1"/>
<smd name="68" x="8" y="2.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="69" x="8" y="3" dx="1.5" dy="0.35" layer="1"/>
<smd name="70" x="8" y="3.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="71" x="8" y="4" dx="1.5" dy="0.35" layer="1"/>
<smd name="72" x="8" y="4.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="73" x="8" y="5" dx="1.5" dy="0.35" layer="1"/>
<smd name="74" x="8" y="5.5" dx="1.5" dy="0.35" layer="1"/>
<smd name="75" x="8" y="6" dx="1.5" dy="0.35" layer="1"/>
<smd name="76" x="6" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="77" x="5.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="78" x="5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="79" x="4.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="80" x="4" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="81" x="3.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="82" x="3" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="83" x="2.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="84" x="2" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="85" x="1.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="86" x="1" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="87" x="0.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="88" x="0" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="89" x="-0.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="90" x="-1" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="91" x="-1.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="92" x="-2" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="93" x="-2.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="94" x="-3" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="95" x="-3.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="96" x="-4" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="97" x="-4.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="98" x="-5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="99" x="-5.5" y="8" dx="0.35" dy="1.5" layer="1"/>
<smd name="100" x="-6" y="8" dx="0.35" dy="1.5" layer="1"/>
<text x="-6.395" y="9.2451" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.1801" y="2.8001" size="1.27" layer="27">&gt;VALUE</text>
<text x="-2.81" y="-2.4801" size="0.8128" layer="51">TQFP 100</text>
<text x="3.3899" y="-1.0701" size="0.6096" layer="51" ratio="15">R</text>
<rectangle x1="-8.1999" y1="5.8499" x2="-7.15" y2="6.1502" layer="51"/>
<rectangle x1="-8.1999" y1="5.35" x2="-7.15" y2="5.6501" layer="51"/>
<rectangle x1="-8.1999" y1="4.8499" x2="-7.15" y2="5.1502" layer="51"/>
<rectangle x1="-8.1999" y1="4.35" x2="-7.15" y2="4.6501" layer="51"/>
<rectangle x1="-8.1999" y1="3.8499" x2="-7.15" y2="4.1502" layer="51"/>
<rectangle x1="-8.1999" y1="3.35" x2="-7.15" y2="3.6501" layer="51"/>
<rectangle x1="-8.1999" y1="2.8499" x2="-7.15" y2="3.1502" layer="51"/>
<rectangle x1="-8.1999" y1="2.35" x2="-7.15" y2="2.6501" layer="51"/>
<rectangle x1="-8.1999" y1="1.8499" x2="-7.15" y2="2.1502" layer="51"/>
<rectangle x1="-8.1999" y1="1.35" x2="-7.15" y2="1.6501" layer="51"/>
<rectangle x1="-8.1999" y1="0.8499" x2="-7.15" y2="1.1502" layer="51"/>
<rectangle x1="-8.1999" y1="0.35" x2="-7.15" y2="0.6501" layer="51"/>
<rectangle x1="-8.1999" y1="-0.1501" x2="-7.15" y2="0.1502" layer="51"/>
<rectangle x1="-8.1999" y1="-0.65" x2="-7.15" y2="-0.3499" layer="51"/>
<rectangle x1="-8.1999" y1="-1.1501" x2="-7.15" y2="-0.8498" layer="51"/>
<rectangle x1="-8.1999" y1="-1.65" x2="-7.15" y2="-1.3499" layer="51"/>
<rectangle x1="-8.1999" y1="-2.1501" x2="-7.15" y2="-1.8498" layer="51"/>
<rectangle x1="-8.1999" y1="-2.65" x2="-7.15" y2="-2.3499" layer="51"/>
<rectangle x1="-8.1999" y1="-3.1501" x2="-7.15" y2="-2.8498" layer="51"/>
<rectangle x1="-8.1999" y1="-3.65" x2="-7.15" y2="-3.3499" layer="51"/>
<rectangle x1="-8.1999" y1="-4.1501" x2="-7.15" y2="-3.8498" layer="51"/>
<rectangle x1="-8.1999" y1="-4.65" x2="-7.15" y2="-4.3499" layer="51"/>
<rectangle x1="-8.1999" y1="-5.1501" x2="-7.15" y2="-4.8498" layer="51"/>
<rectangle x1="-8.1999" y1="-5.65" x2="-7.15" y2="-5.3499" layer="51"/>
<rectangle x1="-8.1999" y1="-6.1501" x2="-7.15" y2="-5.8498" layer="51"/>
<rectangle x1="-6.1501" y1="-8.1999" x2="-5.8498" y2="-7.15" layer="51"/>
<rectangle x1="-5.65" y1="-8.1999" x2="-5.3499" y2="-7.15" layer="51"/>
<rectangle x1="-5.1501" y1="-8.1999" x2="-4.8498" y2="-7.15" layer="51"/>
<rectangle x1="-4.65" y1="-8.1999" x2="-4.3499" y2="-7.15" layer="51"/>
<rectangle x1="-4.1501" y1="-8.1999" x2="-3.8498" y2="-7.15" layer="51"/>
<rectangle x1="-3.65" y1="-8.1999" x2="-3.3499" y2="-7.15" layer="51"/>
<rectangle x1="-3.1501" y1="-8.1999" x2="-2.8498" y2="-7.15" layer="51"/>
<rectangle x1="-2.65" y1="-8.1999" x2="-2.3499" y2="-7.15" layer="51"/>
<rectangle x1="-2.1501" y1="-8.1999" x2="-1.8498" y2="-7.15" layer="51"/>
<rectangle x1="-1.65" y1="-8.1999" x2="-1.3499" y2="-7.15" layer="51"/>
<rectangle x1="-1.1501" y1="-8.1999" x2="-0.8498" y2="-7.15" layer="51"/>
<rectangle x1="-0.65" y1="-8.1999" x2="-0.3499" y2="-7.15" layer="51"/>
<rectangle x1="-0.1501" y1="-8.1999" x2="0.1502" y2="-7.15" layer="51"/>
<rectangle x1="0.35" y1="-8.1999" x2="0.6501" y2="-7.15" layer="51"/>
<rectangle x1="0.8499" y1="-8.1999" x2="1.1502" y2="-7.15" layer="51"/>
<rectangle x1="1.35" y1="-8.1999" x2="1.6501" y2="-7.15" layer="51"/>
<rectangle x1="1.8499" y1="-8.1999" x2="2.1502" y2="-7.15" layer="51"/>
<rectangle x1="2.35" y1="-8.1999" x2="2.6501" y2="-7.15" layer="51"/>
<rectangle x1="2.8499" y1="-8.1999" x2="3.1502" y2="-7.15" layer="51"/>
<rectangle x1="3.35" y1="-8.1999" x2="3.6501" y2="-7.15" layer="51"/>
<rectangle x1="3.8499" y1="-8.1999" x2="4.1502" y2="-7.15" layer="51"/>
<rectangle x1="4.35" y1="-8.1999" x2="4.6501" y2="-7.15" layer="51"/>
<rectangle x1="4.8499" y1="-8.1999" x2="5.1502" y2="-7.15" layer="51"/>
<rectangle x1="5.35" y1="-8.1999" x2="5.6501" y2="-7.15" layer="51"/>
<rectangle x1="5.8499" y1="-8.1999" x2="6.1502" y2="-7.15" layer="51"/>
<rectangle x1="7.1501" y1="-6.1501" x2="8.2" y2="-5.8498" layer="51"/>
<rectangle x1="7.1501" y1="-5.65" x2="8.2" y2="-5.3499" layer="51"/>
<rectangle x1="7.1501" y1="-5.1501" x2="8.2" y2="-4.8498" layer="51"/>
<rectangle x1="7.1501" y1="-4.65" x2="8.2" y2="-4.3499" layer="51"/>
<rectangle x1="7.1501" y1="-4.1501" x2="8.2" y2="-3.8498" layer="51"/>
<rectangle x1="7.1501" y1="-3.65" x2="8.2" y2="-3.3499" layer="51"/>
<rectangle x1="7.1501" y1="-3.1501" x2="8.2" y2="-2.8498" layer="51"/>
<rectangle x1="7.1501" y1="-2.65" x2="8.2" y2="-2.3499" layer="51"/>
<rectangle x1="7.1501" y1="-2.1501" x2="8.2" y2="-1.8498" layer="51"/>
<rectangle x1="7.1501" y1="-1.65" x2="8.2" y2="-1.3499" layer="51"/>
<rectangle x1="7.1501" y1="-1.1501" x2="8.2" y2="-0.8498" layer="51"/>
<rectangle x1="7.1501" y1="-0.65" x2="8.2" y2="-0.3499" layer="51"/>
<rectangle x1="7.1501" y1="-0.1501" x2="8.2" y2="0.1502" layer="51"/>
<rectangle x1="7.1501" y1="0.35" x2="8.2" y2="0.6501" layer="51"/>
<rectangle x1="7.1501" y1="0.8499" x2="8.2" y2="1.1502" layer="51"/>
<rectangle x1="7.1501" y1="1.35" x2="8.2" y2="1.6501" layer="51"/>
<rectangle x1="7.1501" y1="1.8499" x2="8.2" y2="2.1502" layer="51"/>
<rectangle x1="7.1501" y1="2.35" x2="8.2" y2="2.6501" layer="51"/>
<rectangle x1="7.1501" y1="2.8499" x2="8.2" y2="3.1502" layer="51"/>
<rectangle x1="7.1501" y1="3.35" x2="8.2" y2="3.6501" layer="51"/>
<rectangle x1="7.1501" y1="3.8499" x2="8.2" y2="4.1502" layer="51"/>
<rectangle x1="7.1501" y1="4.35" x2="8.2" y2="4.6501" layer="51"/>
<rectangle x1="7.1501" y1="4.8499" x2="8.2" y2="5.1502" layer="51"/>
<rectangle x1="7.1501" y1="5.35" x2="8.2" y2="5.6501" layer="51"/>
<rectangle x1="7.1501" y1="5.8499" x2="8.2" y2="6.1502" layer="51"/>
<rectangle x1="5.8499" y1="7.1501" x2="6.1502" y2="8.2" layer="51"/>
<rectangle x1="5.35" y1="7.1501" x2="5.6501" y2="8.2" layer="51"/>
<rectangle x1="4.8499" y1="7.1501" x2="5.1502" y2="8.2" layer="51"/>
<rectangle x1="4.35" y1="7.1501" x2="4.6501" y2="8.2" layer="51"/>
<rectangle x1="3.8499" y1="7.1501" x2="4.1502" y2="8.2" layer="51"/>
<rectangle x1="3.35" y1="7.1501" x2="3.6501" y2="8.2" layer="51"/>
<rectangle x1="2.8499" y1="7.1501" x2="3.1502" y2="8.2" layer="51"/>
<rectangle x1="2.35" y1="7.1501" x2="2.6501" y2="8.2" layer="51"/>
<rectangle x1="1.8499" y1="7.1501" x2="2.1502" y2="8.2" layer="51"/>
<rectangle x1="1.35" y1="7.1501" x2="1.6501" y2="8.2" layer="51"/>
<rectangle x1="0.8499" y1="7.1501" x2="1.1502" y2="8.2" layer="51"/>
<rectangle x1="0.35" y1="7.1501" x2="0.6501" y2="8.2" layer="51"/>
<rectangle x1="-0.1501" y1="7.1501" x2="0.1502" y2="8.2" layer="51"/>
<rectangle x1="-0.65" y1="7.1501" x2="-0.3499" y2="8.2" layer="51"/>
<rectangle x1="-1.1501" y1="7.1501" x2="-0.8498" y2="8.2" layer="51"/>
<rectangle x1="-1.65" y1="7.1501" x2="-1.3499" y2="8.2" layer="51"/>
<rectangle x1="-2.1501" y1="7.1501" x2="-1.8498" y2="8.2" layer="51"/>
<rectangle x1="-2.65" y1="7.1501" x2="-2.3499" y2="8.2" layer="51"/>
<rectangle x1="-3.1501" y1="7.1501" x2="-2.8498" y2="8.2" layer="51"/>
<rectangle x1="-3.65" y1="7.1501" x2="-3.3499" y2="8.2" layer="51"/>
<rectangle x1="-4.1501" y1="7.1501" x2="-3.8498" y2="8.2" layer="51"/>
<rectangle x1="-4.65" y1="7.1501" x2="-4.3499" y2="8.2" layer="51"/>
<rectangle x1="-5.1501" y1="7.1501" x2="-4.8498" y2="8.2" layer="51"/>
<rectangle x1="-5.65" y1="7.1501" x2="-5.3499" y2="8.2" layer="51"/>
<rectangle x1="-6.1501" y1="7.1501" x2="-5.8498" y2="8.2" layer="51"/>
<polygon width="0.1" layer="51">
<vertex x="-3.81" y="-0.6701"/>
<vertex x="-2.81" y="1.3299"/>
<vertex x="-2.2101" y="1.3299"/>
<vertex x="-2.2101" y="-0.6701"/>
<vertex x="-2.6101" y="-0.6701"/>
<vertex x="-2.6101" y="0.73"/>
<vertex x="-3.2101" y="-0.4699"/>
<vertex x="-3.0099" y="-0.4699"/>
<vertex x="-3.0099" y="-0.6701"/>
</polygon>
<polygon width="0.1" layer="51">
<vertex x="-2.7099" y="1.6299"/>
<vertex x="-2.51" y="2.03"/>
<vertex x="3.0899" y="2.03"/>
<vertex x="3.0899" y="1.6299"/>
<vertex x="-1.51" y="1.6299"/>
<vertex x="-1.51" y="-0.6701"/>
<vertex x="-1.9101" y="-0.6701"/>
<vertex x="-1.9101" y="1.6299"/>
</polygon>
<polygon width="0.1" layer="51">
<vertex x="-1.2101" y="1.3299"/>
<vertex x="-1.2101" y="-0.6701"/>
<vertex x="-0.81" y="-0.6701"/>
<vertex x="-0.81" y="1.13"/>
<vertex x="-0.6101" y="1.13"/>
<vertex x="-0.6101" y="-0.6701"/>
<vertex x="-0.2101" y="-0.6701"/>
<vertex x="-0.2101" y="1.13"/>
<vertex x="-0.0099" y="1.13"/>
<vertex x="-0.0099" y="-0.6701"/>
<vertex x="0.3899" y="-0.6701"/>
<vertex x="0.3899" y="0.9299"/>
<vertex x="0.2901" y="1.13"/>
<vertex x="0.19" y="1.2301"/>
<vertex x="-0.0099" y="1.3299"/>
</polygon>
<polygon width="0.1" layer="51">
<vertex x="0.6901" y="1.3299"/>
<vertex x="0.6901" y="-0.6701"/>
<vertex x="1.89" y="-0.6701"/>
<vertex x="1.89" y="-0.0701"/>
<vertex x="0.89" y="-0.0701"/>
<vertex x="0.89" y="0.13"/>
<vertex x="1.89" y="0.13"/>
<vertex x="1.89" y="0.5301"/>
<vertex x="0.89" y="0.5301"/>
<vertex x="0.89" y="0.73"/>
<vertex x="1.89" y="0.73"/>
<vertex x="1.89" y="1.3299"/>
</polygon>
<polygon width="0.1" layer="51">
<vertex x="2.19" y="1.3299"/>
<vertex x="2.19" y="-0.6701"/>
<vertex x="2.7899" y="-0.6701"/>
<vertex x="2.9901" y="-0.27"/>
<vertex x="2.59" y="-0.27"/>
<vertex x="2.59" y="1.3299"/>
</polygon>
<polygon width="0.1" layer="51">
<vertex x="-3.81" y="-0.8699"/>
<vertex x="-3.81" y="-1.27"/>
<vertex x="2.49" y="-1.27"/>
<vertex x="2.6901" y="-0.8699"/>
</polygon>
</package>
<package name="SM77H" urn="urn:adsk.eagle:footprint:12177394/1" library_version="77">
<description>&lt;b&gt;3.3V CMOS Clock Oscillator&lt;/b&gt;&lt;p&gt;
Source: www.pletronics.com .. sm77h%203.3v.pdf</description>
<wire x1="-3.4" y1="-2.4" x2="3.4" y2="-2.4" width="0.2032" layer="51"/>
<wire x1="3.4" y1="-2.4" x2="3.4" y2="2.4" width="0.2032" layer="51"/>
<wire x1="3.4" y1="2.4" x2="-3.4" y2="2.4" width="0.2032" layer="51"/>
<wire x1="-3.4" y1="2.4" x2="-3.4" y2="-2.4" width="0.2032" layer="51"/>
<wire x1="-1.368" y1="-2.4" x2="1.368" y2="-2.4" width="0.2032" layer="21"/>
<wire x1="-3.4" y1="0.876" x2="-3.4" y2="-0.876" width="0.2032" layer="21"/>
<wire x1="1.368" y1="2.4" x2="-1.368" y2="2.4" width="0.2032" layer="21"/>
<wire x1="3.4" y1="-0.876" x2="3.4" y2="0.876" width="0.2032" layer="21"/>
<circle x="-2.794" y="-0.762" radius="0.254" width="0" layer="21"/>
<smd name="1" x="-2.5" y="-2.1" dx="2" dy="2" layer="1" rot="R90"/>
<smd name="2" x="2.5" y="-2.1" dx="2" dy="2" layer="1" rot="R90"/>
<smd name="3" x="2.5" y="2.1" dx="2" dy="2" layer="1" rot="R270"/>
<smd name="4" x="-2.5" y="2.1" dx="2" dy="2" layer="1" rot="R270"/>
<text x="-3.81" y="-2.54" size="1.27" layer="25" rot="R90">&gt;NAME</text>
<text x="-2.286" y="-0.508" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="SCREWTERM_4POS_3.5MM" urn="urn:adsk.eagle:footprint:10723823/2" library_version="44">
<description>&lt;b&gt;MKDS 1/ 4-3,5&lt;/b&gt; Printklemme&lt;p&gt;
Nennstrom: 10 A&lt;br&gt;
Bemessungsspannung: 160 V&lt;br&gt;
Raster: 3,5 mm&lt;br&gt;
Polzahl: 4&lt;br&gt;
Montageart: Löten&lt;br&gt;
Anschlussart: Schraubanschluss&lt;br&gt;
Anschlussrichtung vom Leiter zur Platine: 0°&lt;br&gt;
Source: http://eshop.phoenixcontact.com .. 1751264.pdf</description>
<wire x1="-7.25" y1="3.65" x2="7.25" y2="3.65" width="0.1016" layer="21"/>
<wire x1="-7.25" y1="3.65" x2="-7.25" y2="1.9123" width="0.1016" layer="21"/>
<wire x1="7.25" y1="-2.0993" x2="-7.25" y2="-2.0993" width="0.1016" layer="21"/>
<wire x1="7.25" y1="-1.6163" x2="7.25" y2="1.4367" width="0.1016" layer="21"/>
<wire x1="7.25" y1="-2.0993" x2="7.25" y2="-2.911" width="0.1016" layer="21"/>
<wire x1="7.25" y1="-1.6163" x2="7.25" y2="-2.0993" width="0.1016" layer="21"/>
<wire x1="-7.25" y1="1.9123" x2="-7.25" y2="1.4367" width="0.1016" layer="21"/>
<wire x1="7.25" y1="1.4367" x2="7.25" y2="1.9123" width="0.1016" layer="21"/>
<wire x1="-7.25" y1="-1.6163" x2="-7.25" y2="1.4367" width="0.1016" layer="21"/>
<wire x1="7.25" y1="3.65" x2="7.25" y2="1.9123" width="0.1016" layer="21"/>
<wire x1="-7.25" y1="-1.6163" x2="-7.25" y2="-2.0993" width="0.1016" layer="21"/>
<wire x1="-7.25" y1="-2.0993" x2="-7.25" y2="-2.911" width="0.1016" layer="21"/>
<wire x1="-6.456" y1="-0.811" x2="-4.539" y2="1.106" width="0.1016" layer="51"/>
<wire x1="-7.25" y1="-3.65" x2="7.25" y2="-3.65" width="0.1016" layer="21"/>
<wire x1="7.25" y1="-3.35" x2="7.25" y2="-3.65" width="0.1016" layer="21"/>
<wire x1="-7.25" y1="-3.35" x2="-7.25" y2="-3.65" width="0.1016" layer="21"/>
<wire x1="-7.25" y1="-2.911" x2="-7.25" y2="-3.35" width="0.1016" layer="21"/>
<wire x1="7.25" y1="-2.911" x2="7.25" y2="-3.35" width="0.1016" layer="21"/>
<wire x1="-4.044" y1="0.611" x2="-4.05" y2="0.605" width="0.1016" layer="21"/>
<wire x1="-4.05" y1="0.605" x2="-5.961" y2="-1.306" width="0.1016" layer="51"/>
<wire x1="-2.956" y1="-0.811" x2="-1.039" y2="1.106" width="0.1016" layer="51"/>
<wire x1="-0.544" y1="0.611" x2="-0.55" y2="0.605" width="0.1016" layer="21"/>
<wire x1="-0.55" y1="0.605" x2="-2.461" y2="-1.306" width="0.1016" layer="51"/>
<wire x1="0.544" y1="-0.811" x2="2.461" y2="1.106" width="0.1016" layer="51"/>
<wire x1="2.956" y1="0.611" x2="2.95" y2="0.605" width="0.1016" layer="21"/>
<wire x1="2.95" y1="0.605" x2="1.039" y2="-1.306" width="0.1016" layer="51"/>
<wire x1="4.044" y1="-0.811" x2="5.961" y2="1.106" width="0.1016" layer="51"/>
<wire x1="6.456" y1="0.611" x2="6.45" y2="0.605" width="0.1016" layer="21"/>
<wire x1="6.45" y1="0.605" x2="4.539" y2="-1.306" width="0.1016" layer="51"/>
<circle x="-5.25" y="-0.1" radius="1.45" width="0.1016" layer="21"/>
<circle x="-1.75" y="-0.1" radius="1.45" width="0.1016" layer="21"/>
<circle x="1.75" y="-0.1" radius="1.45" width="0.1016" layer="21"/>
<circle x="5.25" y="-0.1" radius="1.45" width="0.1016" layer="21"/>
<pad name="1" x="-5.25" y="-0.1" drill="1.1" diameter="1.7" rot="R90"/>
<pad name="2" x="-1.75" y="-0.1" drill="1.1" diameter="1.7" rot="R90"/>
<pad name="3" x="1.75" y="-0.1" drill="1.1" diameter="1.7" rot="R90"/>
<pad name="4" x="5.25" y="-0.1" drill="1.1" diameter="1.7" rot="R90"/>
<text x="-5.7" y="2.2225" size="1.27" layer="21" font="vector">1</text>
<text x="-2.2075" y="2.2225" size="1.27" layer="21" font="vector">2</text>
<text x="1.285" y="2.2225" size="1.27" layer="21" font="vector">3</text>
<text x="4.7775" y="2.2225" size="1.27" layer="21" font="vector">4</text>
<text x="-7.605" y="-2.8575" size="1.27" layer="25" rot="R90">&gt;NAME</text>
<text x="-0.3025" y="4.1275" size="1.27" layer="27">&gt;VALUE</text>
<polygon width="0.1016" layer="21">
<vertex x="-5.2555" y="-3.2385"/>
<vertex x="-5.7" y="-2.4765"/>
<vertex x="-4.811" y="-2.4765"/>
</polygon>
</package>
<package name="UD-4X5,8_NICHICON" urn="urn:adsk.eagle:footprint:12177395/1" library_version="77">
<description>&lt;b&gt;ALUMINUM ELECTROLYTIC CAPACITORS&lt;/b&gt; UD Series 4 x 5.8 mm&lt;p&gt;
Source: http://products.nichicon.co.jp/en/pdf/XJA043/e-ud.pdf</description>
<wire x1="-2.1" y1="2.1" x2="1.3" y2="2.1" width="0.1016" layer="51"/>
<wire x1="1.3" y1="2.1" x2="2.1" y2="1.3" width="0.1016" layer="51"/>
<wire x1="2.1" y1="1.3" x2="2.1" y2="-1.3" width="0.1016" layer="51"/>
<wire x1="2.1" y1="-1.3" x2="1.3" y2="-2.1" width="0.1016" layer="51"/>
<wire x1="1.3" y1="-2.1" x2="-2.1" y2="-2.1" width="0.1016" layer="51"/>
<wire x1="-2.1" y1="-2.1" x2="-2.1" y2="2.1" width="0.1016" layer="51"/>
<wire x1="-1.75" y1="0.875" x2="1.75" y2="0.875" width="0.1016" layer="21" curve="-126.263848"/>
<wire x1="-2.1" y1="0.9" x2="-2.1" y2="2.1" width="0.1016" layer="21"/>
<wire x1="-2.1" y1="2.1" x2="1.3" y2="2.1" width="0.1016" layer="21"/>
<wire x1="1.3" y1="2.1" x2="2.1" y2="1.3" width="0.1016" layer="21"/>
<wire x1="2.1" y1="-1.3" x2="1.3" y2="-2.1" width="0.1016" layer="21"/>
<wire x1="1.3" y1="-2.1" x2="-2.1" y2="-2.1" width="0.1016" layer="21"/>
<wire x1="-2.1" y1="-2.1" x2="-2.1" y2="-0.9" width="0.1016" layer="21"/>
<wire x1="1.75" y1="-0.875" x2="-1.75" y2="-0.875" width="0.1016" layer="21" curve="-126.263848"/>
<circle x="0" y="0" radius="1.9527" width="0.1016" layer="51"/>
<smd name="-" x="-1.75" y="0" dx="2.5" dy="1.6" layer="1"/>
<smd name="+" x="1.75" y="0" dx="2.5" dy="1.6" layer="1"/>
<text x="-1.905" y="2.54" size="1.016" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.016" layer="27">&gt;VALUE</text>
<polygon width="0.1016" layer="51">
<vertex x="-1.55" y="1.175" curve="72.275472"/>
<vertex x="-1.55" y="-1.175"/>
</polygon>
</package>
<package name="UD-6,3X5,8_NICHICON" urn="urn:adsk.eagle:footprint:12177393/1" library_version="77">
<description>&lt;b&gt;ALUMINUM ELECTROLYTIC CAPACITORS&lt;/b&gt; UD Series 6.3 x 5.8 mm&lt;p&gt;
Source: http://products.nichicon.co.jp/en/pdf/XJA043/e-ud.pdf</description>
<wire x1="-3.25" y1="3.25" x2="2.45" y2="3.25" width="0.1016" layer="51"/>
<wire x1="2.45" y1="3.25" x2="3.25" y2="2.45" width="0.1016" layer="51"/>
<wire x1="3.25" y1="2.45" x2="3.25" y2="-2.45" width="0.1016" layer="51"/>
<wire x1="3.25" y1="-2.45" x2="2.45" y2="-3.25" width="0.1016" layer="51"/>
<wire x1="2.45" y1="-3.25" x2="-3.25" y2="-3.25" width="0.1016" layer="51"/>
<wire x1="-3.25" y1="-3.25" x2="-3.25" y2="3.25" width="0.1016" layer="51"/>
<wire x1="-3" y1="0.775" x2="2.975" y2="0.85" width="0.1016" layer="21" curve="-149.753145"/>
<wire x1="-3.25" y1="0.8" x2="-3.25" y2="3.25" width="0.1016" layer="21"/>
<wire x1="-3.25" y1="3.25" x2="2.45" y2="3.25" width="0.1016" layer="21"/>
<wire x1="2.45" y1="3.25" x2="3.25" y2="2.45" width="0.1016" layer="21"/>
<wire x1="3.25" y1="-2.45" x2="2.45" y2="-3.25" width="0.1016" layer="21"/>
<wire x1="2.45" y1="-3.25" x2="-3.25" y2="-3.25" width="0.1016" layer="21"/>
<wire x1="-3.25" y1="-3.25" x2="-3.25" y2="-0.7" width="0.1016" layer="21"/>
<wire x1="3" y1="-0.775" x2="-2.975" y2="-0.85" width="0.1016" layer="21" curve="-149.753145"/>
<circle x="0" y="0" radius="3.1001" width="0.1016" layer="51"/>
<smd name="-" x="-2.5" y="0" dx="3.2" dy="1.6" layer="1"/>
<smd name="+" x="2.5" y="0" dx="3.2" dy="1.6" layer="1"/>
<text x="-3.175" y="3.81" size="1.016" layer="25">&gt;NAME</text>
<text x="-3.175" y="-4.445" size="1.016" layer="27">&gt;VALUE</text>
<polygon width="0.1016" layer="51">
<vertex x="-2.2" y="2.15" curve="88.581463"/>
<vertex x="-2.2" y="-2.15"/>
</polygon>
</package>
<package name="SO08" urn="urn:adsk.eagle:footprint:10681738/1" library_version="44">
<description>&lt;b&gt;Small Outline Package 8&lt;/b&gt;&lt;br&gt;
NS Package M08A</description>
<wire x1="2.4" y1="1.9" x2="2.4" y2="-1.4" width="0.2032" layer="51"/>
<wire x1="2.4" y1="-1.4" x2="2.4" y2="-1.9" width="0.2032" layer="51"/>
<wire x1="2.4" y1="-1.9" x2="-2.4" y2="-1.9" width="0.2032" layer="51"/>
<wire x1="-2.4" y1="-1.9" x2="-2.4" y2="-1.4" width="0.2032" layer="51"/>
<wire x1="-2.4" y1="-1.4" x2="-2.4" y2="1.9" width="0.2032" layer="51"/>
<wire x1="-2.4" y1="1.9" x2="2.4" y2="1.9" width="0.2032" layer="51"/>
<wire x1="2.4" y1="-1.4" x2="-2.4" y2="-1.4" width="0.2032" layer="51"/>
<smd name="2" x="-0.635" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="7" x="-0.635" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="1" x="-1.905" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="3" x="0.635" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="4" x="1.905" y="-2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="8" x="-1.905" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="6" x="0.635" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<smd name="5" x="1.905" y="2.6" dx="0.6" dy="2.2" layer="1"/>
<text x="-2.667" y="-1.905" size="1.27" layer="25" rot="R90">&gt;NAME</text>
<text x="3.937" y="-1.905" size="1.27" layer="27" rot="R90">&gt;VALUE</text>
<rectangle x1="-2.15" y1="-3.1" x2="-1.66" y2="-2" layer="51"/>
<rectangle x1="-0.88" y1="-3.1" x2="-0.39" y2="-2" layer="51"/>
<rectangle x1="0.39" y1="-3.1" x2="0.88" y2="-2" layer="51"/>
<rectangle x1="1.66" y1="-3.1" x2="2.15" y2="-2" layer="51"/>
<rectangle x1="1.66" y1="2" x2="2.15" y2="3.1" layer="51"/>
<rectangle x1="0.39" y1="2" x2="0.88" y2="3.1" layer="51"/>
<rectangle x1="-0.88" y1="2" x2="-0.39" y2="3.1" layer="51"/>
<rectangle x1="-2.15" y1="2" x2="-1.66" y2="3.1" layer="51"/>
<circle x="-1.905" y="-0.889" radius="0.127" width="0.254" layer="21"/>
</package>
<package name="C0805" urn="urn:adsk.eagle:footprint:10736670/2" library_version="63" library_locally_modified="yes">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;</description>
<wire x1="-1.719" y1="0.8814" x2="1.719" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="1.719" y1="-0.8814" x2="-1.719" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="-1.719" y1="-0.8814" x2="-1.719" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<wire x1="1.719" y1="0.8814" x2="1.719" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="-0.762" y1="0.8128" x2="0.8382" y2="0.8128" width="0.0762" layer="21"/>
<wire x1="0.8382" y1="-0.8128" x2="-0.762" y2="-0.8128" width="0.0762" layer="21"/>
<smd name="1" x="-0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C0201" urn="urn:adsk.eagle:footprint:10736660/1" library_version="45">
<description>Source: http://www.avxcorp.com/docs/catalogs/cx5r.pdf</description>
<smd name="1" x="-0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<smd name="2" x="0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.3" y1="-0.15" x2="-0.15" y2="0.15" layer="51"/>
<rectangle x1="0.15" y1="-0.15" x2="0.3" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="0.1" x2="0.15" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="-0.15" x2="0.15" y2="-0.1" layer="51"/>
<wire x1="-0.508" y1="-0.3048" x2="-0.508" y2="0.3048" width="0.0508" layer="39"/>
<wire x1="-0.508" y1="0.3048" x2="0.508" y2="0.3048" width="0.0508" layer="39"/>
<wire x1="0.508" y1="0.3048" x2="0.508" y2="-0.3048" width="0.0508" layer="39"/>
<wire x1="0.508" y1="-0.3048" x2="-0.508" y2="-0.3048" width="0.0508" layer="39"/>
</package>
<package name="C0504" urn="urn:adsk.eagle:footprint:10736661/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.3206" y1="0.7798" x2="1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="0.7798" x2="1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="-0.7798" x2="-1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="-1.3206" y1="-0.7798" x2="-1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C0603" urn="urn:adsk.eagle:footprint:10736667/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.5238" y1="0.6274" x2="1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="0.6274" x2="1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="-0.6274" x2="-1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="-1.5238" y1="-0.6274" x2="-1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C1206" urn="urn:adsk.eagle:footprint:10736673/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.0338" x2="2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.0338" x2="-2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.0338" x2="-2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="1.0338" x2="2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1210" urn="urn:adsk.eagle:footprint:10736659/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.483" x2="2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.483" x2="-2.3206" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.483" x2="-2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.3206" y1="1.483" x2="2.3206" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1310" urn="urn:adsk.eagle:footprint:10736665/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.3206" y1="0.7798" x2="1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="0.7798" x2="1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="-0.7798" x2="-1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="-1.3206" y1="-0.7798" x2="-1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.3" x2="0.1001" y2="0.3" layer="35"/>
</package>
<package name="C1608" urn="urn:adsk.eagle:footprint:10736664/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.5238" y1="0.6274" x2="1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="0.6274" x2="1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="-0.6274" x2="-1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="-1.5238" y1="-0.6274" x2="-1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C1808" urn="urn:adsk.eagle:footprint:10736658/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-1.4732" y1="0.9502" x2="1.4732" y2="0.9502" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-0.9502" x2="1.4732" y2="-0.9502" width="0.1016" layer="51"/>
<wire x1="-2.8956" y1="-1.2192" x2="-2.8956" y2="1.2192" width="0.0508" layer="39"/>
<wire x1="-2.8956" y1="1.2192" x2="2.8956" y2="1.2192" width="0.0508" layer="39"/>
<wire x1="2.8956" y1="1.2192" x2="2.8956" y2="-1.2192" width="0.0508" layer="39"/>
<wire x1="2.8956" y1="-1.2192" x2="-2.8956" y2="-1.2192" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<text x="-2.233" y="1.827" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.233" y="-2.842" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.275" y1="-1.015" x2="-1.225" y2="1.015" layer="51"/>
<rectangle x1="1.225" y1="-1.015" x2="2.275" y2="1.015" layer="51"/>
</package>
<package name="C1812" urn="urn:adsk.eagle:footprint:10736668/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0238" y1="1.8306" x2="3.0238" y2="1.8306" width="0.0508" layer="39"/>
<wire x1="3.0238" y1="-1.8306" x2="-3.0238" y2="-1.8306" width="0.0508" layer="39"/>
<wire x1="-3.0238" y1="-1.8306" x2="-3.0238" y2="1.8306" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="3.0238" y1="1.8306" x2="3.0238" y2="-1.8306" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.3" y1="-0.4001" x2="0.3" y2="0.4001" layer="35"/>
</package>
<package name="C1825" urn="urn:adsk.eagle:footprint:10736666/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0238" y1="3.5338" x2="3.0238" y2="3.5338" width="0.0508" layer="39"/>
<wire x1="3.0238" y1="-3.5338" x2="-3.0238" y2="-3.5338" width="0.0508" layer="39"/>
<wire x1="-3.0238" y1="-3.5338" x2="-3.0238" y2="3.5338" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="3.0238" y1="3.5338" x2="3.0238" y2="-3.5338" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.7" y1="-0.7" x2="0.7" y2="0.7" layer="35"/>
</package>
<package name="C2012" urn="urn:adsk.eagle:footprint:10736669/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.6174" y1="0.8814" x2="1.6174" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="1.6174" y1="0.8814" x2="1.6174" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="1.6174" y1="-0.8814" x2="-1.6174" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="-1.6174" y1="-0.8814" x2="-1.6174" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C3216" urn="urn:adsk.eagle:footprint:10736676/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.0338" x2="2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.0338" x2="-2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.0338" x2="-2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="1.0338" x2="2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.3" y1="-0.5001" x2="0.3" y2="0.5001" layer="35"/>
</package>
<package name="C3225" urn="urn:adsk.eagle:footprint:10736672/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.483" x2="2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.483" x2="-2.3206" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.483" x2="-2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.3206" y1="1.483" x2="2.3206" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.5001" x2="0.1999" y2="0.5001" layer="35"/>
</package>
<package name="C3640" urn="urn:adsk.eagle:footprint:10736674/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-3.8322" y1="5.0496" x2="3.8322" y2="5.0496" width="0.1016" layer="51"/>
<wire x1="-3.8322" y1="-5.0496" x2="3.8322" y2="-5.0496" width="0.1016" layer="51"/>
<wire x1="-5.7912" y1="5.588" x2="5.7912" y2="5.588" width="0.0508" layer="39"/>
<wire x1="5.7912" y1="5.588" x2="5.7912" y2="-5.588" width="0.0508" layer="39"/>
<wire x1="5.7912" y1="-5.588" x2="-5.7912" y2="-5.588" width="0.0508" layer="39"/>
<wire x1="-5.7912" y1="-5.588" x2="-5.7912" y2="5.588" width="0.0508" layer="39"/>
<smd name="1" x="-4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<smd name="2" x="4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<text x="-4.647" y="6.465" size="1.27" layer="25">&gt;NAME</text>
<text x="-4.647" y="-7.255" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-4.57" y1="-5.1" x2="-3.05" y2="5.1" layer="51"/>
<rectangle x1="3.05" y1="-5.1" x2="4.5688" y2="5.1" layer="51"/>
</package>
<package name="C4532" urn="urn:adsk.eagle:footprint:10736671/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0746" y1="1.9322" x2="3.0746" y2="1.9322" width="0.0508" layer="39"/>
<wire x1="3.0746" y1="-1.9322" x2="-3.0746" y2="-1.9322" width="0.0508" layer="39"/>
<wire x1="-3.0746" y1="-1.9322" x2="-3.0746" y2="1.9322" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="3.0746" y1="1.9322" x2="3.0746" y2="-1.9322" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.4001" y1="-0.7" x2="0.4001" y2="0.7" layer="35"/>
</package>
<package name="C4564" urn="urn:adsk.eagle:footprint:10736675/1" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0746" y1="3.5846" x2="3.0746" y2="3.5846" width="0.0508" layer="39"/>
<wire x1="3.0746" y1="-3.5846" x2="-3.0746" y2="-3.5846" width="0.0508" layer="39"/>
<wire x1="-3.0746" y1="-3.5846" x2="-3.0746" y2="3.5846" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="3.0746" y1="3.5846" x2="3.0746" y2="-3.5846" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="C0402" urn="urn:adsk.eagle:footprint:10724855/2" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-0.245" y1="0.224" x2="0.245" y2="0.224" width="0.1524" layer="51"/>
<wire x1="0.245" y1="-0.224" x2="-0.245" y2="-0.224" width="0.1524" layer="51"/>
<wire x1="-1.1174" y1="0.5846" x2="1.1174" y2="0.5846" width="0.0508" layer="39"/>
<wire x1="1.1174" y1="0.5846" x2="1.1174" y2="-0.5846" width="0.0508" layer="39"/>
<wire x1="1.1174" y1="-0.5846" x2="-1.1174" y2="-0.5846" width="0.0508" layer="39"/>
<wire x1="-1.1174" y1="-0.5846" x2="-1.1174" y2="0.5846" width="0.0508" layer="39"/>
<smd name="1" x="-0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<smd name="2" x="0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.2951" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.2951" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="TO220" urn="urn:adsk.eagle:footprint:28453/1" library_version="45">
<description>&lt;b&gt;TO 220 horizontal&lt;/b&gt;</description>
<wire x1="-5.207" y1="-1.27" x2="5.207" y2="-1.27" width="0.127" layer="21"/>
<wire x1="5.207" y1="14.605" x2="-5.207" y2="14.605" width="0.127" layer="21"/>
<wire x1="5.207" y1="-1.27" x2="5.207" y2="11.176" width="0.127" layer="21"/>
<wire x1="5.207" y1="11.176" x2="4.318" y2="11.176" width="0.127" layer="21"/>
<wire x1="4.318" y1="11.176" x2="4.318" y2="12.7" width="0.127" layer="21"/>
<wire x1="4.318" y1="12.7" x2="5.207" y2="12.7" width="0.127" layer="21"/>
<wire x1="5.207" y1="12.7" x2="5.207" y2="14.605" width="0.127" layer="21"/>
<wire x1="-5.207" y1="-1.27" x2="-5.207" y2="11.176" width="0.127" layer="21"/>
<wire x1="-5.207" y1="11.176" x2="-4.318" y2="11.176" width="0.127" layer="21"/>
<wire x1="-4.318" y1="11.176" x2="-4.318" y2="12.7" width="0.127" layer="21"/>
<wire x1="-4.318" y1="12.7" x2="-5.207" y2="12.7" width="0.127" layer="21"/>
<wire x1="-5.207" y1="12.7" x2="-5.207" y2="14.605" width="0.127" layer="21"/>
<wire x1="-4.572" y1="-0.635" x2="4.572" y2="-0.635" width="0.0508" layer="21"/>
<wire x1="4.572" y1="7.62" x2="4.572" y2="-0.635" width="0.0508" layer="21"/>
<wire x1="4.572" y1="7.62" x2="-4.572" y2="7.62" width="0.0508" layer="21"/>
<wire x1="-4.572" y1="-0.635" x2="-4.572" y2="7.62" width="0.0508" layer="21"/>
<circle x="0" y="11.176" radius="1.8034" width="0.127" layer="21"/>
<circle x="0" y="11.176" radius="4.191" width="0" layer="42"/>
<circle x="0" y="11.176" radius="4.191" width="0" layer="43"/>
<pad name="1" x="-2.54" y="-6.35" drill="1.1176" shape="long" rot="R90"/>
<pad name="2" x="0" y="-6.35" drill="1.1176" shape="long" rot="R90"/>
<pad name="3" x="2.54" y="-6.35" drill="1.1176" shape="long" rot="R90"/>
<text x="-3.81" y="5.207" size="1.778" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.937" y="2.54" size="1.778" layer="27" ratio="10">&gt;VALUE</text>
<text x="-4.445" y="7.874" size="0.9906" layer="21" ratio="12">A17,5mm</text>
<text x="-3.175" y="0" size="1.27" layer="51" ratio="10">1</text>
<text x="-0.635" y="0" size="1.27" layer="51" ratio="10">2</text>
<text x="1.905" y="0" size="1.27" layer="51" ratio="10">3</text>
<rectangle x1="2.159" y1="-4.699" x2="2.921" y2="-4.064" layer="21"/>
<rectangle x1="-0.381" y1="-4.699" x2="0.381" y2="-4.064" layer="21"/>
<rectangle x1="-2.921" y1="-4.699" x2="-2.159" y2="-4.064" layer="21"/>
<rectangle x1="-3.175" y1="-4.064" x2="-1.905" y2="-1.27" layer="21"/>
<rectangle x1="-0.635" y1="-4.064" x2="0.635" y2="-1.27" layer="21"/>
<rectangle x1="1.905" y1="-4.064" x2="3.175" y2="-1.27" layer="21"/>
<rectangle x1="-2.921" y1="-6.604" x2="-2.159" y2="-4.699" layer="51"/>
<rectangle x1="-0.381" y1="-6.604" x2="0.381" y2="-4.699" layer="51"/>
<rectangle x1="2.159" y1="-6.604" x2="2.921" y2="-4.699" layer="51"/>
<hole x="0" y="11.176" drill="3.302"/>
</package>
<package name="RASPBERRYPI_ZERO" urn="urn:adsk.eagle:footprint:10723822/4" library_version="74">
<description>Raspberry Pi board model B+, full outline with position of big connectors &amp;amp; drill holes</description>
<circle x="3.5" y="3.5" radius="3.1" width="0.127" layer="51"/>
<circle x="61.5" y="3.5" radius="3.1" width="0.127" layer="51"/>
<circle x="61.5" y="26.5" radius="3.1" width="0.127" layer="51"/>
<circle x="3.5" y="26.5" radius="3.1" width="0.127" layer="51"/>
<wire x1="0" y1="3" x2="3" y2="0" width="0.254" layer="21" curve="90"/>
<wire x1="3" y1="0" x2="6.85" y2="0" width="0.254" layer="21"/>
<wire x1="6.85" y1="0" x2="14.35" y2="0" width="0.254" layer="21"/>
<wire x1="14.35" y1="0" x2="62" y2="0" width="0.254" layer="21"/>
<wire x1="62" y1="0" x2="65" y2="3" width="0.254" layer="21" curve="90"/>
<wire x1="65" y1="3" x2="65" y2="27" width="0.254" layer="21"/>
<wire x1="65" y1="27" x2="62" y2="30" width="0.254" layer="21" curve="90"/>
<wire x1="62" y1="30" x2="3" y2="30" width="0.254" layer="21"/>
<wire x1="3" y1="30" x2="0" y2="27" width="0.254" layer="21" curve="90"/>
<wire x1="0" y1="27" x2="0" y2="3" width="0.254" layer="21"/>
<wire x1="7.1" y1="29.04" x2="7.1" y2="26.5" width="0.127" layer="21"/>
<wire x1="7.1" y1="26.5" x2="7.1" y2="23.96" width="0.127" layer="21"/>
<wire x1="7.1" y1="23.96" x2="8.0525" y2="23.96" width="0.127" layer="21"/>
<wire x1="8.0525" y1="23.96" x2="8.6875" y2="23.96" width="0.127" layer="21"/>
<wire x1="8.6875" y1="23.96" x2="9.64" y2="23.96" width="0.127" layer="21"/>
<wire x1="9.64" y1="23.96" x2="57.9" y2="23.96" width="0.127" layer="21"/>
<wire x1="57.9" y1="23.96" x2="57.9" y2="29.04" width="0.127" layer="21"/>
<wire x1="57.9" y1="29.04" x2="7.1" y2="29.04" width="0.127" layer="21"/>
<wire x1="7.1" y1="26.5" x2="9.64" y2="26.5" width="0.127" layer="21"/>
<wire x1="9.64" y1="26.5" x2="9.64" y2="23.96" width="0.127" layer="21"/>
<wire x1="8.0525" y1="23.96" x2="8.0525" y2="23.6425" width="0.127" layer="21"/>
<wire x1="8.0525" y1="23.6425" x2="8.6875" y2="23.6425" width="0.127" layer="21"/>
<wire x1="8.6875" y1="23.6425" x2="8.6875" y2="23.96" width="0.127" layer="21"/>
<wire x1="6.85" y1="0" x2="6.85" y2="5.75" width="0.127" layer="51"/>
<wire x1="6.85" y1="5.75" x2="14.35" y2="5.75" width="0.127" layer="51"/>
<wire x1="14.35" y1="5.75" x2="14.35" y2="0" width="0.127" layer="51"/>
<wire x1="6.85" y1="0" x2="6.6" y2="-0.5" width="0.127" layer="51"/>
<wire x1="6.6" y1="-0.5" x2="14.6" y2="-0.5" width="0.127" layer="51"/>
<wire x1="14.6" y1="-0.5" x2="14.35" y2="0" width="0.127" layer="51"/>
<wire x1="37.75" y1="0" x2="37.75" y2="5.75" width="0.127" layer="51"/>
<wire x1="37.75" y1="5.75" x2="45.25" y2="5.75" width="0.127" layer="51"/>
<wire x1="45.25" y1="5.75" x2="45.25" y2="0" width="0.127" layer="51"/>
<wire x1="37.75" y1="0" x2="37.5" y2="-0.5" width="0.127" layer="51"/>
<wire x1="37.5" y1="-0.5" x2="45.5" y2="-0.5" width="0.127" layer="51"/>
<wire x1="45.5" y1="-0.5" x2="45.25" y2="0" width="0.127" layer="51"/>
<wire x1="50.35" y1="0" x2="50.35" y2="5.75" width="0.127" layer="51"/>
<wire x1="50.35" y1="5.75" x2="57.85" y2="5.75" width="0.127" layer="51"/>
<wire x1="57.85" y1="5.75" x2="57.85" y2="0" width="0.127" layer="51"/>
<wire x1="50.35" y1="0" x2="50.1" y2="-0.5" width="0.127" layer="51"/>
<wire x1="50.1" y1="-0.5" x2="58.1" y2="-0.5" width="0.127" layer="51"/>
<wire x1="58.1" y1="-0.5" x2="57.85" y2="0" width="0.127" layer="51"/>
<pad name="1" x="8.37" y="25.23" drill="1" diameter="1.778" shape="square"/>
<pad name="2" x="8.37" y="27.77" drill="1" diameter="1.778"/>
<pad name="3" x="10.91" y="25.23" drill="1" diameter="1.778"/>
<pad name="4" x="10.91" y="27.77" drill="1" diameter="1.778"/>
<pad name="5" x="13.45" y="25.23" drill="1" diameter="1.778"/>
<pad name="6" x="13.45" y="27.77" drill="1" diameter="1.778"/>
<pad name="7" x="15.99" y="25.23" drill="1" diameter="1.778"/>
<pad name="8" x="15.99" y="27.77" drill="1" diameter="1.778"/>
<pad name="9" x="18.53" y="25.23" drill="1" diameter="1.778"/>
<pad name="10" x="18.53" y="27.77" drill="1" diameter="1.778"/>
<pad name="11" x="21.07" y="25.23" drill="1" diameter="1.778"/>
<pad name="12" x="21.07" y="27.77" drill="1" diameter="1.778"/>
<pad name="13" x="23.61" y="25.23" drill="1" diameter="1.778"/>
<pad name="14" x="23.61" y="27.77" drill="1" diameter="1.778"/>
<pad name="15" x="26.15" y="25.23" drill="1" diameter="1.778"/>
<pad name="16" x="26.15" y="27.77" drill="1" diameter="1.778"/>
<pad name="17" x="28.69" y="25.23" drill="1" diameter="1.778"/>
<pad name="18" x="28.69" y="27.77" drill="1" diameter="1.778"/>
<pad name="19" x="31.23" y="25.23" drill="1" diameter="1.778"/>
<pad name="20" x="31.23" y="27.77" drill="1" diameter="1.778"/>
<pad name="21" x="33.77" y="25.23" drill="1" diameter="1.778"/>
<pad name="22" x="33.77" y="27.77" drill="1" diameter="1.778"/>
<pad name="23" x="36.31" y="25.23" drill="1" diameter="1.778"/>
<pad name="24" x="36.31" y="27.77" drill="1" diameter="1.778"/>
<pad name="25" x="38.85" y="25.23" drill="1" diameter="1.778"/>
<pad name="26" x="38.85" y="27.77" drill="1" diameter="1.778"/>
<pad name="27" x="41.39" y="25.23" drill="1" diameter="1.778"/>
<pad name="28" x="41.39" y="27.77" drill="1" diameter="1.778"/>
<pad name="29" x="43.93" y="25.23" drill="1" diameter="1.778"/>
<pad name="30" x="43.93" y="27.77" drill="1" diameter="1.778"/>
<pad name="31" x="46.47" y="25.23" drill="1" diameter="1.778"/>
<pad name="32" x="46.47" y="27.77" drill="1" diameter="1.778"/>
<pad name="33" x="49.01" y="25.23" drill="1" diameter="1.778"/>
<pad name="34" x="49.01" y="27.77" drill="1" diameter="1.778"/>
<pad name="35" x="51.55" y="25.23" drill="1" diameter="1.778"/>
<pad name="36" x="51.55" y="27.77" drill="1" diameter="1.778"/>
<pad name="37" x="54.09" y="25.23" drill="1" diameter="1.778"/>
<pad name="38" x="54.09" y="27.77" drill="1" diameter="1.778"/>
<pad name="39" x="56.63" y="25.23" drill="1" diameter="1.778"/>
<pad name="40" x="56.63" y="27.77" drill="1" diameter="1.778"/>
<text x="8.0525" y="22.3725" size="1.016" layer="21" font="vector" ratio="10">1</text>
</package>
<package name="VNH5019" urn="urn:adsk.eagle:footprint:10723827/4" library_version="49">
<wire x1="-19.05" y1="5.715" x2="-19.05" y2="6.985" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="6.985" x2="-18.415" y2="7.62" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="7.62" x2="-17.145" y2="7.62" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="7.62" x2="-16.51" y2="6.985" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="2.54" x2="-19.05" y2="3.175" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="3.175" x2="-19.05" y2="4.445" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="4.445" x2="-18.415" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="5.08" x2="-17.145" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="5.08" x2="-16.51" y2="4.445" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="4.445" x2="-16.51" y2="3.175" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="3.175" x2="-17.145" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="5.715" x2="-18.415" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="5.08" x2="-16.51" y2="5.715" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="6.985" x2="-16.51" y2="5.715" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-1.905" x2="-19.05" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-0.635" x2="-18.415" y2="0" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="0" x2="-17.145" y2="0" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="0" x2="-16.51" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="0" x2="-19.05" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="0.635" x2="-19.05" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="1.905" x2="-18.415" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="2.54" x2="-17.145" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="2.54" x2="-16.51" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="1.905" x2="-16.51" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="0.635" x2="-17.145" y2="0" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="-5.08" x2="-19.05" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-4.445" x2="-19.05" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-3.175" x2="-18.415" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="-2.54" x2="-17.145" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="-2.54" x2="-16.51" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="-3.175" x2="-16.51" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="-4.445" x2="-17.145" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-1.905" x2="-18.415" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="-2.54" x2="-16.51" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="-0.635" x2="-16.51" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-9.525" x2="-19.05" y2="-8.255" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-8.255" x2="-18.415" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="-7.62" x2="-17.145" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="-7.62" x2="-16.51" y2="-8.255" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="-7.62" x2="-19.05" y2="-6.985" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-6.985" x2="-19.05" y2="-5.715" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-5.715" x2="-18.415" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="-5.08" x2="-17.145" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="-5.08" x2="-16.51" y2="-5.715" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="-5.715" x2="-16.51" y2="-6.985" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="-6.985" x2="-17.145" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="-10.16" x2="-17.145" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="-9.525" x2="-18.415" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="-10.16" x2="-16.51" y2="-9.525" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="-8.255" x2="-16.51" y2="-9.525" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="8.255" x2="-19.05" y2="9.525" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="9.525" x2="-18.415" y2="10.16" width="0.1524" layer="21"/>
<wire x1="-18.415" y1="10.16" x2="-17.145" y2="10.16" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="10.16" x2="-16.51" y2="9.525" width="0.1524" layer="21"/>
<wire x1="-19.05" y1="8.255" x2="-18.415" y2="7.62" width="0.1524" layer="21"/>
<wire x1="-17.145" y1="7.62" x2="-16.51" y2="8.255" width="0.1524" layer="21"/>
<wire x1="-16.51" y1="9.525" x2="-16.51" y2="8.255" width="0.1524" layer="21"/>
<wire x1="17.145" y1="10.16" x2="16.51" y2="10.795" width="0.1524" layer="21"/>
<wire x1="16.51" y1="10.795" x2="16.51" y2="12.065" width="0.1524" layer="21"/>
<wire x1="16.51" y1="12.065" x2="17.145" y2="12.7" width="0.1524" layer="21"/>
<wire x1="17.145" y1="12.7" x2="18.415" y2="12.7" width="0.1524" layer="21"/>
<wire x1="18.415" y1="12.7" x2="19.05" y2="12.065" width="0.1524" layer="21"/>
<wire x1="19.05" y1="12.065" x2="19.05" y2="10.795" width="0.1524" layer="21"/>
<wire x1="19.05" y1="10.795" x2="18.415" y2="10.16" width="0.1524" layer="21"/>
<wire x1="16.51" y1="5.715" x2="16.51" y2="6.985" width="0.1524" layer="21"/>
<wire x1="16.51" y1="6.985" x2="17.145" y2="7.62" width="0.1524" layer="21"/>
<wire x1="17.145" y1="7.62" x2="18.415" y2="7.62" width="0.1524" layer="21"/>
<wire x1="18.415" y1="7.62" x2="19.05" y2="6.985" width="0.1524" layer="21"/>
<wire x1="17.145" y1="7.62" x2="16.51" y2="8.255" width="0.1524" layer="21"/>
<wire x1="16.51" y1="8.255" x2="16.51" y2="9.525" width="0.1524" layer="21"/>
<wire x1="16.51" y1="9.525" x2="17.145" y2="10.16" width="0.1524" layer="21"/>
<wire x1="17.145" y1="10.16" x2="18.415" y2="10.16" width="0.1524" layer="21"/>
<wire x1="18.415" y1="10.16" x2="19.05" y2="9.525" width="0.1524" layer="21"/>
<wire x1="19.05" y1="9.525" x2="19.05" y2="8.255" width="0.1524" layer="21"/>
<wire x1="19.05" y1="8.255" x2="18.415" y2="7.62" width="0.1524" layer="21"/>
<wire x1="17.145" y1="2.54" x2="16.51" y2="3.175" width="0.1524" layer="21"/>
<wire x1="16.51" y1="3.175" x2="16.51" y2="4.445" width="0.1524" layer="21"/>
<wire x1="16.51" y1="4.445" x2="17.145" y2="5.08" width="0.1524" layer="21"/>
<wire x1="17.145" y1="5.08" x2="18.415" y2="5.08" width="0.1524" layer="21"/>
<wire x1="18.415" y1="5.08" x2="19.05" y2="4.445" width="0.1524" layer="21"/>
<wire x1="19.05" y1="4.445" x2="19.05" y2="3.175" width="0.1524" layer="21"/>
<wire x1="19.05" y1="3.175" x2="18.415" y2="2.54" width="0.1524" layer="21"/>
<wire x1="16.51" y1="5.715" x2="17.145" y2="5.08" width="0.1524" layer="21"/>
<wire x1="18.415" y1="5.08" x2="19.05" y2="5.715" width="0.1524" layer="21"/>
<wire x1="19.05" y1="6.985" x2="19.05" y2="5.715" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-1.905" x2="16.51" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-0.635" x2="17.145" y2="0" width="0.1524" layer="21"/>
<wire x1="17.145" y1="0" x2="18.415" y2="0" width="0.1524" layer="21"/>
<wire x1="18.415" y1="0" x2="19.05" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="17.145" y1="0" x2="16.51" y2="0.635" width="0.1524" layer="21"/>
<wire x1="16.51" y1="0.635" x2="16.51" y2="1.905" width="0.1524" layer="21"/>
<wire x1="16.51" y1="1.905" x2="17.145" y2="2.54" width="0.1524" layer="21"/>
<wire x1="17.145" y1="2.54" x2="18.415" y2="2.54" width="0.1524" layer="21"/>
<wire x1="18.415" y1="2.54" x2="19.05" y2="1.905" width="0.1524" layer="21"/>
<wire x1="19.05" y1="1.905" x2="19.05" y2="0.635" width="0.1524" layer="21"/>
<wire x1="19.05" y1="0.635" x2="18.415" y2="0" width="0.1524" layer="21"/>
<wire x1="17.145" y1="-5.08" x2="16.51" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-4.445" x2="16.51" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-3.175" x2="17.145" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="17.145" y1="-2.54" x2="18.415" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="18.415" y1="-2.54" x2="19.05" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="19.05" y1="-3.175" x2="19.05" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="19.05" y1="-4.445" x2="18.415" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-1.905" x2="17.145" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="18.415" y1="-2.54" x2="19.05" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="19.05" y1="-0.635" x2="19.05" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-9.525" x2="16.51" y2="-8.255" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-8.255" x2="17.145" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="17.145" y1="-7.62" x2="18.415" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="18.415" y1="-7.62" x2="19.05" y2="-8.255" width="0.1524" layer="21"/>
<wire x1="17.145" y1="-7.62" x2="16.51" y2="-6.985" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-6.985" x2="16.51" y2="-5.715" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-5.715" x2="17.145" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="17.145" y1="-5.08" x2="18.415" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="18.415" y1="-5.08" x2="19.05" y2="-5.715" width="0.1524" layer="21"/>
<wire x1="19.05" y1="-5.715" x2="19.05" y2="-6.985" width="0.1524" layer="21"/>
<wire x1="19.05" y1="-6.985" x2="18.415" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="17.145" y1="-10.16" x2="18.415" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="16.51" y1="-9.525" x2="17.145" y2="-10.16" width="0.1524" layer="21"/>
<wire x1="18.415" y1="-10.16" x2="19.05" y2="-9.525" width="0.1524" layer="21"/>
<wire x1="19.05" y1="-8.255" x2="19.05" y2="-9.525" width="0.1524" layer="21"/>
<wire x1="16.51" y1="13.335" x2="16.51" y2="14.605" width="0.1524" layer="21"/>
<wire x1="16.51" y1="14.605" x2="17.145" y2="15.24" width="0.1524" layer="21"/>
<wire x1="17.145" y1="15.24" x2="18.415" y2="15.24" width="0.1524" layer="21"/>
<wire x1="18.415" y1="15.24" x2="19.05" y2="14.605" width="0.1524" layer="21"/>
<wire x1="16.51" y1="13.335" x2="17.145" y2="12.7" width="0.1524" layer="21"/>
<wire x1="18.415" y1="12.7" x2="19.05" y2="13.335" width="0.1524" layer="21"/>
<wire x1="19.05" y1="14.605" x2="19.05" y2="13.335" width="0.1524" layer="21"/>
<wire x1="18.415" y1="16.51" x2="-18.415" y2="16.51" width="0.127" layer="21"/>
<wire x1="-19.685" y1="15.24" x2="-19.685" y2="-10.16" width="0.127" layer="21"/>
<wire x1="-18.415" y1="-11.43" x2="18.415" y2="-11.43" width="0.127" layer="21"/>
<wire x1="19.685" y1="-10.16" x2="19.685" y2="15.24" width="0.127" layer="21"/>
<wire x1="-19.685" y1="15.24" x2="-18.415" y2="16.51" width="0.127" layer="21" curve="-90"/>
<wire x1="18.415" y1="16.51" x2="19.685" y2="15.24" width="0.127" layer="21" curve="-90"/>
<wire x1="19.685" y1="-10.16" x2="18.415" y2="-11.43" width="0.127" layer="21" curve="-90"/>
<wire x1="-19.685" y1="-10.16" x2="-18.415" y2="-11.43" width="0.127" layer="21" curve="90"/>
<pad name="8" x="-17.78" y="-8.89" drill="1.016" shape="long" rot="R180"/>
<pad name="7" x="-17.78" y="-6.35" drill="1.016" shape="long" rot="R180"/>
<pad name="6" x="-17.78" y="-3.81" drill="1.016" shape="long" rot="R180"/>
<pad name="5" x="-17.78" y="-1.27" drill="1.016" shape="long" rot="R180"/>
<pad name="4" x="-17.78" y="1.27" drill="1.016" shape="long" rot="R180"/>
<pad name="3" x="-17.78" y="3.81" drill="1.016" shape="long" rot="R180"/>
<pad name="2" x="-17.78" y="6.35" drill="1.016" shape="long" rot="R180"/>
<pad name="1" x="-17.78" y="8.89" drill="1.016" shape="long" rot="R180"/>
<pad name="9" x="17.78" y="-8.89" drill="1.016" shape="long" rot="R180"/>
<pad name="10" x="17.78" y="-6.35" drill="1.016" shape="long" rot="R180"/>
<pad name="11" x="17.78" y="-3.81" drill="1.016" shape="long" rot="R180"/>
<pad name="12" x="17.78" y="-1.27" drill="1.016" shape="long" rot="R180"/>
<pad name="13" x="17.78" y="1.27" drill="1.016" shape="long" rot="R180"/>
<pad name="14" x="17.78" y="3.81" drill="1.016" shape="long" rot="R180"/>
<pad name="15" x="17.78" y="6.35" drill="1.016" shape="long" rot="R180"/>
<pad name="16" x="17.78" y="8.89" drill="1.016" shape="long" rot="R180"/>
<pad name="17" x="17.78" y="11.43" drill="1.016" shape="long" rot="R180"/>
<pad name="18" x="17.78" y="13.97" drill="1.016" shape="long" rot="R180"/>
<rectangle x1="-18.034" y1="6.096" x2="-17.526" y2="6.604" layer="51" rot="R90"/>
<rectangle x1="-18.034" y1="3.556" x2="-17.526" y2="4.064" layer="51" rot="R90"/>
<rectangle x1="-18.034" y1="1.016" x2="-17.526" y2="1.524" layer="51" rot="R90"/>
<rectangle x1="-18.034" y1="-1.524" x2="-17.526" y2="-1.016" layer="51" rot="R90"/>
<rectangle x1="-18.034" y1="-4.064" x2="-17.526" y2="-3.556" layer="51" rot="R90"/>
<rectangle x1="-18.034" y1="-6.604" x2="-17.526" y2="-6.096" layer="51" rot="R90"/>
<rectangle x1="-18.034" y1="-9.144" x2="-17.526" y2="-8.636" layer="51" rot="R90"/>
<rectangle x1="-18.034" y1="8.636" x2="-17.526" y2="9.144" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="11.176" x2="18.034" y2="11.684" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="8.636" x2="18.034" y2="9.144" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="6.096" x2="18.034" y2="6.604" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="3.556" x2="18.034" y2="4.064" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="1.016" x2="18.034" y2="1.524" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="-1.524" x2="18.034" y2="-1.016" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="-4.064" x2="18.034" y2="-3.556" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="-6.604" x2="18.034" y2="-6.096" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="-9.144" x2="18.034" y2="-8.636" layer="51" rot="R90"/>
<rectangle x1="17.526" y1="13.716" x2="18.034" y2="14.224" layer="51" rot="R90"/>
<text x="10.2362" y="-8.1788" size="1.27" layer="25" ratio="10" rot="R180">&gt;NAME</text>
<text x="10.16" y="-5.715" size="1.27" layer="27" rot="R180">&gt;VALUE</text>
<text x="10.16" y="-2.54" size="1.27" layer="21" rot="R180">Motor Contoller</text>
<text x="15.24" y="13.97" size="0.762" layer="21" rot="R180">GND</text>
<text x="15.24" y="11.43" size="0.762" layer="21" rot="R180">VOUT</text>
<text x="15.24" y="8.89" size="0.762" layer="21" rot="R180">GND</text>
<text x="15.24" y="6.35" size="0.762" layer="21" rot="R180">VDD</text>
<text x="15.24" y="3.81" size="0.762" layer="21" rot="R180">INB</text>
<text x="15.24" y="1.27" size="0.762" layer="21" rot="R180">ENB</text>
<text x="15.24" y="-1.27" size="0.762" layer="21" rot="R180">CS</text>
<text x="15.24" y="-3.81" size="0.762" layer="21" rot="R180">PWM</text>
<text x="15.24" y="-6.35" size="0.762" layer="21" rot="R180">ENA</text>
<text x="15.24" y="-8.89" size="0.762" layer="21" rot="R180">INA</text>
<text x="-15.24" y="7.62" size="1.27" layer="21">VIN</text>
<text x="-15.24" y="2.54" size="1.27" layer="21">GND</text>
<text x="-15.24" y="-2.54" size="1.27" layer="21">OUTB</text>
<text x="-15.24" y="-7.62" size="1.27" layer="21">OUTA</text>
</package>
<package name="BNO055" urn="urn:adsk.eagle:footprint:10723821/2" library_version="54">
<wire x1="-7.62" y1="-0.635" x2="-7.62" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-1.905" x2="-8.255" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="-2.54" x2="-9.525" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="-2.54" x2="-10.16" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="-2.54" x2="-7.62" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-3.175" x2="-7.62" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-4.445" x2="-8.255" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="-5.08" x2="-9.525" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="-5.08" x2="-10.16" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="-4.445" x2="-10.16" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="-3.175" x2="-9.525" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="2.54" x2="-7.62" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="1.905" x2="-7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="0.635" x2="-8.255" y2="0" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="0" x2="-9.525" y2="0" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="0" x2="-10.16" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="0.635" x2="-10.16" y2="1.905" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="1.905" x2="-9.525" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-0.635" x2="-8.255" y2="0" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="0" x2="-10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="-1.905" x2="-10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="6.985" x2="-7.62" y2="5.715" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="5.715" x2="-8.255" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="5.08" x2="-9.525" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="5.08" x2="-10.16" y2="5.715" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="5.08" x2="-7.62" y2="4.445" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="4.445" x2="-7.62" y2="3.175" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="3.175" x2="-8.255" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="2.54" x2="-9.525" y2="2.54" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="2.54" x2="-10.16" y2="3.175" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="3.175" x2="-10.16" y2="4.445" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="4.445" x2="-9.525" y2="5.08" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="7.62" x2="-9.525" y2="7.62" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="6.985" x2="-8.255" y2="7.62" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="7.62" x2="-10.16" y2="6.985" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="5.715" x2="-10.16" y2="6.985" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-5.715" x2="-7.62" y2="-6.985" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-6.985" x2="-8.255" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="-7.62" x2="-9.525" y2="-7.62" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="-7.62" x2="-10.16" y2="-6.985" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-5.715" x2="-8.255" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="-5.08" x2="-10.16" y2="-5.715" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="-6.985" x2="-10.16" y2="-5.715" width="0.1524" layer="21"/>
<wire x1="8.255" y1="0" x2="7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="0.635" x2="7.62" y2="1.905" width="0.1524" layer="21"/>
<wire x1="7.62" y1="1.905" x2="8.255" y2="2.54" width="0.1524" layer="21"/>
<wire x1="8.255" y1="2.54" x2="9.525" y2="2.54" width="0.1524" layer="21"/>
<wire x1="9.525" y1="2.54" x2="10.16" y2="1.905" width="0.1524" layer="21"/>
<wire x1="10.16" y1="1.905" x2="10.16" y2="0.635" width="0.1524" layer="21"/>
<wire x1="10.16" y1="0.635" x2="9.525" y2="0" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-4.445" x2="7.62" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-3.175" x2="8.255" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="8.255" y1="-2.54" x2="9.525" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="9.525" y1="-2.54" x2="10.16" y2="-3.175" width="0.1524" layer="21"/>
<wire x1="8.255" y1="-2.54" x2="7.62" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-1.905" x2="7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-0.635" x2="8.255" y2="0" width="0.1524" layer="21"/>
<wire x1="8.255" y1="0" x2="9.525" y2="0" width="0.1524" layer="21"/>
<wire x1="9.525" y1="0" x2="10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="10.16" y1="-0.635" x2="10.16" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="10.16" y1="-1.905" x2="9.525" y2="-2.54" width="0.1524" layer="21"/>
<wire x1="8.255" y1="-5.08" x2="9.525" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-4.445" x2="8.255" y2="-5.08" width="0.1524" layer="21"/>
<wire x1="9.525" y1="-5.08" x2="10.16" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="10.16" y1="-3.175" x2="10.16" y2="-4.445" width="0.1524" layer="21"/>
<wire x1="7.62" y1="3.175" x2="7.62" y2="4.445" width="0.1524" layer="21"/>
<wire x1="7.62" y1="4.445" x2="8.255" y2="5.08" width="0.1524" layer="21"/>
<wire x1="8.255" y1="5.08" x2="9.525" y2="5.08" width="0.1524" layer="21"/>
<wire x1="9.525" y1="5.08" x2="10.16" y2="4.445" width="0.1524" layer="21"/>
<wire x1="7.62" y1="3.175" x2="8.255" y2="2.54" width="0.1524" layer="21"/>
<wire x1="9.525" y1="2.54" x2="10.16" y2="3.175" width="0.1524" layer="21"/>
<wire x1="10.16" y1="4.445" x2="10.16" y2="3.175" width="0.1524" layer="21"/>
<wire x1="-10.795" y1="10.795" x2="-10.795" y2="-10.795" width="0.127" layer="21"/>
<wire x1="-8.255" y1="-13.335" x2="8.255" y2="-13.335" width="0.127" layer="21"/>
<wire x1="10.795" y1="-10.795" x2="10.795" y2="10.795" width="0.127" layer="21"/>
<wire x1="8.255" y1="13.335" x2="-8.255" y2="13.335" width="0.127" layer="21"/>
<wire x1="-8.255" y1="13.335" x2="-10.795" y2="10.795" width="0.127" layer="21" curve="90"/>
<wire x1="8.255" y1="13.335" x2="10.795" y2="10.795" width="0.127" layer="21" curve="-90"/>
<wire x1="10.795" y1="-10.795" x2="8.255" y2="-13.335" width="0.127" layer="21" curve="-90"/>
<wire x1="-10.795" y1="-10.795" x2="-8.255" y2="-13.335" width="0.127" layer="21" curve="90"/>
<pad name="1" x="-8.89" y="6.35" drill="1.016" shape="long"/>
<pad name="2" x="-8.89" y="3.81" drill="1.016" shape="long"/>
<pad name="3" x="-8.89" y="1.27" drill="1.016" shape="long"/>
<pad name="4" x="-8.89" y="-1.27" drill="1.016" shape="long"/>
<pad name="5" x="-8.89" y="-3.81" drill="1.016" shape="long"/>
<pad name="6" x="-8.89" y="-6.35" drill="1.016" shape="long"/>
<pad name="7" x="8.89" y="-3.81" drill="1.016" shape="long" rot="R180"/>
<pad name="8" x="8.89" y="-1.27" drill="1.016" shape="long" rot="R180"/>
<pad name="9" x="8.89" y="1.27" drill="1.016" shape="long" rot="R180"/>
<pad name="10" x="8.89" y="3.81" drill="1.016" shape="long" rot="R180"/>
<text x="-7.0612" y="-12.1412" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-6.985" y="-10.16" size="1.27" layer="27">&gt;VALUE</text>
<text x="-1.27" y="11.43" size="1.27" layer="21">IMU</text>
<text x="-6.35" y="6.35" size="0.762" layer="21">VIN</text>
<text x="-6.35" y="3.81" size="0.762" layer="21">3VO</text>
<text x="-6.35" y="1.27" size="0.762" layer="21">GND</text>
<text x="-6.35" y="-1.27" size="0.762" layer="21">SDA</text>
<text x="-6.35" y="-3.81" size="0.762" layer="21">SCL</text>
<text x="-6.35" y="-6.35" size="0.762" layer="21">RST</text>
<text x="6.35" y="3.81" size="0.762" layer="21" rot="R180">PS0</text>
<text x="6.35" y="1.27" size="0.762" layer="21" rot="R180">PS1</text>
<text x="6.35" y="-1.27" size="0.762" layer="21" rot="R180">INT</text>
<text x="6.35" y="-3.81" size="0.762" layer="21" rot="R180">ADR</text>
<rectangle x1="-9.144" y1="-4.064" x2="-8.636" y2="-3.556" layer="51" rot="R270"/>
<rectangle x1="-9.144" y1="-1.524" x2="-8.636" y2="-1.016" layer="51" rot="R270"/>
<rectangle x1="-9.144" y1="1.016" x2="-8.636" y2="1.524" layer="51" rot="R270"/>
<rectangle x1="-9.144" y1="3.556" x2="-8.636" y2="4.064" layer="51" rot="R270"/>
<rectangle x1="-9.144" y1="6.096" x2="-8.636" y2="6.604" layer="51" rot="R270"/>
<rectangle x1="-9.144" y1="-6.604" x2="-8.636" y2="-6.096" layer="51" rot="R270"/>
<rectangle x1="8.636" y1="1.016" x2="9.144" y2="1.524" layer="51" rot="R90"/>
<rectangle x1="8.636" y1="-1.524" x2="9.144" y2="-1.016" layer="51" rot="R90"/>
<rectangle x1="8.636" y1="-4.064" x2="9.144" y2="-3.556" layer="51" rot="R90"/>
<rectangle x1="8.636" y1="3.556" x2="9.144" y2="4.064" layer="51" rot="R90"/>
</package>
<package name="PW14" urn="urn:adsk.eagle:footprint:10752470/2" library_version="58">
<smd name="1" x="-2.8194" y="1.95" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="2" x="-2.8194" y="1.3" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="3" x="-2.8194" y="0.65" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="4" x="-2.8194" y="0" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="5" x="-2.8194" y="-0.65" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="6" x="-2.8194" y="-1.3" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="7" x="-2.8194" y="-1.95" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="8" x="2.8194" y="-1.95" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="9" x="2.8194" y="-1.3" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="10" x="2.8194" y="-0.65" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="11" x="2.8194" y="0" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="12" x="2.8194" y="0.65" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="13" x="2.8194" y="1.3" dx="1.6764" dy="0.3556" layer="1"/>
<smd name="14" x="2.8194" y="1.95" dx="1.6764" dy="0.3556" layer="1"/>
<wire x1="-2.2352" y1="1.8034" x2="-2.2352" y2="2.1082" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="2.1082" x2="-3.302" y2="2.1082" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="2.1082" x2="-3.302" y2="1.8034" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="1.8034" x2="-2.2352" y2="1.8034" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="1.143" x2="-2.2352" y2="1.4478" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="1.4478" x2="-3.302" y2="1.4478" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="1.4478" x2="-3.302" y2="1.143" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="1.143" x2="-2.2352" y2="1.143" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="0.508" x2="-2.2352" y2="0.8128" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="0.8128" x2="-3.302" y2="0.8128" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="0.8128" x2="-3.302" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="0.508" x2="-2.2352" y2="0.508" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-0.1524" x2="-2.2352" y2="0.1524" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="0.1524" x2="-3.302" y2="0.1524" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="0.1524" x2="-3.302" y2="-0.1524" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="-0.1524" x2="-2.2352" y2="-0.1524" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-0.8128" x2="-2.2352" y2="-0.508" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-0.508" x2="-3.302" y2="-0.508" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="-0.508" x2="-3.302" y2="-0.8128" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="-0.8128" x2="-2.2352" y2="-0.8128" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-1.4478" x2="-2.2352" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-1.143" x2="-3.302" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="-1.143" x2="-3.302" y2="-1.4478" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="-1.4478" x2="-2.2352" y2="-1.4478" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-2.1082" x2="-2.2352" y2="-1.8034" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-1.8034" x2="-3.302" y2="-1.8034" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="-1.8034" x2="-3.302" y2="-2.1082" width="0.1524" layer="51"/>
<wire x1="-3.302" y1="-2.1082" x2="-2.2352" y2="-2.1082" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-1.8034" x2="2.2352" y2="-2.1082" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-2.1082" x2="3.302" y2="-2.1082" width="0.1524" layer="51"/>
<wire x1="3.302" y1="-2.1082" x2="3.302" y2="-1.8034" width="0.1524" layer="51"/>
<wire x1="3.302" y1="-1.8034" x2="2.2352" y2="-1.8034" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-1.143" x2="2.2352" y2="-1.4478" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-1.4478" x2="3.302" y2="-1.4478" width="0.1524" layer="51"/>
<wire x1="3.302" y1="-1.4478" x2="3.302" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="3.302" y1="-1.143" x2="2.2352" y2="-1.143" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-0.508" x2="2.2352" y2="-0.8128" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-0.8128" x2="3.302" y2="-0.8128" width="0.1524" layer="51"/>
<wire x1="3.302" y1="-0.8128" x2="3.302" y2="-0.508" width="0.1524" layer="51"/>
<wire x1="3.302" y1="-0.508" x2="2.2352" y2="-0.508" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="0.1524" x2="2.2352" y2="-0.1524" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-0.1524" x2="3.302" y2="-0.1524" width="0.1524" layer="51"/>
<wire x1="3.302" y1="-0.1524" x2="3.302" y2="0.1524" width="0.1524" layer="51"/>
<wire x1="3.302" y1="0.1524" x2="2.2352" y2="0.1524" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="0.8128" x2="2.2352" y2="0.508" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="0.508" x2="3.302" y2="0.508" width="0.1524" layer="51"/>
<wire x1="3.302" y1="0.508" x2="3.302" y2="0.8128" width="0.1524" layer="51"/>
<wire x1="3.302" y1="0.8128" x2="2.2352" y2="0.8128" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="1.4478" x2="2.2352" y2="1.143" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="1.143" x2="3.302" y2="1.143" width="0.1524" layer="51"/>
<wire x1="3.302" y1="1.143" x2="3.302" y2="1.4478" width="0.1524" layer="51"/>
<wire x1="3.302" y1="1.4478" x2="2.2352" y2="1.4478" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="2.1082" x2="2.2352" y2="1.8034" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="1.8034" x2="3.302" y2="1.8034" width="0.1524" layer="51"/>
<wire x1="3.302" y1="1.8034" x2="3.302" y2="2.1082" width="0.1524" layer="51"/>
<wire x1="3.302" y1="2.1082" x2="2.2352" y2="2.1082" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="-2.54" x2="2.2352" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="-2.54" x2="2.2352" y2="2.54" width="0.1524" layer="51"/>
<wire x1="2.2352" y1="2.54" x2="-0.3048" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-0.3048" y1="2.54" x2="-2.2352" y2="2.54" width="0.1524" layer="51"/>
<wire x1="-2.2352" y1="2.54" x2="-2.2352" y2="-2.54" width="0.1524" layer="51"/>
<wire x1="0.3048" y1="2.54" x2="-0.3048" y2="2.54" width="0.1524" layer="51" curve="-180"/>
<wire x1="-2.3876" y1="-2.6924" x2="2.3876" y2="-2.6924" width="0.1524" layer="21"/>
<wire x1="2.3876" y1="-2.6924" x2="2.3876" y2="-2.4638" width="0.1524" layer="21"/>
<wire x1="2.3876" y1="2.6924" x2="-2.3876" y2="2.6924" width="0.1524" layer="21"/>
<wire x1="-2.3876" y1="2.6924" x2="-2.3876" y2="2.4638" width="0.1524" layer="21"/>
<wire x1="-2.3876" y1="-2.4638" x2="-2.3876" y2="-2.6924" width="0.1524" layer="21"/>
<wire x1="2.3876" y1="2.4638" x2="2.3876" y2="2.6924" width="0.1524" layer="21"/>
<wire x1="-0.254" y1="0" x2="0.254" y2="0" width="0.1524" layer="23"/>
<wire x1="0" y1="-0.254" x2="0" y2="0.254" width="0.1524" layer="23"/>
<wire x1="-3.937" y1="-2.54" x2="-2.54" y2="-2.54" width="0.127" layer="39" style="shortdash"/>
<wire x1="-2.54" y1="-2.54" x2="-2.54" y2="-2.794" width="0.127" layer="39" style="shortdash"/>
<wire x1="-3.937" y1="-2.54" x2="-3.937" y2="2.413" width="0.127" layer="39"/>
<wire x1="-3.937" y1="2.413" x2="-2.54" y2="2.413" width="0.127" layer="39"/>
<wire x1="-2.54" y1="2.413" x2="-2.54" y2="2.794" width="0.127" layer="39"/>
<wire x1="-2.54" y1="2.794" x2="2.54" y2="2.794" width="0.127" layer="39"/>
<wire x1="2.54" y1="2.794" x2="2.54" y2="2.413" width="0.127" layer="39"/>
<wire x1="2.54" y1="2.413" x2="3.937" y2="2.413" width="0.127" layer="39"/>
<wire x1="3.937" y1="2.413" x2="3.937" y2="-2.413" width="0.127" layer="39"/>
<wire x1="3.937" y1="-2.413" x2="2.54" y2="-2.413" width="0.127" layer="39"/>
<wire x1="2.54" y1="-2.413" x2="2.54" y2="-2.794" width="0.127" layer="39"/>
<wire x1="2.54" y1="-2.794" x2="-2.54" y2="-2.794" width="0.127" layer="39"/>
<text x="-3.2766" y="3.175" size="1.27" layer="25" ratio="6" rot="SR0">&gt;Name</text>
<circle x="-1.4986" y="1.9304" radius="0.127" width="0.254" layer="51"/>
</package>
<package name="SOT23" urn="urn:adsk.eagle:footprint:15704/1" library_version="70" library_locally_modified="yes">
<description>&lt;b&gt;SOT-23&lt;/b&gt;</description>
<wire x1="1.4224" y1="0.6604" x2="1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="1.4224" y1="-0.6604" x2="-1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="-0.6604" x2="-1.4224" y2="0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="0.6604" x2="1.4224" y2="0.6604" width="0.1524" layer="51"/>
<smd name="3" x="0" y="1.1" dx="1" dy="1.4" layer="1"/>
<smd name="2" x="0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<smd name="1" x="-0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.2286" y1="0.7112" x2="0.2286" y2="1.2954" layer="51"/>
<rectangle x1="0.7112" y1="-1.2954" x2="1.1684" y2="-0.7112" layer="51"/>
<rectangle x1="-1.1684" y1="-1.2954" x2="-0.7112" y2="-0.7112" layer="51"/>
</package>
<package name="1X02/90" urn="urn:adsk.eagle:footprint:22310/1" library_version="63" library_locally_modified="yes">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-2.54" y1="-1.905" x2="0" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="0" y1="-1.905" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="-2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-2.54" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="6.985" x2="-1.27" y2="1.27" width="0.762" layer="21"/>
<wire x1="0" y1="-1.905" x2="2.54" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-1.905" x2="2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.27" y1="6.985" x2="1.27" y2="1.27" width="0.762" layer="21"/>
<pad name="1" x="-1.27" y="-3.81" drill="1.016" shape="long" rot="R90"/>
<pad name="2" x="1.27" y="-3.81" drill="1.016" shape="long" rot="R90"/>
<text x="-3.175" y="-3.81" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="4.445" y="-3.81" size="1.27" layer="27" rot="R90">&gt;VALUE</text>
<rectangle x1="-1.651" y1="0.635" x2="-0.889" y2="1.143" layer="21"/>
<rectangle x1="0.889" y1="0.635" x2="1.651" y2="1.143" layer="21"/>
<rectangle x1="-1.651" y1="-2.921" x2="-0.889" y2="-1.905" layer="21"/>
<rectangle x1="0.889" y1="-2.921" x2="1.651" y2="-1.905" layer="21"/>
</package>
<package name="1X02" urn="urn:adsk.eagle:footprint:22309/1" library_version="63" library_locally_modified="yes">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-1.905" y1="1.27" x2="-0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="-0.635" x2="-0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-0.635" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="1.27" x2="1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="1.27" x2="2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-0.635" x2="1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<pad name="1" x="-1.27" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="2" x="1.27" y="0" drill="1.016" shape="long" rot="R90"/>
<text x="-2.6162" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-2.54" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.524" y1="-0.254" x2="-1.016" y2="0.254" layer="51"/>
<rectangle x1="1.016" y1="-0.254" x2="1.524" y2="0.254" layer="51"/>
</package>
<package name="1X03" urn="urn:adsk.eagle:footprint:22340/1" library_version="78">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-3.175" y1="1.27" x2="-1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-1.27" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-0.635" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="1.27" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.27" y1="0.635" x2="1.27" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-0.635" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="-0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="-1.27" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="0.635" x2="-3.81" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-0.635" x2="-3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-1.27" x2="-3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="1.27" y1="0.635" x2="1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="1.27" x2="3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="1.27" x2="3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="3.81" y1="0.635" x2="3.81" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-0.635" x2="3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-1.27" x2="1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="1.27" y2="-0.635" width="0.1524" layer="21"/>
<pad name="1" x="-2.54" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="2" x="0" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="3" x="2.54" y="0" drill="1.016" shape="long" rot="R90"/>
<text x="-3.8862" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-3.81" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="51"/>
<rectangle x1="-2.794" y1="-0.254" x2="-2.286" y2="0.254" layer="51"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="51"/>
</package>
<package name="1X03/90" urn="urn:adsk.eagle:footprint:22341/1" library_version="78">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="-3.81" y1="-1.905" x2="-1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-1.27" y1="0.635" x2="-3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="0.635" x2="-3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="6.985" x2="-2.54" y2="1.27" width="0.762" layer="21"/>
<wire x1="-1.27" y1="-1.905" x2="1.27" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="1.27" y1="0.635" x2="-1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="6.985" x2="0" y2="1.27" width="0.762" layer="21"/>
<wire x1="1.27" y1="-1.905" x2="3.81" y2="-1.905" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-1.905" x2="3.81" y2="0.635" width="0.1524" layer="21"/>
<wire x1="3.81" y1="0.635" x2="1.27" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="6.985" x2="2.54" y2="1.27" width="0.762" layer="21"/>
<pad name="1" x="-2.54" y="-3.81" drill="1.016" shape="long" rot="R90"/>
<pad name="2" x="0" y="-3.81" drill="1.016" shape="long" rot="R90"/>
<pad name="3" x="2.54" y="-3.81" drill="1.016" shape="long" rot="R90"/>
<text x="-4.445" y="-3.81" size="1.27" layer="25" ratio="10" rot="R90">&gt;NAME</text>
<text x="5.715" y="-3.81" size="1.27" layer="27" rot="R90">&gt;VALUE</text>
<rectangle x1="-2.921" y1="0.635" x2="-2.159" y2="1.143" layer="21"/>
<rectangle x1="-0.381" y1="0.635" x2="0.381" y2="1.143" layer="21"/>
<rectangle x1="2.159" y1="0.635" x2="2.921" y2="1.143" layer="21"/>
<rectangle x1="-2.921" y1="-2.921" x2="-2.159" y2="-1.905" layer="21"/>
<rectangle x1="-0.381" y1="-2.921" x2="0.381" y2="-1.905" layer="21"/>
<rectangle x1="2.159" y1="-2.921" x2="2.921" y2="-1.905" layer="21"/>
</package>
</packages>
<packages3d>
<package3d name="SOT223" urn="urn:adsk.eagle:package:10681910/3" type="model" library_version="64">
<description>&lt;b&gt;SOT-223&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="SOT223"/>
</packageinstances>
</package3d>
<package3d name="R0201" urn="urn:adsk.eagle:package:10736708/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt; chip&lt;p&gt;
Source: http://www.vishay.com/docs/20008/dcrcw.pdf</description>
<packageinstances>
<packageinstance name="R0201"/>
</packageinstances>
</package3d>
<package3d name="R0402" urn="urn:adsk.eagle:package:10736707/1" type="model" library_version="41">
<description>&lt;b&gt;Chip RESISTOR 0402 EIA (1005 Metric)&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R0402"/>
</packageinstances>
</package3d>
<package3d name="R0603" urn="urn:adsk.eagle:package:10736709/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R0603"/>
</packageinstances>
</package3d>
<package3d name="R0805" urn="urn:adsk.eagle:package:10736717/2" type="model" library_version="63">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;&lt;p&gt;</description>
<packageinstances>
<packageinstance name="R0805"/>
</packageinstances>
</package3d>
<package3d name="R1206" urn="urn:adsk.eagle:package:10736713/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R1206"/>
</packageinstances>
</package3d>
<package3d name="R1210" urn="urn:adsk.eagle:package:10736711/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R1210"/>
</packageinstances>
</package3d>
<package3d name="R2012" urn="urn:adsk.eagle:package:10736710/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R2012"/>
</packageinstances>
</package3d>
<package3d name="R2512" urn="urn:adsk.eagle:package:23545/2" type="model" library_version="41">
<description>RESISTOR</description>
<packageinstances>
<packageinstance name="R2512"/>
</packageinstances>
</package3d>
<package3d name="R3216" urn="urn:adsk.eagle:package:10736715/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R3216"/>
</packageinstances>
</package3d>
<package3d name="R3225" urn="urn:adsk.eagle:package:10736716/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R3225"/>
</packageinstances>
</package3d>
<package3d name="R4527" urn="urn:adsk.eagle:package:10736714/1" type="model" library_version="41">
<description>&lt;b&gt;Package 4527&lt;/b&gt;&lt;p&gt;
Source: http://www.vishay.com/docs/31059/wsrhigh.pdf</description>
<packageinstances>
<packageinstance name="R4527"/>
</packageinstances>
</package3d>
<package3d name="R5025" urn="urn:adsk.eagle:package:10736712/1" type="model" library_version="41">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="R5025"/>
</packageinstances>
</package3d>
<package3d name="R6332" urn="urn:adsk.eagle:package:23559/2" type="model" library_version="41">
<description>RESISTOR
Source: http://download.siliconexpert.com/pdfs/2005/02/24/Semi_Ap/2/VSH/Resistor/dcrcwfre.pdf</description>
<packageinstances>
<packageinstance name="R6332"/>
</packageinstances>
</package3d>
<package3d name="WSL_10G" urn="urn:adsk.eagle:package:10681399/5" type="model" library_version="71">
<description>&lt;b&gt;CONNECTOR&lt;/b&gt;&lt;p&gt;
series 057 contact pc board low profile headers&lt;p&gt;
straight</description>
<packageinstances>
<packageinstance name="WSL_10G"/>
</packageinstances>
</package3d>
<package3d name="2X05" urn="urn:adsk.eagle:package:22470/2" type="model" library_version="41">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="2X05"/>
</packageinstances>
</package3d>
<package3d name="2X05/90" urn="urn:adsk.eagle:package:22471/2" type="model" library_version="41">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="2X05/90"/>
</packageinstances>
</package3d>
<package3d name="2X05/JTAG" urn="urn:adsk.eagle:package:10681960/4" type="model" library_version="41">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="2X05/JTAG"/>
</packageinstances>
</package3d>
<package3d name="RN04" urn="urn:adsk.eagle:package:10682942/2" type="model" library_version="42">
<description>&lt;b&gt;RESISTOR NETWORK&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="RN04"/>
</packageinstances>
</package3d>
<package3d name="TQFP100" urn="urn:adsk.eagle:package:10682030/2" type="model" library_version="42">
<description>&lt;b&gt;100-lead Thin Quad Flat Pack Package Outline&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="TQFP100"/>
</packageinstances>
</package3d>
<package3d name="SM77H" urn="urn:adsk.eagle:package:12177396/1" type="box" library_version="77">
<description>&lt;b&gt;3.3V CMOS Clock Oscillator&lt;/b&gt;&lt;p&gt;
Source: www.pletronics.com .. sm77h%203.3v.pdf</description>
<packageinstances>
<packageinstance name="SM77H"/>
</packageinstances>
</package3d>
<package3d name="4POS_SCREWTERM_3.5MM" urn="urn:adsk.eagle:package:10723840/3" type="model" library_version="44">
<description>&lt;b&gt;MKDS 1/ 4-3,5&lt;/b&gt; Printklemme&lt;p&gt;
Nennstrom: 10 A&lt;br&gt;
Bemessungsspannung: 160 V&lt;br&gt;
Raster: 3,5 mm&lt;br&gt;
Polzahl: 4&lt;br&gt;
Montageart: Löten&lt;br&gt;
Anschlussart: Schraubanschluss&lt;br&gt;
Anschlussrichtung vom Leiter zur Platine: 0°&lt;br&gt;
Source: http://eshop.phoenixcontact.com .. 1751264.pdf</description>
<packageinstances>
<packageinstance name="SCREWTERM_4POS_3.5MM"/>
</packageinstances>
</package3d>
<package3d name="UD-4X5,8_NICHICON" urn="urn:adsk.eagle:package:10681681/3" type="model" library_version="77">
<description>&lt;b&gt;ALUMINUM ELECTROLYTIC CAPACITORS&lt;/b&gt; UD Series 4 x 5.8 mm&lt;p&gt;
Source: http://products.nichicon.co.jp/en/pdf/XJA043/e-ud.pdf</description>
<packageinstances>
<packageinstance name="UD-4X5,8_NICHICON"/>
</packageinstances>
</package3d>
<package3d name="UD-6,3X5,8_NICHICON" urn="urn:adsk.eagle:package:10681938/3" type="model" library_version="77">
<description>&lt;b&gt;ALUMINUM ELECTROLYTIC CAPACITORS&lt;/b&gt; UD Series 6.3 x 5.8 mm&lt;p&gt;
Source: http://products.nichicon.co.jp/en/pdf/XJA043/e-ud.pdf</description>
<packageinstances>
<packageinstance name="UD-6,3X5,8_NICHICON"/>
</packageinstances>
</package3d>
<package3d name="SO08" urn="urn:adsk.eagle:package:10681740/1" type="model" library_version="44">
<description>&lt;b&gt;Small Outline Package 8&lt;/b&gt;&lt;br&gt;
NS Package M08A</description>
<packageinstances>
<packageinstance name="SO08"/>
</packageinstances>
</package3d>
<package3d name="C0805" urn="urn:adsk.eagle:package:10736691/2" type="model" library_version="63" library_locally_modified="yes">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;</description>
<packageinstances>
<packageinstance name="C0805"/>
</packageinstances>
</package3d>
<package3d name="C0201" urn="urn:adsk.eagle:package:10736697/1" type="model" library_version="45">
<description>Source: http://www.avxcorp.com/docs/catalogs/cx5r.pdf</description>
<packageinstances>
<packageinstance name="C0201"/>
</packageinstances>
</package3d>
<package3d name="C0504" urn="urn:adsk.eagle:package:10736700/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C0504"/>
</packageinstances>
</package3d>
<package3d name="C0603" urn="urn:adsk.eagle:package:10736694/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C0603"/>
</packageinstances>
</package3d>
<package3d name="C1206" urn="urn:adsk.eagle:package:10736689/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1206"/>
</packageinstances>
</package3d>
<package3d name="C1210" urn="urn:adsk.eagle:package:10736698/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1210"/>
</packageinstances>
</package3d>
<package3d name="C1310" urn="urn:adsk.eagle:package:10736704/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1310"/>
</packageinstances>
</package3d>
<package3d name="C1608" urn="urn:adsk.eagle:package:10736695/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1608"/>
</packageinstances>
</package3d>
<package3d name="C1808" urn="urn:adsk.eagle:package:10736706/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<packageinstances>
<packageinstance name="C1808"/>
</packageinstances>
</package3d>
<package3d name="C1812" urn="urn:adsk.eagle:package:10736703/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1812"/>
</packageinstances>
</package3d>
<package3d name="C1825" urn="urn:adsk.eagle:package:10736696/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1825"/>
</packageinstances>
</package3d>
<package3d name="C2012" urn="urn:adsk.eagle:package:10736702/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C2012"/>
</packageinstances>
</package3d>
<package3d name="C3216" urn="urn:adsk.eagle:package:10736690/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C3216"/>
</packageinstances>
</package3d>
<package3d name="C3225" urn="urn:adsk.eagle:package:10736705/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C3225"/>
</packageinstances>
</package3d>
<package3d name="C3640" urn="urn:adsk.eagle:package:10736692/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<packageinstances>
<packageinstance name="C3640"/>
</packageinstances>
</package3d>
<package3d name="C4532" urn="urn:adsk.eagle:package:10736693/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C4532"/>
</packageinstances>
</package3d>
<package3d name="C4564" urn="urn:adsk.eagle:package:10736688/1" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C4564"/>
</packageinstances>
</package3d>
<package3d name="C0402" urn="urn:adsk.eagle:package:10724827/4" type="model" library_version="45">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C0402"/>
</packageinstances>
</package3d>
<package3d name="TO220" urn="urn:adsk.eagle:package:10682687/2" type="model" library_version="45">
<description>TO 220 horizontal</description>
<packageinstances>
<packageinstance name="TO220"/>
</packageinstances>
</package3d>
<package3d name="RASPBERRYPI_ZERO" urn="urn:adsk.eagle:package:10723842/6" type="box" library_version="74">
<description>Raspberry Pi board model B+, full outline with position of big connectors &amp;amp; drill holes</description>
<packageinstances>
<packageinstance name="RASPBERRYPI_ZERO"/>
</packageinstances>
</package3d>
<package3d name="VNH5019" urn="urn:adsk.eagle:package:10723836/6" type="box" library_version="66">
<packageinstances>
<packageinstance name="VNH5019"/>
</packageinstances>
</package3d>
<package3d name="BNO055" urn="urn:adsk.eagle:package:10723845/4" type="box" library_version="66">
<packageinstances>
<packageinstance name="BNO055"/>
</packageinstances>
</package3d>
<package3d name="PW14" urn="urn:adsk.eagle:package:10752475/3" type="model" library_version="58">
<packageinstances>
<packageinstance name="PW14"/>
</packageinstances>
</package3d>
<package3d name="SOT23" urn="urn:adsk.eagle:package:10831617/1" type="model" library_version="71">
<description>SOT-23</description>
<packageinstances>
<packageinstance name="SOT23"/>
</packageinstances>
</package3d>
<package3d name="1X02/90" urn="urn:adsk.eagle:package:22437/2" type="model" library_version="63" library_locally_modified="yes">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="1X02/90"/>
</packageinstances>
</package3d>
<package3d name="1X02" urn="urn:adsk.eagle:package:22435/2" type="model" library_version="63" library_locally_modified="yes">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="1X02"/>
</packageinstances>
</package3d>
<package3d name="1X03" urn="urn:adsk.eagle:package:22458/2" type="model" library_version="78">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="1X03"/>
</packageinstances>
</package3d>
<package3d name="1X03/90" urn="urn:adsk.eagle:package:22459/2" type="model" library_version="78">
<description>PIN HEADER</description>
<packageinstances>
<packageinstance name="1X03/90"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="NCP1117" urn="urn:adsk.eagle:symbol:10681909/1" library_version="36">
<wire x1="15.24" y1="5.08" x2="15.24" y2="-12.7" width="0.254" layer="94"/>
<wire x1="15.24" y1="-12.7" x2="-17.78" y2="-12.7" width="0.254" layer="94"/>
<wire x1="-17.78" y1="-12.7" x2="-17.78" y2="5.08" width="0.254" layer="94"/>
<wire x1="-17.78" y1="5.08" x2="15.24" y2="5.08" width="0.254" layer="94"/>
<pin name="GND" x="-2.54" y="-17.78" length="middle" rot="R90"/>
<pin name="5V" x="20.32" y="-2.54" length="middle" rot="R180"/>
<pin name="VIN" x="-22.86" y="-2.54" length="middle"/>
<text x="-17.78" y="-15.24" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="7.62" size="1.778" layer="96" rot="R180">&gt;VALUE</text>
</symbol>
<symbol name="R-EU" urn="urn:adsk.eagle:symbol:10724084/1" library_version="41">
<wire x1="-2.54" y1="-0.889" x2="2.54" y2="-0.889" width="0.254" layer="94"/>
<wire x1="2.54" y1="0.889" x2="-2.54" y2="0.889" width="0.254" layer="94"/>
<wire x1="2.54" y1="-0.889" x2="2.54" y2="0.889" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-0.889" x2="-2.54" y2="0.889" width="0.254" layer="94"/>
<text x="-3.81" y="1.4986" size="1.778" layer="95">&gt;NAME</text>
<text x="-3.81" y="-3.302" size="1.778" layer="96">&gt;VALUE</text>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
</symbol>
<symbol name="PINH2X5" urn="urn:adsk.eagle:symbol:10681959/1" library_version="41">
<wire x1="-6.35" y1="-7.62" x2="8.89" y2="-7.62" width="0.4064" layer="94"/>
<wire x1="8.89" y1="-7.62" x2="8.89" y2="7.62" width="0.4064" layer="94"/>
<wire x1="8.89" y1="7.62" x2="-6.35" y2="7.62" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="7.62" x2="-6.35" y2="-7.62" width="0.4064" layer="94"/>
<text x="-6.35" y="8.255" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-10.16" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="5.08" y="5.08" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="3" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="5.08" y="2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="5" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="6" x="5.08" y="0" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="7" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="8" x="5.08" y="-2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="9" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="10" x="5.08" y="-5.08" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
</symbol>
<symbol name="RN04" urn="urn:adsk.eagle:symbol:10682940/1" library_version="42">
<wire x1="-2.54" y1="1.27" x2="-2.54" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-1.27" x2="2.54" y2="-1.27" width="0.254" layer="94"/>
<wire x1="2.54" y1="-1.27" x2="2.54" y2="1.27" width="0.254" layer="94"/>
<wire x1="2.54" y1="1.27" x2="-2.54" y2="1.27" width="0.254" layer="94"/>
<text x="-2.54" y="2.54" size="1.778" layer="95">&gt;NAME</text>
<text x="-2.54" y="-4.318" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="pad" length="short" direction="pas"/>
<pin name="2" x="5.08" y="0" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="3" x="10.16" y="0" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="4" x="15.24" y="0" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="5" x="20.32" y="0" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="86-I/O-1" urn="urn:adsk.eagle:symbol:10682027/1" library_version="42">
<wire x1="-30.48" y1="78.74" x2="30.48" y2="78.74" width="0.254" layer="94"/>
<wire x1="30.48" y1="78.74" x2="30.48" y2="-76.2" width="0.254" layer="94"/>
<wire x1="30.48" y1="-76.2" x2="-30.48" y2="-76.2" width="0.254" layer="94"/>
<wire x1="-30.48" y1="-76.2" x2="-30.48" y2="78.74" width="0.254" layer="94"/>
<wire x1="10.16" y1="36.6713" x2="13.0175" y2="36.6713" width="0.127" layer="95"/>
<wire x1="19.685" y1="-72.5488" x2="22.7013" y2="-72.5488" width="0.127" layer="95"/>
<wire x1="19.8437" y1="-70.0088" x2="22.86" y2="-70.0088" width="0.127" layer="95"/>
<wire x1="-28.2575" y1="77.3113" x2="-21.2725" y2="77.3113" width="0.127" layer="95"/>
<text x="-30.48" y="-78.74" size="1.778" layer="96">&gt;VALUE</text>
<text x="-30.48" y="80.01" size="1.778" layer="95">&gt;NAME</text>
<text x="-28.0987" y="35.0838" size="1.524" layer="95">GND</text>
<text x="-28.0987" y="32.5438" size="1.524" layer="95">GND</text>
<text x="-28.0987" y="30.0038" size="1.524" layer="95">GND</text>
<text x="-28.0987" y="42.3863" size="1.524" layer="95">VCC</text>
<text x="-28.0987" y="44.9263" size="1.524" layer="95">VCC</text>
<text x="-28.0987" y="39.8463" size="1.524" layer="95">VCC</text>
<pin name="(A8)PC0" x="35.56" y="12.7" length="middle" rot="R180"/>
<pin name="(A9)PC1" x="35.56" y="15.24" length="middle" rot="R180"/>
<pin name="(A10)PC2" x="35.56" y="17.78" length="middle" rot="R180"/>
<pin name="(A11)PC3" x="35.56" y="20.32" length="middle" rot="R180"/>
<pin name="(A12)PC4" x="35.56" y="22.86" length="middle" rot="R180"/>
<pin name="(A13)PC5" x="35.56" y="25.4" length="middle" rot="R180"/>
<pin name="(A14)PC6" x="35.56" y="27.94" length="middle" rot="R180"/>
<pin name="(A15)PC7" x="35.56" y="30.48" length="middle" rot="R180"/>
<pin name="(AD0)PA0" x="35.56" y="58.42" length="middle" rot="R180"/>
<pin name="(AD1)PA1" x="35.56" y="60.96" length="middle" rot="R180"/>
<pin name="(AD2)PA2" x="35.56" y="63.5" length="middle" rot="R180"/>
<pin name="(AD3)PA3" x="35.56" y="66.04" length="middle" rot="R180"/>
<pin name="(AD4)PA4" x="35.56" y="68.58" length="middle" rot="R180"/>
<pin name="(AD5)PA5" x="35.56" y="71.12" length="middle" rot="R180"/>
<pin name="(AD6)PA6" x="35.56" y="73.66" length="middle" rot="R180"/>
<pin name="(AD7)PA7" x="35.56" y="76.2" length="middle" rot="R180"/>
<pin name="(ADC0)PF0" x="35.56" y="-55.88" length="middle" rot="R180"/>
<pin name="(ADC1)PF1" x="35.56" y="-53.34" length="middle" rot="R180"/>
<pin name="(ADC2)PF2" x="35.56" y="-50.8" length="middle" rot="R180"/>
<pin name="(ADC3)PF3" x="35.56" y="-48.26" length="middle" rot="R180"/>
<pin name="(ADC4/TCK)PF4" x="35.56" y="-45.72" length="middle" rot="R180"/>
<pin name="(ADC5/TMS)PF5" x="35.56" y="-43.18" length="middle" rot="R180"/>
<pin name="(ADC6/TDO)PF6" x="35.56" y="-40.64" length="middle" rot="R180"/>
<pin name="(ADC7/TDI)PF7" x="35.56" y="-38.1" length="middle" rot="R180"/>
<pin name="(ALE)PG2" x="35.56" y="-68.58" length="middle" rot="R180"/>
<pin name="(CLKO/ICP3/INT7)PE7" x="35.56" y="-15.24" length="middle" rot="R180"/>
<pin name="(ICP1)PD4" x="35.56" y="0" length="middle" rot="R180"/>
<pin name="(MISO/PCINT3)PB3" x="35.56" y="43.18" length="middle" rot="R180"/>
<pin name="(MOSI/PCINT2)PB2" x="35.56" y="40.64" length="middle" rot="R180"/>
<pin name="(OC0A/OC1C/PCINT7)PB7" x="35.56" y="53.34" length="middle" rot="R180"/>
<pin name="(OC0B)PG5" x="35.56" y="-60.96" length="middle" rot="R180"/>
<pin name="(OC1A/PCINT5)PB5" x="35.56" y="48.26" length="middle" rot="R180"/>
<pin name="(OC1B/PCINT6)PB6" x="35.56" y="50.8" length="middle" rot="R180"/>
<pin name="(OC2A/PCINT4)PB4" x="35.56" y="45.72" length="middle" rot="R180"/>
<pin name="(OC3A/AIN1)PE3" x="35.56" y="-25.4" length="middle" rot="R180"/>
<pin name="(OC3B/INT4)PE4" x="35.56" y="-22.86" length="middle" rot="R180"/>
<pin name="(OC3C/INT5)PE5" x="35.56" y="-20.32" length="middle" rot="R180"/>
<pin name="(RD)PG1" x="35.56" y="-71.12" length="middle" rot="R180"/>
<pin name="(RXD0/PCIN8)PE0" x="35.56" y="-33.02" length="middle" rot="R180"/>
<pin name="(RXD1/INT2)PD2" x="35.56" y="-5.08" length="middle" rot="R180"/>
<pin name="(SCK/PCINT1)PB1" x="35.56" y="38.1" length="middle" rot="R180"/>
<pin name="(SCL/INT0)PD0" x="35.56" y="-10.16" length="middle" rot="R180"/>
<pin name="(SDA/INT1)PD1" x="35.56" y="-7.62" length="middle" rot="R180"/>
<pin name="(SS/PCINT0)PB0" x="35.56" y="35.56" length="middle" rot="R180"/>
<pin name="(T0)PD7" x="35.56" y="7.62" length="middle" rot="R180"/>
<pin name="(T1)PD6" x="35.56" y="5.08" length="middle" rot="R180"/>
<pin name="(T3/INT6)PE6" x="35.56" y="-17.78" length="middle" rot="R180"/>
<pin name="(TOSC1)PG4" x="35.56" y="-63.5" length="middle" rot="R180"/>
<pin name="(TOSC2)PG3" x="35.56" y="-66.04" length="middle" rot="R180"/>
<pin name="(TXD0)PE1" x="35.56" y="-30.48" length="middle" rot="R180"/>
<pin name="(TXD1/INT3)PD3" x="35.56" y="-2.54" length="middle" rot="R180"/>
<pin name="(WR)PG0" x="35.56" y="-73.66" length="middle" rot="R180"/>
<pin name="(XCK0/AIN0)PE2" x="35.56" y="-27.94" length="middle" rot="R180"/>
<pin name="(XCK1)PD5" x="35.56" y="2.54" length="middle" rot="R180"/>
<pin name="AGND" x="-35.56" y="55.88" length="middle" direction="pwr"/>
<pin name="AREF" x="-35.56" y="60.96" length="middle"/>
<pin name="AVCC" x="-35.56" y="58.42" length="middle" direction="pwr"/>
<pin name="GND" x="-35.56" y="38.1" length="middle" direction="pwr"/>
<pin name="GND1" x="-35.56" y="35.56" visible="pad" length="middle" direction="pwr"/>
<pin name="GND2" x="-35.56" y="33.02" visible="pad" length="middle" direction="pwr"/>
<pin name="GND3" x="-35.56" y="30.48" visible="pad" length="middle" direction="pwr"/>
<pin name="PH0(RXD2)" x="-35.56" y="-73.66" length="middle"/>
<pin name="PH1(TXD2)" x="-35.56" y="-71.12" length="middle"/>
<pin name="PH2(XCK2)" x="-35.56" y="-68.58" length="middle"/>
<pin name="PH3(OC4A)" x="-35.56" y="-66.04" length="middle"/>
<pin name="PH4(OC4B)" x="-35.56" y="-63.5" length="middle"/>
<pin name="PH5(OC4C)" x="-35.56" y="-60.96" length="middle"/>
<pin name="PH6(OC2B)" x="-35.56" y="-58.42" length="middle"/>
<pin name="PH7(T4)" x="-35.56" y="-55.88" length="middle"/>
<pin name="PJ0(RXD3/PCINT9)" x="-35.56" y="-50.8" length="middle"/>
<pin name="PJ1(TXD3/PCINT10)" x="-35.56" y="-48.26" length="middle"/>
<pin name="PJ2(XCK3/PCINT11)" x="-35.56" y="-45.72" length="middle"/>
<pin name="PJ3(PCINT12)" x="-35.56" y="-43.18" length="middle"/>
<pin name="PJ4(PCINT13)" x="-35.56" y="-40.64" length="middle"/>
<pin name="PJ5(PCINT14)" x="-35.56" y="-38.1" length="middle"/>
<pin name="PJ6(PCINT15)" x="-35.56" y="-35.56" length="middle"/>
<pin name="PJ7" x="-35.56" y="-33.02" length="middle"/>
<pin name="PK0(ADC8/PCINT16)" x="-35.56" y="-27.94" length="middle"/>
<pin name="PK1(ADC9/PCINT17)" x="-35.56" y="-25.4" length="middle"/>
<pin name="PK2(ADC10/PCINT18)" x="-35.56" y="-22.86" length="middle"/>
<pin name="PK3(ADC11/PCINT19)" x="-35.56" y="-20.32" length="middle"/>
<pin name="PK4(ADC12/PCINT20)" x="-35.56" y="-17.78" length="middle"/>
<pin name="PK5(ADC13/PCINT21)" x="-35.56" y="-15.24" length="middle"/>
<pin name="PK6(ADC14/PCINT22)" x="-35.56" y="-12.7" length="middle"/>
<pin name="PK7(ADC15/PCINT23)" x="-35.56" y="-10.16" length="middle"/>
<pin name="PL0(ICP4)" x="-35.56" y="-5.08" length="middle"/>
<pin name="PL1(ICP5)" x="-35.56" y="-2.54" length="middle"/>
<pin name="PL2(T5)" x="-35.56" y="0" length="middle"/>
<pin name="PL3(OC5A)" x="-35.56" y="2.54" length="middle"/>
<pin name="PL4(OC5B)" x="-35.56" y="5.08" length="middle"/>
<pin name="PL5(OC5C)" x="-35.56" y="7.62" length="middle"/>
<pin name="PL6" x="-35.56" y="10.16" length="middle"/>
<pin name="PL7" x="-35.56" y="12.7" length="middle"/>
<pin name="RESET" x="-35.56" y="76.2" length="middle" direction="in" function="dot"/>
<pin name="VCC" x="-35.56" y="48.26" length="middle" direction="pwr"/>
<pin name="VCC1" x="-35.56" y="45.72" visible="pad" length="middle" direction="pwr"/>
<pin name="VCC2" x="-35.56" y="43.18" visible="pad" length="middle" direction="pwr"/>
<pin name="VCC3" x="-35.56" y="40.64" visible="pad" length="middle" direction="pwr"/>
<pin name="XTAL1" x="-35.56" y="66.04" length="middle" direction="in"/>
<pin name="XTAL2" x="-35.56" y="71.12" length="middle" direction="out"/>
</symbol>
<symbol name="SM77H" urn="urn:adsk.eagle:symbol:10682028/1" library_version="42">
<wire x1="-7.62" y1="5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="0.762" y1="-1.27" x2="1.778" y2="-1.27" width="0.1016" layer="94"/>
<wire x1="1.778" y1="-1.27" x2="1.778" y2="-0.381" width="0.1016" layer="94"/>
<wire x1="1.778" y1="-1.27" x2="1.778" y2="-2.159" width="0.1016" layer="94"/>
<wire x1="2.286" y1="-0.635" x2="2.794" y2="-0.635" width="0.1016" layer="94"/>
<wire x1="2.794" y1="-0.635" x2="2.794" y2="-1.905" width="0.1016" layer="94"/>
<wire x1="2.794" y1="-1.905" x2="2.286" y2="-1.905" width="0.1016" layer="94"/>
<wire x1="2.286" y1="-1.905" x2="2.286" y2="-0.635" width="0.1016" layer="94"/>
<wire x1="4.318" y1="-1.27" x2="3.302" y2="-1.27" width="0.1016" layer="94"/>
<wire x1="3.302" y1="-1.27" x2="3.302" y2="-2.159" width="0.1016" layer="94"/>
<wire x1="3.302" y1="-1.27" x2="3.302" y2="-0.381" width="0.1016" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="E/D" x="-10.16" y="0" length="short" direction="in"/>
<pin name="VCC" x="-10.16" y="2.54" length="short" direction="pwr"/>
<pin name="GND" x="-10.16" y="-2.54" length="short" direction="pwr"/>
<pin name="OUT" x="10.16" y="2.54" length="short" direction="out" rot="R180"/>
</symbol>
<symbol name="PINHD4" urn="urn:adsk.eagle:symbol:10681958/1" library_version="42">
<wire x1="-6.35" y1="-5.08" x2="1.27" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-5.08" x2="1.27" y2="7.62" width="0.4064" layer="94"/>
<wire x1="1.27" y1="7.62" x2="-6.35" y2="7.62" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="7.62" x2="-6.35" y2="-5.08" width="0.4064" layer="94"/>
<text x="-6.35" y="8.255" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="3" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
</symbol>
<symbol name="CPOL" urn="urn:adsk.eagle:symbol:10681680/1" library_version="44">
<wire x1="-1.524" y1="-0.889" x2="1.524" y2="-0.889" width="0.254" layer="94"/>
<wire x1="1.524" y1="-0.889" x2="1.524" y2="0" width="0.254" layer="94"/>
<wire x1="-1.524" y1="0" x2="-1.524" y2="-0.889" width="0.254" layer="94"/>
<wire x1="-1.524" y1="0" x2="1.524" y2="0" width="0.254" layer="94"/>
<text x="1.143" y="0.4826" size="1.778" layer="95">&gt;NAME</text>
<text x="-0.5842" y="0.4064" size="1.27" layer="94" rot="R90">+</text>
<text x="1.143" y="-4.5974" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-1.651" y1="-2.54" x2="1.651" y2="-1.651" layer="94"/>
<pin name="-" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="+" x="0" y="2.54" visible="off" length="short" direction="pas" rot="R270"/>
</symbol>
<symbol name="LM385-1.2" urn="urn:adsk.eagle:symbol:11072098/1" library_version="76">
<description>Adjustable Micropower Voltage References</description>
<wire x1="-12.7" y1="10.16" x2="10.16" y2="10.16" width="0.254" layer="94"/>
<wire x1="10.16" y1="10.16" x2="10.16" y2="-10.16" width="0.254" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="-12.7" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-12.7" y1="10.16" x2="-12.7" y2="-10.16" width="0.254" layer="94"/>
<text x="-2.54" y="12.7" size="1.778" layer="95" rot="R180">&gt;NAME</text>
<text x="-10.16" y="-12.7" size="1.778" layer="96">&gt;VALUE</text>
<pin name="NC1" x="-15.24" y="7.62" length="middle" direction="nc"/>
<pin name="NC2" x="-15.24" y="2.54" length="middle" direction="nc"/>
<pin name="NC3" x="-15.24" y="-2.54" length="middle" direction="nc"/>
<pin name="NG" x="-15.24" y="-7.62" length="middle"/>
<pin name="NC6" x="12.7" y="-7.62" length="middle" direction="nc" rot="R180"/>
<pin name="NC5" x="12.7" y="-2.54" length="middle" direction="nc" rot="R180"/>
<pin name="NC4" x="12.7" y="2.54" length="middle" direction="nc" rot="R180"/>
<pin name="POS" x="12.7" y="7.62" length="middle" rot="R180"/>
</symbol>
<symbol name="OPAMP" urn="urn:adsk.eagle:symbol:10681716/1" library_version="44">
<wire x1="-5.08" y1="5.08" x2="-5.08" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="-5.08" y1="-5.08" x2="5.08" y2="0" width="0.4064" layer="94"/>
<wire x1="5.08" y1="0" x2="-5.08" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-3.81" y1="3.175" x2="-3.81" y2="1.905" width="0.1524" layer="94"/>
<wire x1="-4.445" y1="2.54" x2="-3.175" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-4.445" y1="-2.54" x2="-3.175" y2="-2.54" width="0.1524" layer="94"/>
<text x="2.54" y="3.175" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="-IN" x="-7.62" y="-2.54" visible="pad" length="short" direction="in"/>
<pin name="+IN" x="-7.62" y="2.54" visible="pad" length="short" direction="in"/>
<pin name="OUT" x="7.62" y="0" visible="pad" length="short" direction="out" rot="R180"/>
</symbol>
<symbol name="PWR+-" urn="urn:adsk.eagle:symbol:10681715/1" library_version="44">
<text x="1.27" y="3.175" size="0.8128" layer="93" rot="R90">V+</text>
<text x="1.27" y="-4.445" size="0.8128" layer="93" rot="R90">V-</text>
<pin name="V+" x="0" y="7.62" visible="pad" length="middle" direction="pwr" rot="R270"/>
<pin name="V-" x="0" y="-7.62" visible="pad" length="middle" direction="pwr" rot="R90"/>
</symbol>
<symbol name="C-EU" urn="urn:adsk.eagle:symbol:10724083/1" library_version="45">
<wire x1="0" y1="0" x2="0" y2="-0.508" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<text x="1.524" y="0.381" size="1.778" layer="95">&gt;NAME</text>
<text x="1.524" y="-4.699" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-2.032" y1="-2.032" x2="2.032" y2="-1.524" layer="94"/>
<rectangle x1="-2.032" y1="-1.016" x2="2.032" y2="-0.508" layer="94"/>
<pin name="1" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="IGFET-EN-GDS" urn="urn:adsk.eagle:symbol:10682686/1" library_version="45">
<wire x1="-2.54" y1="-2.54" x2="-1.2192" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="0.762" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-0.762" width="0.254" layer="94"/>
<wire x1="0" y1="3.683" x2="0" y2="1.397" width="0.254" layer="94"/>
<wire x1="1.905" y1="0.635" x2="0.635" y2="0" width="0.254" layer="94"/>
<wire x1="1.905" y1="-0.635" x2="0.635" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="0.635" y2="0" width="0.1524" layer="94"/>
<wire x1="0.635" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-1.397" x2="0" y2="-3.683" width="0.254" layer="94"/>
<wire x1="-1.143" y1="2.54" x2="-1.143" y2="-2.54" width="0.254" layer="94"/>
<text x="-11.43" y="0" size="1.778" layer="96">&gt;VALUE</text>
<text x="-11.43" y="2.54" size="1.778" layer="95">&gt;NAME</text>
<pin name="D" x="5.08" y="2.54" visible="off" length="middle" direction="pas" rot="R180"/>
<pin name="S" x="5.08" y="-2.54" visible="off" length="middle" direction="pas" rot="R180"/>
<pin name="G" x="-5.08" y="-2.54" visible="off" length="short" direction="pas"/>
</symbol>
<symbol name="RPI-ZERO" urn="urn:adsk.eagle:symbol:10723816/4" library_version="63" library_locally_modified="yes">
<wire x1="-20.32" y1="33.02" x2="22.86" y2="33.02" width="0.254" layer="94"/>
<wire x1="22.86" y1="33.02" x2="22.86" y2="-27.94" width="0.254" layer="94"/>
<wire x1="22.86" y1="-27.94" x2="-20.32" y2="-27.94" width="0.254" layer="94"/>
<wire x1="-20.32" y1="-27.94" x2="-20.32" y2="33.02" width="0.254" layer="94"/>
<pin name="5V0@1" x="25.4" y="30.48" length="short" direction="sup" rot="R180"/>
<pin name="3V3@1" x="-22.86" y="30.48" length="short"/>
<pin name="GPIO2/SDA1" x="-22.86" y="27.94" length="short"/>
<pin name="5V0@2" x="25.4" y="27.94" length="short" direction="sup" rot="R180"/>
<pin name="GPIO3/SCL1" x="-22.86" y="25.4" length="short"/>
<pin name="GND@8" x="25.4" y="25.4" length="short" direction="sup" rot="R180"/>
<pin name="GPIO4/GCKL" x="-22.86" y="22.86" length="short"/>
<pin name="TXD0/GPIO14" x="25.4" y="22.86" length="short" rot="R180"/>
<pin name="GND@1" x="-22.86" y="20.32" length="short" direction="sup"/>
<pin name="RXD0/GPIO15" x="25.4" y="20.32" length="short" rot="R180"/>
<pin name="GPIO17/GEN0" x="-22.86" y="17.78" length="short"/>
<pin name="GPIO18" x="25.4" y="17.78" length="short" rot="R180"/>
<pin name="GPIO27/GEN2" x="-22.86" y="15.24" length="short"/>
<pin name="GND@4" x="25.4" y="15.24" length="short" direction="sup" rot="R180"/>
<pin name="GPIO22/GEN3" x="-22.86" y="12.7" length="short"/>
<pin name="GEN4/GPIO23" x="25.4" y="12.7" length="short" rot="R180"/>
<pin name="3V3@2" x="-22.86" y="10.16" length="short"/>
<pin name="GEN5/GPIO24" x="25.4" y="10.16" length="short" rot="R180"/>
<pin name="GPIO10/MOSI" x="-22.86" y="7.62" length="short"/>
<pin name="GND@5" x="25.4" y="7.62" length="short" direction="sup" rot="R180"/>
<pin name="GPIO9/MISO" x="-22.86" y="5.08" length="short"/>
<pin name="GEN/6GPIO25" x="25.4" y="5.08" length="short" rot="R180"/>
<pin name="GPIO11/SCLK" x="-22.86" y="2.54" length="short"/>
<pin name="!CE0!/GPIO8" x="25.4" y="2.54" length="short" rot="R180"/>
<pin name="GND@2" x="-22.86" y="0" length="short" direction="sup"/>
<pin name="!CE!/GPIO7" x="25.4" y="0" length="short" rot="R180"/>
<pin name="ID_SD" x="-22.86" y="-2.54" length="short"/>
<pin name="ID_SC" x="25.4" y="-2.54" length="short" rot="R180"/>
<pin name="GPIO5" x="-22.86" y="-5.08" length="short"/>
<pin name="GND@6" x="25.4" y="-5.08" length="short" direction="sup" rot="R180"/>
<pin name="GPIO6" x="-22.86" y="-7.62" length="short"/>
<pin name="GPIO12" x="25.4" y="-7.62" length="short" rot="R180"/>
<pin name="GPIO13" x="-22.86" y="-10.16" length="short"/>
<pin name="GND@7" x="25.4" y="-10.16" length="short" direction="sup" rot="R180"/>
<pin name="GPIO19" x="-22.86" y="-12.7" length="short"/>
<pin name="GPIO16" x="25.4" y="-12.7" length="short" rot="R180"/>
<pin name="GPIO26" x="-22.86" y="-15.24" length="short"/>
<pin name="GPIO20" x="25.4" y="-15.24" length="short" rot="R180"/>
<pin name="GND@3" x="-22.86" y="-17.78" length="short" direction="sup"/>
<pin name="GPIO21" x="25.4" y="-17.78" length="short" rot="R180"/>
<text x="-20.32" y="35.56" size="1.27" layer="95" font="vector">&gt;NAME</text>
<text x="-20.32" y="33.655" size="1.27" layer="96" font="vector">&gt;VALUE</text>
</symbol>
<symbol name="VNH5019" urn="urn:adsk.eagle:symbol:10740377/1" library_version="49">
<description>VHN5019</description>
<pin name="VIN@1" x="-15.24" y="10.16" length="middle"/>
<pin name="VIN@2" x="-15.24" y="7.62" length="middle"/>
<pin name="GND@3" x="-15.24" y="5.08" length="middle"/>
<pin name="GND@4" x="-15.24" y="2.54" length="middle"/>
<pin name="OUTB@5" x="-15.24" y="0" length="middle"/>
<pin name="OUTB@6" x="-15.24" y="-2.54" length="middle"/>
<pin name="OUTA@7" x="-15.24" y="-5.08" length="middle"/>
<pin name="OUTA@8" x="-15.24" y="-7.62" length="middle"/>
<pin name="INA@9" x="12.7" y="-7.62" length="middle" rot="R180"/>
<pin name="ENA@10" x="12.7" y="-5.08" length="middle" rot="R180"/>
<pin name="PWM@11" x="12.7" y="-2.54" length="middle" rot="R180"/>
<pin name="CS@12" x="12.7" y="0" length="middle" rot="R180"/>
<pin name="ENB@13" x="12.7" y="2.54" length="middle" rot="R180"/>
<pin name="INB@14" x="12.7" y="5.08" length="middle" rot="R180"/>
<pin name="VDD@15" x="12.7" y="7.62" length="middle" rot="R180"/>
<pin name="GND@16" x="12.7" y="10.16" length="middle" rot="R180"/>
<pin name="VOUT@17" x="12.7" y="12.7" length="middle" rot="R180"/>
<pin name="GND@18" x="12.7" y="15.24" length="middle" rot="R180"/>
<wire x1="-12.7" y1="-10.16" x2="-12.7" y2="17.78" width="0.254" layer="94"/>
<wire x1="-12.7" y1="17.78" x2="10.16" y2="17.78" width="0.254" layer="94"/>
<wire x1="10.16" y1="17.78" x2="10.16" y2="-10.16" width="0.254" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="-12.7" y2="-10.16" width="0.254" layer="94"/>
<text x="-5.08" y="20.32" size="1.778" layer="95" rot="R180">&gt;NAME</text>
<text x="-12.7" y="-12.7" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="N-MOS" urn="urn:adsk.eagle:symbol:10681852/1" library_version="51">
<wire x1="-1.27" y1="0" x2="-0.254" y2="0.381" width="0.1524" layer="94"/>
<wire x1="-0.254" y1="0.381" x2="-0.254" y2="-0.381" width="0.1524" layer="94"/>
<wire x1="-0.254" y1="-0.381" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0" x2="-1.016" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.016" y1="0" x2="-0.889" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.889" y1="0" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.032" x2="0" y2="-2.794" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="0" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="-2.54" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="3.048" x2="1.27" y2="3.048" width="0.1524" layer="94"/>
<wire x1="1.27" y1="3.048" x2="1.27" y2="0.762" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.762" x2="1.27" y2="0.508" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.508" x2="1.27" y2="-2.794" width="0.1524" layer="94"/>
<wire x1="1.27" y1="-2.794" x2="0" y2="-2.794" width="0.1524" layer="94"/>
<wire x1="1.778" y1="0" x2="0.762" y2="0" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0" x2="1.27" y2="0.762" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.762" x2="1.778" y2="0" width="0.1524" layer="94"/>
<wire x1="1.778" y1="0.762" x2="0.762" y2="0.762" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="2.032" x2="0" y2="2.032" width="0.1524" layer="94"/>
<wire x1="0" y1="2.032" x2="0" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="-2.032" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="-1.016" y1="0" x2="-0.381" y2="-0.254" width="0.254" layer="94"/>
<wire x1="-0.381" y1="-0.254" x2="-0.381" y2="0.254" width="0.254" layer="94"/>
<wire x1="-0.381" y1="0.254" x2="-0.889" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0.508" x2="1.016" y2="0.127" width="0.254" layer="94"/>
<wire x1="1.016" y1="0.127" x2="1.524" y2="0.127" width="0.254" layer="94"/>
<wire x1="1.524" y1="0.127" x2="1.27" y2="0.508" width="0.254" layer="94"/>
<circle x="0" y="-2.794" radius="0.3592" width="0" layer="94"/>
<circle x="0" y="-2.032" radius="0.3592" width="0" layer="94"/>
<circle x="0" y="3.048" radius="0.3592" width="0" layer="94"/>
<text x="2.54" y="0" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-2.032" y1="1.27" x2="-1.524" y2="2.54" layer="94"/>
<rectangle x1="-2.032" y1="-2.54" x2="-1.524" y2="-1.27" layer="94"/>
<rectangle x1="-2.032" y1="-0.762" x2="-1.524" y2="0.762" layer="94"/>
<pin name="G" x="-5.08" y="-2.54" visible="off" length="short" direction="pas"/>
<pin name="D" x="0" y="5.08" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="S" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
</symbol>
<symbol name="BNO055" urn="urn:adsk.eagle:symbol:10749271/2" library_version="54">
<pin name="RST@6" x="-15.24" y="-5.08" length="middle"/>
<pin name="SCL@5" x="-15.24" y="-2.54" length="middle"/>
<pin name="SDA@4" x="-15.24" y="0" length="middle"/>
<pin name="GND@3" x="-15.24" y="2.54" length="middle"/>
<pin name="3VO@2" x="-15.24" y="5.08" length="middle"/>
<pin name="VIN@1" x="-15.24" y="7.62" length="middle"/>
<pin name="ADR@7" x="15.24" y="-5.08" length="middle" rot="R180"/>
<pin name="INT@8" x="15.24" y="-2.54" length="middle" rot="R180"/>
<pin name="PS1@9" x="15.24" y="0" length="middle" rot="R180"/>
<pin name="PS0@10" x="15.24" y="2.54" length="middle" rot="R180"/>
<wire x1="-12.7" y1="-7.62" x2="-12.7" y2="10.16" width="0.254" layer="94"/>
<wire x1="-12.7" y1="10.16" x2="12.7" y2="10.16" width="0.254" layer="94"/>
<wire x1="12.7" y1="10.16" x2="12.7" y2="-7.62" width="0.254" layer="94"/>
<wire x1="12.7" y1="-7.62" x2="-12.7" y2="-7.62" width="0.254" layer="94"/>
<text x="-5.08" y="12.7" size="1.778" layer="95" rot="R180">&gt;NAME</text>
<text x="-12.7" y="-10.16" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="TXB0104PWR" urn="urn:adsk.eagle:symbol:10752465/3" library_version="64">
<pin name="VCCA" x="-27.94" y="7.62" length="middle" direction="pwr"/>
<pin name="A1" x="-27.94" y="5.08" length="middle"/>
<pin name="A2" x="-27.94" y="2.54" length="middle"/>
<pin name="A3" x="-27.94" y="0" length="middle"/>
<pin name="A4" x="-27.94" y="-2.54" length="middle"/>
<pin name="NC_2" x="-27.94" y="-5.08" length="middle" direction="nc"/>
<pin name="GND" x="-27.94" y="-7.62" length="middle" direction="pwr"/>
<pin name="OE" x="27.94" y="-7.62" length="middle" rot="R180"/>
<pin name="NC" x="27.94" y="-5.08" length="middle" direction="nc" rot="R180"/>
<pin name="B4" x="27.94" y="-2.54" length="middle" rot="R180"/>
<pin name="B3" x="27.94" y="0" length="middle" rot="R180"/>
<pin name="B2" x="27.94" y="2.54" length="middle" rot="R180"/>
<pin name="B1" x="27.94" y="5.08" length="middle" rot="R180"/>
<pin name="VCCB" x="27.94" y="7.62" length="middle" direction="pwr" rot="R180"/>
<wire x1="-22.86" y1="12.7" x2="-22.86" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="-22.86" y1="-12.7" x2="22.86" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="22.86" y1="-12.7" x2="22.86" y2="12.7" width="0.1524" layer="94"/>
<wire x1="22.86" y1="12.7" x2="-22.86" y2="12.7" width="0.1524" layer="94"/>
<wire x1="22.86" y1="6.35" x2="12.7" y2="6.35" width="0.127" layer="97" style="shortdash"/>
<wire x1="12.7" y1="6.35" x2="12.7" y2="-3.81" width="0.127" layer="97" style="shortdash"/>
<wire x1="12.7" y1="-3.81" x2="22.86" y2="-3.81" width="0.127" layer="97" style="shortdash"/>
<wire x1="-22.86" y1="6.35" x2="-12.7" y2="6.35" width="0.127" layer="97" style="shortdash"/>
<wire x1="-12.7" y1="6.35" x2="-12.7" y2="-3.81" width="0.127" layer="97" style="shortdash"/>
<wire x1="-12.7" y1="-3.81" x2="-22.86" y2="-3.81" width="0.127" layer="97" style="shortdash"/>
<text x="-22.5044" y="14.1986" size="2.0828" layer="95" ratio="6" rot="SR0">&gt;Name</text>
<text x="-23.1394" y="-16.2814" size="2.0828" layer="96" ratio="6" rot="SR0">&gt;Value</text>
<text x="-13.97" y="-1.27" size="1.016" layer="97" ratio="6" rot="R90">1.2-3.6V</text>
<text x="13.97" y="5.08" size="1.016" layer="97" ratio="6" rot="R270">1.65-5.5V</text>
</symbol>
<symbol name="SDD_AKAK" urn="urn:adsk.eagle:symbol:10681392/1" library_version="63">
<wire x1="-3.81" y1="-1.27" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.27" y1="0" x2="-3.81" y2="1.27" width="0.254" layer="94"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="0" width="0.254" layer="94"/>
<wire x1="-3.81" y1="0" x2="-3.81" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="1.27" x2="3.81" y2="0" width="0.254" layer="94"/>
<wire x1="3.81" y1="0" x2="1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="-1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="-0.635" y1="1.016" x2="-0.635" y2="1.27" width="0.254" layer="94"/>
<wire x1="-0.635" y1="1.27" x2="-1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.905" y1="-1.016" x2="-1.905" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-1.27" y1="-1.27" x2="-1.905" y2="-1.27" width="0.254" layer="94"/>
<wire x1="3.175" y1="-1.016" x2="3.175" y2="-1.27" width="0.254" layer="94"/>
<wire x1="3.175" y1="-1.27" x2="3.81" y2="-1.27" width="0.254" layer="94"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="0" width="0.254" layer="94"/>
<wire x1="4.445" y1="1.016" x2="4.445" y2="1.27" width="0.254" layer="94"/>
<wire x1="3.81" y1="0" x2="3.81" y2="1.27" width="0.254" layer="94"/>
<wire x1="3.81" y1="1.27" x2="4.445" y2="1.27" width="0.254" layer="94"/>
<wire x1="-1.27" y1="0" x2="1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-5.08" y1="0" x2="-3.81" y2="0" width="0.1524" layer="94"/>
<wire x1="3.81" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<circle x="0" y="0" radius="0.127" width="0.4064" layer="94"/>
<text x="0.762" y="2.0066" size="1.778" layer="95">&gt;NAME</text>
<text x="-4.318" y="-3.9624" size="1.778" layer="96">&gt;VALUE</text>
<pin name="A1" x="-5.08" y="0" visible="off" length="point" direction="pas"/>
<pin name="C2" x="5.08" y="0" visible="off" length="point" direction="pas" rot="R180"/>
<pin name="C1A2" x="0" y="2.54" visible="off" length="short" direction="pas" rot="R270"/>
</symbol>
<symbol name="PINHD2" urn="urn:adsk.eagle:symbol:10682845/1" library_version="63" library_locally_modified="yes">
<wire x1="-6.35" y1="-2.54" x2="1.27" y2="-2.54" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="1.27" y2="5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="5.08" x2="-6.35" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="5.08" x2="-6.35" y2="-2.54" width="0.4064" layer="94"/>
<text x="-6.35" y="5.715" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
</symbol>
<symbol name="PINHD3" urn="urn:adsk.eagle:symbol:12237006/1" library_version="78">
<wire x1="-6.35" y1="-5.08" x2="1.27" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-5.08" x2="1.27" y2="5.08" width="0.4064" layer="94"/>
<wire x1="1.27" y1="5.08" x2="-6.35" y2="5.08" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="5.08" x2="-6.35" y2="-5.08" width="0.4064" layer="94"/>
<text x="-6.35" y="5.715" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="3" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="NCP1117" urn="urn:adsk.eagle:component:10681928/5" prefix="P" library_version="76">
<description>&lt;b&gt;Voltage Regulator&lt;/b&gt;&lt;p&gt;
NCP1117&lt;p&gt;
1.0A 5.0V Low-Dropout Positive Fixed and Adjustable Voltage Regulators&lt;p&gt;
ON Semiconductor</description>
<gates>
<gate name="P$1" symbol="NCP1117" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT223">
<connects>
<connect gate="P$1" pin="5V" pad="2 4"/>
<connect gate="P$1" pin="GND" pad="1"/>
<connect gate="P$1" pin="VIN" pad="3"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681910/3"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.mouser.de/datasheet/2/308/NCP1117-D-81326.pdf" constant="no"/>
<attribute name="DESCR" value="LDO Voltage Regulators 5.0V 1A Positive - SOT-223-3" constant="no"/>
<attribute name="FARNELL_NO" value="2112617" constant="no"/>
<attribute name="MF" value="ON Semiconductor" constant="no"/>
<attribute name="MF_PN" value="NCP1117ST50T3G" constant="no"/>
<attribute name="MOUSER_NO" value="863-NCP1117ST50T3G" constant="no"/>
<attribute name="PACKAGE" value="SOT-223-3" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/on-semiconductor/ncp1117st50t3g/ldo-reg-15vin-1a-5v-1-3sot223/dp/2112617" constant="no"/>
<attribute name="UNIT_PRICE" value="0.41" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="R-EU" urn="urn:adsk.eagle:component:10724828/7" prefix="R" uservalue="yes" library_version="70">
<description>&lt;b&gt;Resistor&lt;/b&gt;&lt;p&gt;
European Symbol&lt;p&gt;

&lt;p&gt;
The shape and size of surface mount devices are standardized, most manufacturers use the JEDEC standards. The size of SMD capacitors/resistors is indicated by a numerical code, such as 0603. This code contains the width and height of the package. So in the example of 0603 Imperial code, this indicates a length of 0.060″ and a width of 0.030″. This code can be given in Imperial or Metric units.&lt;br&gt;&amp;nbsp;
&lt;img src="http://www.resistorguide.com/pictures/resistor-sizes.png" alt="" title="" width="350"&gt;
&lt;/p&gt;

&lt;table class="CSSTable" style="margin: 0px auto;"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td colspan="2"&gt;Code&lt;/td&gt;
&lt;td colspan="2"&gt;Length (l)&lt;/td&gt;
&lt;td colspan="2"&gt;Width (w)&lt;/td&gt;
&lt;td colspan="2"&gt;Height (h)&lt;/td&gt;
&lt;td&gt;Power&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td bgcolor="#CBD9EC"&gt;Imperial&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;Metric&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;Watt&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0201&lt;/td&gt;
&lt;td&gt;0603&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;0.012&lt;/td&gt;
&lt;td&gt;0.3&lt;/td&gt;
&lt;td&gt;0.01&lt;/td&gt;
&lt;td&gt;0.25&lt;/td&gt;
&lt;td&gt;1/20 (0.05)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0402&lt;/td&gt;
&lt;td&gt;1005&lt;/td&gt;
&lt;td&gt;0.04&lt;/td&gt;
&lt;td&gt;1.0&lt;/td&gt;
&lt;td&gt;0.02&lt;/td&gt;
&lt;td&gt;0.5&lt;/td&gt;
&lt;td&gt;0.014&lt;/td&gt;
&lt;td&gt;0.35&lt;/td&gt;
&lt;td&gt;1/16 (0.062)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0603&lt;/td&gt;
&lt;td&gt;1608&lt;/td&gt;
&lt;td&gt;0.06&lt;/td&gt;
&lt;td&gt;1.55&lt;/td&gt;
&lt;td&gt;0.03&lt;/td&gt;
&lt;td&gt;0.85&lt;/td&gt;
&lt;td&gt;0.018&lt;/td&gt;
&lt;td&gt;0.45&lt;/td&gt;
&lt;td&gt;1/10 (0.10)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0805&lt;/td&gt;
&lt;td&gt;2012&lt;/td&gt;
&lt;td&gt;0.08&lt;/td&gt;
&lt;td&gt;2.0&lt;/td&gt;
&lt;td&gt;0.05&lt;/td&gt;
&lt;td&gt;1.2&lt;/td&gt;
&lt;td&gt;0.018&lt;/td&gt;
&lt;td&gt;0.45&lt;/td&gt;
&lt;td&gt;1/8 (0.125)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1206&lt;/td&gt;
&lt;td&gt;3216&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.06&lt;/td&gt;
&lt;td&gt;1.6&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1/4 (0.25)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1210&lt;/td&gt;
&lt;td&gt;3225&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.10&lt;/td&gt;
&lt;td&gt;2.5&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1/2 (0.50)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1218&lt;/td&gt;
&lt;td&gt;3246&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.18&lt;/td&gt;
&lt;td&gt;4.6&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;2010&lt;/td&gt;
&lt;td&gt;5025&lt;/td&gt;
&lt;td&gt;0.20&lt;/td&gt;
&lt;td&gt;5.0&lt;/td&gt;
&lt;td&gt;0.10&lt;/td&gt;
&lt;td&gt;2.5&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;3/4 (0.75)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;2512&lt;/td&gt;
&lt;td&gt;6332&lt;/td&gt;
&lt;td&gt;0.25&lt;/td&gt;
&lt;td&gt;6.3&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;1&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;

&lt;p&gt;
&lt;img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/SMT_sizes%2C_based_on_original_by_Zureks.svg/800px-SMT_sizes%2C_based_on_original_by_Zureks.svg.png" alt="" title="" width="350"&gt;
&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="R-EU" x="5.08" y="0"/>
</gates>
<devices>
<device name="R0201" package="R0201">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736708/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R0402" package="R0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736707/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R0603" package="R0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736709/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R0805" package="R0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736717/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DESCR" value="SMD Resistor" constant="no"/>
<attribute name="PACKAGE" value="C0805" constant="no"/>
<attribute name="SIZE" value="0805in" constant="no"/>
</technology>
</technologies>
</device>
<device name="R1206" package="R1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736713/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R1210" package="R1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736711/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R2012" package="R2012">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736710/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R2512" package="R2512">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23545/2"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R3216" package="R3216">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736715/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R3225" package="R3225">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736716/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R4527" package="R4527">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736714/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R5025" package="R5025">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736712/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="R6332" package="R6332">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:23559/2"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="WSL_10G" urn="urn:adsk.eagle:component:10681403/8" prefix="JP" library_version="76">
<description>&lt;b&gt;Connector&lt;/b&gt;&lt;p&gt;
WSL 10G&lt;p&gt;
WANNENSTECKER, 10-POLIG&lt;p&gt;
BOX HEADER&lt;p&gt;
Source: &lt;a href="https://cdn-reichelt.de/documents/datenblatt/C151/BH1S-XX-L.pdf"&gt;Box Header&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="PINH2X5" x="0" y="0"/>
</gates>
<devices>
<device name="" package="WSL_10G">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10" pad="10"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8" pad="8"/>
<connect gate="G$1" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681399/5"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="Straight" constant="no"/>
<attribute name="DATASHEET" value="https://cdn-reichelt.de/documents/datenblatt/C151/BH1S-XX-L.pdf" constant="no"/>
<attribute name="DESCR" value="Box connector 10pin straight" constant="no"/>
<attribute name="MF" value="Amtek" constant="no"/>
<attribute name="MF_PN" value="WSL-10G" constant="no"/>
<attribute name="PACKAGE" value="Box Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="10" constant="no"/>
<attribute name="PURCHASE" value="https://www.reichelt.de/box-connector-10-pin-straight-wsl-10g-p22816.html?r=1" constant="no"/>
<attribute name="REICHELT_NO" value="WSL 10G" constant="no"/>
<attribute name="ROWS" value="2" constant="no"/>
<attribute name="UNIT_PRICE" value="0.1" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PINHD-2X5" urn="urn:adsk.eagle:component:10738577/4" prefix="JP" library_version="69">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="PINH2X5" x="0" y="0"/>
</gates>
<devices>
<device name="" package="2X05">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22470/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="Straight" constant="no"/>
<attribute name="DESCR" value="Pin Header 2X5 0DEG" constant="no"/>
<attribute name="PACKAGE" value="Pin Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="10" constant="no"/>
<attribute name="ROWS" value="2" constant="no"/>
</technology>
</technologies>
</device>
<device name="/90" package="2X05/90">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22471/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="90" constant="no"/>
<attribute name="PACKAGE" value="Pin Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="10" constant="no"/>
<attribute name="ROWS" value="2" constant="no"/>
</technology>
</technologies>
</device>
<device name="/JTAG" package="2X05/JTAG">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681960/4"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="Straight" constant="no"/>
<attribute name="DESCR" value="Pin Header 2X5 0DEG JTAG" constant="no"/>
<attribute name="PACKAGE" value="Pin Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="10" constant="no"/>
<attribute name="ROWS" value="2" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="RN04" urn="urn:adsk.eagle:component:10682943/5" prefix="RN" uservalue="yes" library_version="76">
<description>&lt;b&gt;RESISTOR NETWORK&lt;/b&gt;&lt;p&gt;

&lt;p&gt;
A resistor network is a single package that contains two or more resistors. The package will include multiple leads by which the network can be made part of a larger circuit. Figure 7 shows typical packages used for resistor networks. There are commonly two ways the resistors are connected in the array, isolated and bussed where one end of all the resistors share a common connection as shown in figure 8. The bussed arrangement is commonly used for pull up, pull down or bus termination on logic signals.
&lt;/p&gt;

&lt;p&gt;
&lt;img src="https://wiki.analog.com/_media/university/courses/electronics/arn_f8.png?w=350&amp;tok=30f449" alt="" title="" width="350"&gt;
&lt;/p&gt;

&lt;p&gt;
 Figure 1 SIP and DIP resistor network packages 
&lt;/p&gt;

&lt;p&gt;
&lt;img src="https://wiki.analog.com/_media/university/courses/electronics/arn_f9.png?w=500&amp;tok=0fbf0a" alt="" title="" width="500"&gt;
&lt;/p&gt;

&lt;p&gt;
 Figure 2 SIP and DIP resistor network schematics 
&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="RN04" x="5.08" y="0"/>
</gates>
<devices>
<device name="" package="RN04">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10682942/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.bourns.com/pdfs/4600X.pdf" constant="no"/>
<attribute name="DESCR" value="Resistor Networks &amp; Arrays 5pin 4resistor 10Kohms 2% Bussed" constant="no"/>
<attribute name="FARNELL_NO" value="9356061" constant="no"/>
<attribute name="MF" value="Bourns" constant="no"/>
<attribute name="MF_PN" value="4605X-101-103LF" constant="no"/>
<attribute name="PACKAGE" value="SIP" constant="no"/>
<attribute name="POS" value="5" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/bourns/4605x-101-103lf/widerstandsnetzwerk-5-pins-10k/dp/9356061" constant="no"/>
<attribute name="RES" value="4" constant="no"/>
<attribute name="UNIT_PRICE" value="0.294" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="ATMEGA*" urn="urn:adsk.eagle:component:10682031/6" prefix="IC" library_version="76">
<description>&lt;b&gt;MICROCONTROLLER&lt;/b&gt;&lt;p&gt;
64/128/256 Kbytes FLASH&lt;p&gt;
4 Kbytes EEPROM&lt;p&gt;
8 Kbytes SRAM&lt;p&gt;
86 General Purpose I/O pins&lt;p&gt;
12-channels16-bit PWM&lt;p&gt;
4 x Serial USARTs&lt;p&gt;
16-channels 10-bit A/D&lt;p&gt;</description>
<gates>
<gate name="G$1" symbol="86-I/O-1" x="0" y="0"/>
</gates>
<devices>
<device name="AI" package="TQFP100">
<connects>
<connect gate="G$1" pin="(A10)PC2" pad="55"/>
<connect gate="G$1" pin="(A11)PC3" pad="56"/>
<connect gate="G$1" pin="(A12)PC4" pad="57"/>
<connect gate="G$1" pin="(A13)PC5" pad="58"/>
<connect gate="G$1" pin="(A14)PC6" pad="59"/>
<connect gate="G$1" pin="(A15)PC7" pad="60"/>
<connect gate="G$1" pin="(A8)PC0" pad="53"/>
<connect gate="G$1" pin="(A9)PC1" pad="54"/>
<connect gate="G$1" pin="(AD0)PA0" pad="78"/>
<connect gate="G$1" pin="(AD1)PA1" pad="77"/>
<connect gate="G$1" pin="(AD2)PA2" pad="76"/>
<connect gate="G$1" pin="(AD3)PA3" pad="75"/>
<connect gate="G$1" pin="(AD4)PA4" pad="74"/>
<connect gate="G$1" pin="(AD5)PA5" pad="73"/>
<connect gate="G$1" pin="(AD6)PA6" pad="72"/>
<connect gate="G$1" pin="(AD7)PA7" pad="71"/>
<connect gate="G$1" pin="(ADC0)PF0" pad="97"/>
<connect gate="G$1" pin="(ADC1)PF1" pad="96"/>
<connect gate="G$1" pin="(ADC2)PF2" pad="95"/>
<connect gate="G$1" pin="(ADC3)PF3" pad="94"/>
<connect gate="G$1" pin="(ADC4/TCK)PF4" pad="93"/>
<connect gate="G$1" pin="(ADC5/TMS)PF5" pad="92"/>
<connect gate="G$1" pin="(ADC6/TDO)PF6" pad="91"/>
<connect gate="G$1" pin="(ADC7/TDI)PF7" pad="90"/>
<connect gate="G$1" pin="(ALE)PG2" pad="70"/>
<connect gate="G$1" pin="(CLKO/ICP3/INT7)PE7" pad="9"/>
<connect gate="G$1" pin="(ICP1)PD4" pad="47"/>
<connect gate="G$1" pin="(MISO/PCINT3)PB3" pad="22"/>
<connect gate="G$1" pin="(MOSI/PCINT2)PB2" pad="21"/>
<connect gate="G$1" pin="(OC0A/OC1C/PCINT7)PB7" pad="26"/>
<connect gate="G$1" pin="(OC0B)PG5" pad="1"/>
<connect gate="G$1" pin="(OC1A/PCINT5)PB5" pad="24"/>
<connect gate="G$1" pin="(OC1B/PCINT6)PB6" pad="25"/>
<connect gate="G$1" pin="(OC2A/PCINT4)PB4" pad="23"/>
<connect gate="G$1" pin="(OC3A/AIN1)PE3" pad="5"/>
<connect gate="G$1" pin="(OC3B/INT4)PE4" pad="6"/>
<connect gate="G$1" pin="(OC3C/INT5)PE5" pad="7"/>
<connect gate="G$1" pin="(RD)PG1" pad="52"/>
<connect gate="G$1" pin="(RXD0/PCIN8)PE0" pad="2"/>
<connect gate="G$1" pin="(RXD1/INT2)PD2" pad="45"/>
<connect gate="G$1" pin="(SCK/PCINT1)PB1" pad="20"/>
<connect gate="G$1" pin="(SCL/INT0)PD0" pad="43"/>
<connect gate="G$1" pin="(SDA/INT1)PD1" pad="44"/>
<connect gate="G$1" pin="(SS/PCINT0)PB0" pad="19"/>
<connect gate="G$1" pin="(T0)PD7" pad="50"/>
<connect gate="G$1" pin="(T1)PD6" pad="49"/>
<connect gate="G$1" pin="(T3/INT6)PE6" pad="8"/>
<connect gate="G$1" pin="(TOSC1)PG4" pad="29"/>
<connect gate="G$1" pin="(TOSC2)PG3" pad="28"/>
<connect gate="G$1" pin="(TXD0)PE1" pad="3"/>
<connect gate="G$1" pin="(TXD1/INT3)PD3" pad="46"/>
<connect gate="G$1" pin="(WR)PG0" pad="51"/>
<connect gate="G$1" pin="(XCK0/AIN0)PE2" pad="4"/>
<connect gate="G$1" pin="(XCK1)PD5" pad="48"/>
<connect gate="G$1" pin="AGND" pad="99"/>
<connect gate="G$1" pin="AREF" pad="98"/>
<connect gate="G$1" pin="AVCC" pad="100"/>
<connect gate="G$1" pin="GND" pad="11"/>
<connect gate="G$1" pin="GND1" pad="32"/>
<connect gate="G$1" pin="GND2" pad="62"/>
<connect gate="G$1" pin="GND3" pad="81"/>
<connect gate="G$1" pin="PH0(RXD2)" pad="12"/>
<connect gate="G$1" pin="PH1(TXD2)" pad="13"/>
<connect gate="G$1" pin="PH2(XCK2)" pad="14"/>
<connect gate="G$1" pin="PH3(OC4A)" pad="15"/>
<connect gate="G$1" pin="PH4(OC4B)" pad="16"/>
<connect gate="G$1" pin="PH5(OC4C)" pad="17"/>
<connect gate="G$1" pin="PH6(OC2B)" pad="18"/>
<connect gate="G$1" pin="PH7(T4)" pad="27"/>
<connect gate="G$1" pin="PJ0(RXD3/PCINT9)" pad="63"/>
<connect gate="G$1" pin="PJ1(TXD3/PCINT10)" pad="64"/>
<connect gate="G$1" pin="PJ2(XCK3/PCINT11)" pad="65"/>
<connect gate="G$1" pin="PJ3(PCINT12)" pad="66"/>
<connect gate="G$1" pin="PJ4(PCINT13)" pad="67"/>
<connect gate="G$1" pin="PJ5(PCINT14)" pad="68"/>
<connect gate="G$1" pin="PJ6(PCINT15)" pad="69"/>
<connect gate="G$1" pin="PJ7" pad="79"/>
<connect gate="G$1" pin="PK0(ADC8/PCINT16)" pad="89"/>
<connect gate="G$1" pin="PK1(ADC9/PCINT17)" pad="88"/>
<connect gate="G$1" pin="PK2(ADC10/PCINT18)" pad="87"/>
<connect gate="G$1" pin="PK3(ADC11/PCINT19)" pad="86"/>
<connect gate="G$1" pin="PK4(ADC12/PCINT20)" pad="85"/>
<connect gate="G$1" pin="PK5(ADC13/PCINT21)" pad="84"/>
<connect gate="G$1" pin="PK6(ADC14/PCINT22)" pad="83"/>
<connect gate="G$1" pin="PK7(ADC15/PCINT23)" pad="82"/>
<connect gate="G$1" pin="PL0(ICP4)" pad="35"/>
<connect gate="G$1" pin="PL1(ICP5)" pad="36"/>
<connect gate="G$1" pin="PL2(T5)" pad="37"/>
<connect gate="G$1" pin="PL3(OC5A)" pad="38"/>
<connect gate="G$1" pin="PL4(OC5B)" pad="39"/>
<connect gate="G$1" pin="PL5(OC5C)" pad="40"/>
<connect gate="G$1" pin="PL6" pad="41"/>
<connect gate="G$1" pin="PL7" pad="42"/>
<connect gate="G$1" pin="RESET" pad="30"/>
<connect gate="G$1" pin="VCC" pad="10"/>
<connect gate="G$1" pin="VCC1" pad="31"/>
<connect gate="G$1" pin="VCC2" pad="61"/>
<connect gate="G$1" pin="VCC3" pad="80"/>
<connect gate="G$1" pin="XTAL1" pad="34"/>
<connect gate="G$1" pin="XTAL2" pad="33"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10682030/2"/>
</package3dinstances>
<technologies>
<technology name="1280-16"/>
<technology name="1280V-8"/>
<technology name="2560-16"/>
<technology name="2560V-8"/>
<technology name="640-16"/>
<technology name="640V-8"/>
</technologies>
</device>
<device name="AU" package="TQFP100">
<connects>
<connect gate="G$1" pin="(A10)PC2" pad="55"/>
<connect gate="G$1" pin="(A11)PC3" pad="56"/>
<connect gate="G$1" pin="(A12)PC4" pad="57"/>
<connect gate="G$1" pin="(A13)PC5" pad="58"/>
<connect gate="G$1" pin="(A14)PC6" pad="59"/>
<connect gate="G$1" pin="(A15)PC7" pad="60"/>
<connect gate="G$1" pin="(A8)PC0" pad="53"/>
<connect gate="G$1" pin="(A9)PC1" pad="54"/>
<connect gate="G$1" pin="(AD0)PA0" pad="78"/>
<connect gate="G$1" pin="(AD1)PA1" pad="77"/>
<connect gate="G$1" pin="(AD2)PA2" pad="76"/>
<connect gate="G$1" pin="(AD3)PA3" pad="75"/>
<connect gate="G$1" pin="(AD4)PA4" pad="74"/>
<connect gate="G$1" pin="(AD5)PA5" pad="73"/>
<connect gate="G$1" pin="(AD6)PA6" pad="72"/>
<connect gate="G$1" pin="(AD7)PA7" pad="71"/>
<connect gate="G$1" pin="(ADC0)PF0" pad="97"/>
<connect gate="G$1" pin="(ADC1)PF1" pad="96"/>
<connect gate="G$1" pin="(ADC2)PF2" pad="95"/>
<connect gate="G$1" pin="(ADC3)PF3" pad="94"/>
<connect gate="G$1" pin="(ADC4/TCK)PF4" pad="93"/>
<connect gate="G$1" pin="(ADC5/TMS)PF5" pad="92"/>
<connect gate="G$1" pin="(ADC6/TDO)PF6" pad="91"/>
<connect gate="G$1" pin="(ADC7/TDI)PF7" pad="90"/>
<connect gate="G$1" pin="(ALE)PG2" pad="70"/>
<connect gate="G$1" pin="(CLKO/ICP3/INT7)PE7" pad="9"/>
<connect gate="G$1" pin="(ICP1)PD4" pad="47"/>
<connect gate="G$1" pin="(MISO/PCINT3)PB3" pad="22"/>
<connect gate="G$1" pin="(MOSI/PCINT2)PB2" pad="21"/>
<connect gate="G$1" pin="(OC0A/OC1C/PCINT7)PB7" pad="26"/>
<connect gate="G$1" pin="(OC0B)PG5" pad="1"/>
<connect gate="G$1" pin="(OC1A/PCINT5)PB5" pad="24"/>
<connect gate="G$1" pin="(OC1B/PCINT6)PB6" pad="25"/>
<connect gate="G$1" pin="(OC2A/PCINT4)PB4" pad="23"/>
<connect gate="G$1" pin="(OC3A/AIN1)PE3" pad="5"/>
<connect gate="G$1" pin="(OC3B/INT4)PE4" pad="6"/>
<connect gate="G$1" pin="(OC3C/INT5)PE5" pad="7"/>
<connect gate="G$1" pin="(RD)PG1" pad="52"/>
<connect gate="G$1" pin="(RXD0/PCIN8)PE0" pad="2"/>
<connect gate="G$1" pin="(RXD1/INT2)PD2" pad="45"/>
<connect gate="G$1" pin="(SCK/PCINT1)PB1" pad="20"/>
<connect gate="G$1" pin="(SCL/INT0)PD0" pad="43"/>
<connect gate="G$1" pin="(SDA/INT1)PD1" pad="44"/>
<connect gate="G$1" pin="(SS/PCINT0)PB0" pad="19"/>
<connect gate="G$1" pin="(T0)PD7" pad="50"/>
<connect gate="G$1" pin="(T1)PD6" pad="49"/>
<connect gate="G$1" pin="(T3/INT6)PE6" pad="8"/>
<connect gate="G$1" pin="(TOSC1)PG4" pad="29"/>
<connect gate="G$1" pin="(TOSC2)PG3" pad="28"/>
<connect gate="G$1" pin="(TXD0)PE1" pad="3"/>
<connect gate="G$1" pin="(TXD1/INT3)PD3" pad="46"/>
<connect gate="G$1" pin="(WR)PG0" pad="51"/>
<connect gate="G$1" pin="(XCK0/AIN0)PE2" pad="4"/>
<connect gate="G$1" pin="(XCK1)PD5" pad="48"/>
<connect gate="G$1" pin="AGND" pad="99"/>
<connect gate="G$1" pin="AREF" pad="98"/>
<connect gate="G$1" pin="AVCC" pad="100"/>
<connect gate="G$1" pin="GND" pad="11"/>
<connect gate="G$1" pin="GND1" pad="32"/>
<connect gate="G$1" pin="GND2" pad="62"/>
<connect gate="G$1" pin="GND3" pad="81"/>
<connect gate="G$1" pin="PH0(RXD2)" pad="12"/>
<connect gate="G$1" pin="PH1(TXD2)" pad="13"/>
<connect gate="G$1" pin="PH2(XCK2)" pad="14"/>
<connect gate="G$1" pin="PH3(OC4A)" pad="15"/>
<connect gate="G$1" pin="PH4(OC4B)" pad="16"/>
<connect gate="G$1" pin="PH5(OC4C)" pad="17"/>
<connect gate="G$1" pin="PH6(OC2B)" pad="18"/>
<connect gate="G$1" pin="PH7(T4)" pad="27"/>
<connect gate="G$1" pin="PJ0(RXD3/PCINT9)" pad="63"/>
<connect gate="G$1" pin="PJ1(TXD3/PCINT10)" pad="64"/>
<connect gate="G$1" pin="PJ2(XCK3/PCINT11)" pad="65"/>
<connect gate="G$1" pin="PJ3(PCINT12)" pad="66"/>
<connect gate="G$1" pin="PJ4(PCINT13)" pad="67"/>
<connect gate="G$1" pin="PJ5(PCINT14)" pad="68"/>
<connect gate="G$1" pin="PJ6(PCINT15)" pad="69"/>
<connect gate="G$1" pin="PJ7" pad="79"/>
<connect gate="G$1" pin="PK0(ADC8/PCINT16)" pad="89"/>
<connect gate="G$1" pin="PK1(ADC9/PCINT17)" pad="88"/>
<connect gate="G$1" pin="PK2(ADC10/PCINT18)" pad="87"/>
<connect gate="G$1" pin="PK3(ADC11/PCINT19)" pad="86"/>
<connect gate="G$1" pin="PK4(ADC12/PCINT20)" pad="85"/>
<connect gate="G$1" pin="PK5(ADC13/PCINT21)" pad="84"/>
<connect gate="G$1" pin="PK6(ADC14/PCINT22)" pad="83"/>
<connect gate="G$1" pin="PK7(ADC15/PCINT23)" pad="82"/>
<connect gate="G$1" pin="PL0(ICP4)" pad="35"/>
<connect gate="G$1" pin="PL1(ICP5)" pad="36"/>
<connect gate="G$1" pin="PL2(T5)" pad="37"/>
<connect gate="G$1" pin="PL3(OC5A)" pad="38"/>
<connect gate="G$1" pin="PL4(OC5B)" pad="39"/>
<connect gate="G$1" pin="PL5(OC5C)" pad="40"/>
<connect gate="G$1" pin="PL6" pad="41"/>
<connect gate="G$1" pin="PL7" pad="42"/>
<connect gate="G$1" pin="RESET" pad="30"/>
<connect gate="G$1" pin="VCC" pad="10"/>
<connect gate="G$1" pin="VCC1" pad="31"/>
<connect gate="G$1" pin="VCC2" pad="61"/>
<connect gate="G$1" pin="VCC3" pad="80"/>
<connect gate="G$1" pin="XTAL1" pad="34"/>
<connect gate="G$1" pin="XTAL2" pad="33"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10682030/2"/>
</package3dinstances>
<technologies>
<technology name="1280-16">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCR" value="" constant="no"/>
<attribute name="FARNELL_NO" value="" constant="no"/>
<attribute name="MF" value="" constant="no"/>
<attribute name="MF_PN" value="" constant="no"/>
<attribute name="MOUSER_NO" value="" constant="no"/>
<attribute name="PACKAGE" value="" constant="no"/>
<attribute name="PURCHASE" value="" constant="no"/>
<attribute name="UNIT_PRICE" value="" constant="no"/>
</technology>
<technology name="1280V-8">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCR" value="" constant="no"/>
<attribute name="FARNELL_NO" value="" constant="no"/>
<attribute name="MF" value="" constant="no"/>
<attribute name="MF_PN" value="" constant="no"/>
<attribute name="MOUSER_NO" value="" constant="no"/>
<attribute name="PACKAGE" value="" constant="no"/>
<attribute name="PURCHASE" value="" constant="no"/>
<attribute name="UNIT_PRICE" value="" constant="no"/>
</technology>
<technology name="2560-16">
<attribute name="DATASHEET" value="http://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2549-8-bit-AVR-Microcontroller-ATmega640-1280-1281-2560-2561_datasheet.pdf" constant="no"/>
<attribute name="DESCR" value="8-bit Microcontrollers - MCU 256kB Flash 4kB EEPROM 86 I/O Pins" constant="no"/>
<attribute name="FARNELL_NO" value="1288330" constant="no"/>
<attribute name="MF" value="Atmel" constant="no"/>
<attribute name="MF_PN" value="ATMEGA2560-16AU" constant="no"/>
<attribute name="MOUSER_NO" value="556-ATMEGA2560-16AU" constant="no"/>
<attribute name="PACKAGE" value="TQFP-100" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/atmel/atmega2560-16au/8bit-mcu-256k-flash-5v-smd-2560/dp/1288330" constant="no"/>
<attribute name="UNIT_PRICE" value="10.13" constant="no"/>
</technology>
<technology name="2560V-8">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCR" value="" constant="no"/>
<attribute name="FARNELL_NO" value="" constant="no"/>
<attribute name="MF" value="" constant="no"/>
<attribute name="MF_PN" value="" constant="no"/>
<attribute name="MOUSER_NO" value="" constant="no"/>
<attribute name="PACKAGE" value="" constant="no"/>
<attribute name="PURCHASE" value="" constant="no"/>
<attribute name="UNIT_PRICE" value="" constant="no"/>
</technology>
<technology name="640-16">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCR" value="" constant="no"/>
<attribute name="FARNELL_NO" value="" constant="no"/>
<attribute name="MF" value="" constant="no"/>
<attribute name="MF_PN" value="" constant="no"/>
<attribute name="MOUSER_NO" value="" constant="no"/>
<attribute name="PACKAGE" value="" constant="no"/>
<attribute name="PURCHASE" value="" constant="no"/>
<attribute name="UNIT_PRICE" value="" constant="no"/>
</technology>
<technology name="640V-8">
<attribute name="DATASHEET" value="" constant="no"/>
<attribute name="DESCR" value="" constant="no"/>
<attribute name="FARNELL_NO" value="" constant="no"/>
<attribute name="MF" value="" constant="no"/>
<attribute name="MF_PN" value="" constant="no"/>
<attribute name="MOUSER_NO" value="" constant="no"/>
<attribute name="PACKAGE" value="" constant="no"/>
<attribute name="PURCHASE" value="" constant="no"/>
<attribute name="UNIT_PRICE" value="" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="XO91" urn="urn:adsk.eagle:component:11072100/2" prefix="QG" library_version="77">
<description>&lt;b&gt;Oscillator&lt;/b&gt;&lt;p&gt;
3.3V CMOS Clock Oscillator&lt;p&gt;
Source: &lt;a href="https://cdn-reichelt.de/documents/datenblatt/B400/XO91.pdf"&gt;Datasheet&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="SM77H" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SM77H">
<connects>
<connect gate="G$1" pin="E/D" pad="1"/>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="OUT" pad="3"/>
<connect gate="G$1" pin="VCC" pad="4"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:12177396/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://cdn-reichelt.de/documents/datenblatt/B400/XO91.pdf " constant="no"/>
<attribute name="DESCR" value="16.0MHz CMOS Crystal Oscillator Ceramic SMD XO91" constant="no"/>
<attribute name="FREQUENCY" value="16MHz" constant="no"/>
<attribute name="MF" value="EUROQUARTZ" constant="no"/>
<attribute name="MF_PN" value="16.000MHZ XO91050UITA" constant="no"/>
<attribute name="PACKAGE" value="7x5" constant="no"/>
<attribute name="PURCHASE" value="https://www.reichelt.de/16-0mhz-crystal-oscillator-ceramic-smd-xo91-xo91-16-00000-p85017.html?&amp;trstct=pol_12" constant="no"/>
<attribute name="REICHELT_NO" value="XO91 16,00000" constant="no"/>
<attribute name="SIZE" value="7x5mm" constant="no"/>
<attribute name="UNIT_PRICE" value="1.15" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SCREWTERM_4POL_3.5MM" urn="urn:adsk.eagle:component:10723857/7" prefix="JP" library_version="76">
<description>&lt;b&gt;Plug-In Screw Terminal Connector&lt;/b&gt;&lt;p&gt;
2 Part Plug-InScrew Terminal &lt;p&gt;
4 position&lt;p&gt;
3.5mm pitch&lt;p&gt;

&lt;style&gt;
table, th, td {
  padding: 5px;
}
th {
  text-align: left;
}
table {
}
&lt;/style&gt;

&lt;table&gt;
  &lt;tr&gt;
    &lt;td bgcolor="#CBD9EC"&gt;Plug&lt;/td&gt;
    &lt;td bgcolor="#CBD9EC"&gt;Pin Header&lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td&gt;AKL 166-04&lt;/td&gt;
    &lt;td&gt;STL 224-04&lt;/td&gt; 
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td&gt;&lt;a href="https://www.reichelt.com/de/en/plug-in-connection-terminal-4-pin-spacing-3-5-mm-akl-166-04-p72073.html?&amp;trstct=pos_9"&gt;Datasheet&lt;/a&gt;&lt;/td&gt;
    &lt;td&gt;&lt;a href="https://www.reichelt.com/de/en/pin-header-for-terminal-4-pin-spacing-3-5-mm-stl-224-04-p72080.html?&amp;trstct=pos_0"&gt;Datasheet&lt;/a&gt;&lt;/td&gt; 
  &lt;/tr&gt;
&lt;/table&gt;</description>
<gates>
<gate name="G$1" symbol="PINHD4" x="2.54" y="-2.54"/>
</gates>
<devices>
<device name="" package="SCREWTERM_4POS_3.5MM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10723840/3"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="90" constant="no"/>
<attribute name="DATASHEET" value="https://cdn-reichelt.de/documents/datenblatt/C100/31166102.pdf; https://cdn-reichelt.de/documents/datenblatt/C100/31224102.pdf" constant="no"/>
<attribute name="DESCR" value="Plug-in Connection Screw Terminal 4P 3.5mm 90DEG; Pin Header for Terminal 4P 3.5 mm" constant="no"/>
<attribute name="MF" value="RIACON" constant="no"/>
<attribute name="MF_PN" value="AKL 166-04; STL 224-04 " constant="no"/>
<attribute name="PACKAGE" value="Screw Terminal; Pin Header for Terminal" constant="no"/>
<attribute name="PITCH" value="3.50mm" constant="no"/>
<attribute name="POS" value="4" constant="no"/>
<attribute name="PURCHASE" value="https://www.reichelt.com/de/en/plug-in-connection-terminal-4-pin-spacing-3-5-mm-akl-166-04-p72073.html?&amp;trstct=pos_9; https://www.reichelt.com/de/en/pin-header-for-terminal-4-pin-spacing-3-5-mm-stl-224-04-p72080.html?&amp;trstct=pos_0" constant="no"/>
<attribute name="REICHELT_NO" value="AKL 166-04; STL 224-04" constant="no"/>
<attribute name="ROWS" value="1" constant="no"/>
<attribute name="UNIT_PRICE" value="0.95; 0.34" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CPOL" urn="urn:adsk.eagle:component:10738169/5" uservalue="yes" library_version="77">
<description>&lt;b&gt;Aluminum Electrolytic Capacitors&lt;/b&gt;&lt;p&gt;
CPOL-EU&lt;p&gt; 
UD NICHICON&lt;p&gt;
Size: Diameter X Length [mm]</description>
<gates>
<gate name="C$1" symbol="CPOL" x="0" y="0"/>
</gates>
<devices>
<device name="/4X5,8" package="UD-4X5,8_NICHICON">
<connects>
<connect gate="C$1" pin="+" pad="+"/>
<connect gate="C$1" pin="-" pad="-"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681681/3"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://industrial.panasonic.com/cdbs/www-data/pdf/RDE0000/ABA0000C1175.pdf" constant="no"/>
<attribute name="DESCR" value="Aluminium Electrolytic Capacitors - SMD FK 35VDC 10uF SMD 4x5.8" constant="no"/>
<attribute name="FARNELL_NO" value="1244420" constant="no"/>
<attribute name="MF" value="Panasonic" constant="no"/>
<attribute name="MF_PN" value="EEEFKV100UAR" constant="no"/>
<attribute name="PACKAGE" value="4x5.8" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/panasonic/eeefkv100uar/kondensator-10-f-35v-radial-smd/dp/1244420" constant="no"/>
<attribute name="SIZE" value="4x5.8mm" constant="no"/>
<attribute name="UNIT_PRICE" value="0.376" constant="no"/>
</technology>
</technologies>
</device>
<device name="/6,3X7,7" package="UD-6,3X5,8_NICHICON">
<connects>
<connect gate="C$1" pin="+" pad="+"/>
<connect gate="C$1" pin="-" pad="-"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681938/3"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://industrial.panasonic.com/cdbs/www-data/pdf/RDE0000/ABA0000C1175.pdf" constant="no"/>
<attribute name="DESCR" value="Aluminium Electrolytic Capacitors - SMD FK 16VDC 10uF SMD 6.3x7.7" constant="no"/>
<attribute name="FARNELL_NO" value="2254321" constant="no"/>
<attribute name="MF" value="Panasonic" constant="no"/>
<attribute name="MF_PN" value="EEEFKC221XAP" constant="no"/>
<attribute name="PACKAGE" value="6.3x7.7" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/panasonic/eeefkc221xap/kondensator-220-f-16v-radial-smd/dp/2254321" constant="no"/>
<attribute name="SIZE" value="6.3x7.7mm" constant="no"/>
<attribute name="UNIT_PRICE" value="0.48" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="LM385-1.2/NOPB" urn="urn:adsk.eagle:component:11072099/1" prefix="U" library_version="76">
<description>&lt;b&gt;Voltage Ref&lt;/b&gt;&lt;p&gt;
LM385M Texas Instruments</description>
<gates>
<gate name="G$1" symbol="LM385-1.2" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SO08">
<connects>
<connect gate="G$1" pin="NC1" pad="1"/>
<connect gate="G$1" pin="NC2" pad="2"/>
<connect gate="G$1" pin="NC3" pad="3"/>
<connect gate="G$1" pin="NC4" pad="7"/>
<connect gate="G$1" pin="NC5" pad="6"/>
<connect gate="G$1" pin="NC6" pad="5"/>
<connect gate="G$1" pin="NG" pad="4"/>
<connect gate="G$1" pin="POS" pad="8"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681740/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="http://www.ti.com/lit/ds/symlink/lm385-1.2-n.pdf" constant="no"/>
<attribute name="DESCR" value="Voltage References Fixed 1.235 MicroPwr Vtg Ref - SOIC-8" constant="no"/>
<attribute name="FARNELL_NO" value="2782470" constant="no"/>
<attribute name="MF" value="Texas Instruments" constant="no"/>
<attribute name="MF_PN" value="LM385MX-1.2/NOPB" constant="no"/>
<attribute name="PACKAGE" value="SOIC-8" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/texas-instruments/lm385mx-1-2-nopb/spannungsreferenz-shunt-1-235v/dp/2782470" constant="no"/>
<attribute name="UNIT_PRICE" value="0.60" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="LM358" urn="urn:adsk.eagle:component:10681717/5" prefix="U" library_version="76">
<description>&lt;b&gt;OP AMP&lt;/b&gt;&lt;p&gt;
also LM158; LM258; LM2904&lt;p&gt;
Source:  &lt;a href="http://cache.national.com/ds/LM/LM158.pdf"&gt;Datasheet&lt;/a&gt;</description>
<gates>
<gate name="A" symbol="OPAMP" x="15.24" y="10.16" swaplevel="1"/>
<gate name="B" symbol="OPAMP" x="15.24" y="-12.7" swaplevel="1"/>
<gate name="P" symbol="PWR+-" x="15.24" y="10.16" addlevel="request"/>
</gates>
<devices>
<device name="D" package="SO08">
<connects>
<connect gate="A" pin="+IN" pad="3"/>
<connect gate="A" pin="-IN" pad="2"/>
<connect gate="A" pin="OUT" pad="1"/>
<connect gate="B" pin="+IN" pad="5"/>
<connect gate="B" pin="-IN" pad="6"/>
<connect gate="B" pin="OUT" pad="7"/>
<connect gate="P" pin="V+" pad="8"/>
<connect gate="P" pin="V-" pad="4"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681740/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="http://www.ti.com/lit/ds/symlink/lm358.pdf" constant="no"/>
<attribute name="DESCR" value="Operational Amplifiers - Op Amps Dual Linear - SOIC-8" constant="no"/>
<attribute name="FARNELL_NO" value="1648685" constant="no"/>
<attribute name="MF" value="Texas Instruments" constant="no"/>
<attribute name="MF_PN" value="LM358D" constant="no"/>
<attribute name="MOUSER_NO" value="595-LM358D" constant="no"/>
<attribute name="PACKAGE" value="SOIC-8" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/texas-instruments/lm358dr/op-amp-dual-low-power-soic8-358/dp/1648685 " constant="no"/>
<attribute name="UNIT_PRICE" value="0.358" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="C-EU" urn="urn:adsk.eagle:component:10724564/9" prefix="C" uservalue="yes" library_version="70">
<description>&lt;b&gt;Capacitor&lt;/b&gt;&lt;p&gt;
European Symbol&lt;p&gt;

&lt;p&gt;
The shape and size of surface mount devices are standardized, most manufacturers use the JEDEC standards. The size of SMD capacitors/resistors is indicated by a numerical code, such as 0603. This code contains the width and height of the package. So in the example of 0603 Imperial code, this indicates a length of 0.060″ and a width of 0.030″. This code can be given in Imperial or Metric units.&lt;br&gt;&amp;nbsp;
&lt;img src="http://www.resistorguide.com/pictures/resistor-sizes.png" alt="" title="" width="350"&gt;
&lt;/p&gt;

&lt;table class="CSSTable" style="margin: 0px auto;"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td colspan="2"&gt;Code&lt;/td&gt;
&lt;td colspan="2"&gt;Length (l)&lt;/td&gt;
&lt;td colspan="2"&gt;Width (w)&lt;/td&gt;
&lt;td colspan="2"&gt;Height (h)&lt;/td&gt;
&lt;td&gt;Power&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td bgcolor="#CBD9EC"&gt;Imperial&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;Metric&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;Watt&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0201&lt;/td&gt;
&lt;td&gt;0603&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;0.012&lt;/td&gt;
&lt;td&gt;0.3&lt;/td&gt;
&lt;td&gt;0.01&lt;/td&gt;
&lt;td&gt;0.25&lt;/td&gt;
&lt;td&gt;1/20 (0.05)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0402&lt;/td&gt;
&lt;td&gt;1005&lt;/td&gt;
&lt;td&gt;0.04&lt;/td&gt;
&lt;td&gt;1.0&lt;/td&gt;
&lt;td&gt;0.02&lt;/td&gt;
&lt;td&gt;0.5&lt;/td&gt;
&lt;td&gt;0.014&lt;/td&gt;
&lt;td&gt;0.35&lt;/td&gt;
&lt;td&gt;1/16 (0.062)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0603&lt;/td&gt;
&lt;td&gt;1608&lt;/td&gt;
&lt;td&gt;0.06&lt;/td&gt;
&lt;td&gt;1.55&lt;/td&gt;
&lt;td&gt;0.03&lt;/td&gt;
&lt;td&gt;0.85&lt;/td&gt;
&lt;td&gt;0.018&lt;/td&gt;
&lt;td&gt;0.45&lt;/td&gt;
&lt;td&gt;1/10 (0.10)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0805&lt;/td&gt;
&lt;td&gt;2012&lt;/td&gt;
&lt;td&gt;0.08&lt;/td&gt;
&lt;td&gt;2.0&lt;/td&gt;
&lt;td&gt;0.05&lt;/td&gt;
&lt;td&gt;1.2&lt;/td&gt;
&lt;td&gt;0.018&lt;/td&gt;
&lt;td&gt;0.45&lt;/td&gt;
&lt;td&gt;1/8 (0.125)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1206&lt;/td&gt;
&lt;td&gt;3216&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.06&lt;/td&gt;
&lt;td&gt;1.6&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1/4 (0.25)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1210&lt;/td&gt;
&lt;td&gt;3225&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.10&lt;/td&gt;
&lt;td&gt;2.5&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1/2 (0.50)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1218&lt;/td&gt;
&lt;td&gt;3246&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.18&lt;/td&gt;
&lt;td&gt;4.6&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;2010&lt;/td&gt;
&lt;td&gt;5025&lt;/td&gt;
&lt;td&gt;0.20&lt;/td&gt;
&lt;td&gt;5.0&lt;/td&gt;
&lt;td&gt;0.10&lt;/td&gt;
&lt;td&gt;2.5&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;3/4 (0.75)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;2512&lt;/td&gt;
&lt;td&gt;6332&lt;/td&gt;
&lt;td&gt;0.25&lt;/td&gt;
&lt;td&gt;6.3&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;1&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;

&lt;p&gt;
&lt;img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/SMT_sizes%2C_based_on_original_by_Zureks.svg/800px-SMT_sizes%2C_based_on_original_by_Zureks.svg.png" alt="" title="" width="350"&gt;
&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="C-EU" x="0" y="2.54"/>
</gates>
<devices>
<device name="C0201" package="C0201">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736697/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0504" package="C0504">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736700/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0603" package="C0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736694/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0805" package="C0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736691/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DESCR" value="SMD Capacitor" constant="no"/>
<attribute name="PACKAGE" value="C0805" constant="no"/>
<attribute name="SIZE" value="0805in" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736689/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1210" package="C1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736698/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1310" package="C1310">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736704/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1608" package="C1608">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736695/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1808" package="C1808">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736706/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1812" package="C1812">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736703/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1825" package="C1825">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736696/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C2012" package="C2012">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736702/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3216" package="C3216">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736690/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3225" package="C3225">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736705/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3640" package="C3640">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736692/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C4532" package="C4532">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736693/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C4564" package="C4564">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736688/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0402" package="C0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10724827/4"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="IRF3808" urn="urn:adsk.eagle:component:10682688/6" prefix="Q" library_version="79">
<description>&lt;b&gt;MOSFET&lt;/b&gt;&lt;p&gt;
N-Channel Enhancement MOSFET (HEXFET); 75V; 140A; 0,007Ohm</description>
<gates>
<gate name="Q$1" symbol="IGFET-EN-GDS" x="0" y="0"/>
</gates>
<devices>
<device name="" package="TO220">
<connects>
<connect gate="Q$1" pin="D" pad="2"/>
<connect gate="Q$1" pin="G" pad="1"/>
<connect gate="Q$1" pin="S" pad="3"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10682687/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.mouser.de/datasheet/2/427/sihf510-105610.pdf" constant="no"/>
<attribute name="DESCR" value="MOSFET N-CH 75V HEXFET MOSFET D2-PA" constant="no"/>
<attribute name="FARNELL_NO" value="1653658" constant="no"/>
<attribute name="MF" value="Vishay" constant="no"/>
<attribute name="MF_PN" value="IRF3808PBF" constant="no"/>
<attribute name="MOUSER_NO" value="942-IRF3808PBF" constant="no"/>
<attribute name="PACKAGE" value="TO-220AB" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/infineon/irf3808pbf/mosfet-n-kanal-75v-140a-to-220/dp/8657661" constant="no"/>
<attribute name="UNIT_PRICE" value="1.55" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="RPI-ZERO" urn="urn:adsk.eagle:component:10723858/11" prefix="IC" library_version="74">
<description>&lt;b&gt;Raspberry Pi Zero W&lt;/b&gt;&lt;p&gt;
BCM 2835 SOC @ 1GHz&lt;p&gt;
1GHz&lt;p&gt;
512MB of RAM&lt;p&gt;
On-board Wireless LAN - 2.4 GHz 802.11 b/g/n (BCM43438)&lt;p&gt;
On-board Bluetooth 4.1 + HS Low-energy (BLE) (BCM43438)&lt;p&gt;
micro-SD&lt;p&gt;
mini-HDMI&lt;p&gt;
micro-B USB for data&lt;p&gt;
micro-B USB for power&lt;p&gt;
CSI camera connector (needs adaptor cable)&lt;p&gt;
Unpopulated 40-pin GPIO connector (requires soldering)&lt;p&gt;
Compatible with existing pHAT/HAT add-ons&lt;p&gt;
Dimensions: 65mm x 30mm x 5mm&lt;p&gt;

Source: &lt;a href="https://www.raspberrypi.org/products/raspberry-pi-zero-w/"&gt;Raspberry Pi Zero W&lt;/a&gt;</description>
<gates>
<gate name="A$1" symbol="RPI-ZERO" x="0" y="0"/>
</gates>
<devices>
<device name="" package="RASPBERRYPI_ZERO">
<connects>
<connect gate="A$1" pin="!CE!/GPIO7" pad="26"/>
<connect gate="A$1" pin="!CE0!/GPIO8" pad="24"/>
<connect gate="A$1" pin="3V3@1" pad="1"/>
<connect gate="A$1" pin="3V3@2" pad="17"/>
<connect gate="A$1" pin="5V0@1" pad="2"/>
<connect gate="A$1" pin="5V0@2" pad="4"/>
<connect gate="A$1" pin="GEN/6GPIO25" pad="22"/>
<connect gate="A$1" pin="GEN4/GPIO23" pad="16"/>
<connect gate="A$1" pin="GEN5/GPIO24" pad="18"/>
<connect gate="A$1" pin="GND@1" pad="9"/>
<connect gate="A$1" pin="GND@2" pad="25"/>
<connect gate="A$1" pin="GND@3" pad="39"/>
<connect gate="A$1" pin="GND@4" pad="14"/>
<connect gate="A$1" pin="GND@5" pad="20"/>
<connect gate="A$1" pin="GND@6" pad="30"/>
<connect gate="A$1" pin="GND@7" pad="34"/>
<connect gate="A$1" pin="GND@8" pad="6"/>
<connect gate="A$1" pin="GPIO10/MOSI" pad="19"/>
<connect gate="A$1" pin="GPIO11/SCLK" pad="23"/>
<connect gate="A$1" pin="GPIO12" pad="32"/>
<connect gate="A$1" pin="GPIO13" pad="33"/>
<connect gate="A$1" pin="GPIO16" pad="36"/>
<connect gate="A$1" pin="GPIO17/GEN0" pad="11"/>
<connect gate="A$1" pin="GPIO18" pad="12"/>
<connect gate="A$1" pin="GPIO19" pad="35"/>
<connect gate="A$1" pin="GPIO2/SDA1" pad="3"/>
<connect gate="A$1" pin="GPIO20" pad="38"/>
<connect gate="A$1" pin="GPIO21" pad="40"/>
<connect gate="A$1" pin="GPIO22/GEN3" pad="15"/>
<connect gate="A$1" pin="GPIO26" pad="37"/>
<connect gate="A$1" pin="GPIO27/GEN2" pad="13"/>
<connect gate="A$1" pin="GPIO3/SCL1" pad="5"/>
<connect gate="A$1" pin="GPIO4/GCKL" pad="7"/>
<connect gate="A$1" pin="GPIO5" pad="29"/>
<connect gate="A$1" pin="GPIO6" pad="31"/>
<connect gate="A$1" pin="GPIO9/MISO" pad="21"/>
<connect gate="A$1" pin="ID_SC" pad="28"/>
<connect gate="A$1" pin="ID_SD" pad="27"/>
<connect gate="A$1" pin="RXD0/GPIO15" pad="10"/>
<connect gate="A$1" pin="TXD0/GPIO14" pad="8"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10723842/6"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DESCR" value="Raspberry Pi Zero W" constant="no"/>
<attribute name="MF" value="Raspberry Pi" constant="no"/>
<attribute name="UNIT_PRICE" value="10.53" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VNH5019" urn="urn:adsk.eagle:component:10723854/8" prefix="A" library_version="76">
<description>&lt;b&gt;Pololu VNH5019 Motor Driver Carrier&lt;/b&gt;&lt;p&gt;
Operating voltage: 5.5 – 24 V1&lt;p&gt;
Output current: 12 A continuous (30 maximum)&lt;p&gt;
3V-compatible inputs&lt;p&gt;
PWM operation up to 20 kHz, which is ultrasonic and allows for quieter motor operation&lt;p&gt;
Current sense output proportional to motor current (approx. 140 mV/A; only active while H-bridge is driving)&lt;p&gt;
Source: &lt;a href="https://www.pololu.com/product/1451"&gt;VNH5019 Motor Driver Carrier&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="VNH5019" x="2.54" y="-2.54"/>
</gates>
<devices>
<device name="" package="VNH5019">
<connects>
<connect gate="G$1" pin="CS@12" pad="12"/>
<connect gate="G$1" pin="ENA@10" pad="10"/>
<connect gate="G$1" pin="ENB@13" pad="13"/>
<connect gate="G$1" pin="GND@16" pad="16"/>
<connect gate="G$1" pin="GND@18" pad="18"/>
<connect gate="G$1" pin="GND@3" pad="3"/>
<connect gate="G$1" pin="GND@4" pad="4"/>
<connect gate="G$1" pin="INA@9" pad="9"/>
<connect gate="G$1" pin="INB@14" pad="14"/>
<connect gate="G$1" pin="OUTA@7" pad="7"/>
<connect gate="G$1" pin="OUTA@8" pad="8"/>
<connect gate="G$1" pin="OUTB@5" pad="5"/>
<connect gate="G$1" pin="OUTB@6" pad="6"/>
<connect gate="G$1" pin="PWM@11" pad="11"/>
<connect gate="G$1" pin="VDD@15" pad="15"/>
<connect gate="G$1" pin="VIN@1" pad="1"/>
<connect gate="G$1" pin="VIN@2" pad="2"/>
<connect gate="G$1" pin="VOUT@17" pad="17"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10723836/6"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.st.com/content/ccc/resource/technical/document/data_brief/3b/bf/c3/13/d5/b2/4c/b0/DM00101248.pdf/files/DM00101248.pdf/jcr:content/translations/en.DM00101248.pdf" constant="no"/>
<attribute name="DESCR" value="VNH5019 Motor Controller/Driver Power Management Evaluation Board" constant="no"/>
<attribute name="DIGIKEY_NO" value="497-14839-ND" constant="no"/>
<attribute name="MF" value="Pololu" constant="no"/>
<attribute name="MF_PN" value="1451" constant="no"/>
<attribute name="PURCHASE" value="https://www.digikey.de/product-detail/de/stmicro/EVAL-VNH5019-P1/497-14839-ND/4869482?utm_adgroup=Dev+Boards+and+Kits&amp;mkwid=siS2m191I&amp;pcrid=218211101233&amp;pkw=&amp;pmt=&amp;pdv=c&amp;productid=4869482&amp;slid=&amp;gclid=CjwKCAjw2cTmBRAVEiwA8YMgzaipRkISnCfVdTSSKNDcojFwUwpzQeKwWGZWYQUEEXtJxoFNqy7q1BoC5-sQAvD_BwE" constant="no"/>
<attribute name="UNIT_PRICE" value="33.42" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="BNO055" urn="urn:adsk.eagle:component:10723859/8" prefix="A" library_version="76">
<description>&lt;b&gt;BREAKOUT BOARD&lt;/b&gt;&lt;p&gt;
Adafruit BNO055 Absolute Orientation Sensor&lt;p&gt;
&lt;a href="https://learn.adafruit.com/adafruit-bno055-absolute-orientation-sensor/overview"&gt;https://learn.adafruit.com/adafruit-bno055-absolute-orientation-sensor/overview&lt;/a&gt;&lt;p&gt;</description>
<gates>
<gate name="G$1" symbol="BNO055" x="0" y="0"/>
</gates>
<devices>
<device name="" package="BNO055">
<connects>
<connect gate="G$1" pin="3VO@2" pad="2"/>
<connect gate="G$1" pin="ADR@7" pad="7"/>
<connect gate="G$1" pin="GND@3" pad="3"/>
<connect gate="G$1" pin="INT@8" pad="8"/>
<connect gate="G$1" pin="PS0@10" pad="10"/>
<connect gate="G$1" pin="PS1@9" pad="9"/>
<connect gate="G$1" pin="RST@6" pad="6"/>
<connect gate="G$1" pin="SCL@5" pad="5"/>
<connect gate="G$1" pin="SDA@4" pad="4"/>
<connect gate="G$1" pin="VIN@1" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10723845/4"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://cdn-learn.adafruit.com/downloads/pdf/adafruit-bno055-absolute-orientation-sensor.pdf" constant="no"/>
<attribute name="DESCR" value="Acceleration Sensor Development Tools Adafruit 9-DOF Absolute Orientation IMU Fusion Breakout - BNO055" constant="no"/>
<attribute name="MF" value="Adafruit" constant="no"/>
<attribute name="MF_PN" value="2472" constant="no"/>
<attribute name="MOUSER_NO" value="485-2472" constant="no"/>
<attribute name="PURCHASE" value="https://www.reichelt.de/development-boards-sensor-with-different-functions-debo-sens-combi-p235479.html?PROVID=2788&amp;gclid=EAIaIQobChMIppaP2Nqd4gIVA853Ch3mIQILEAYYASABEgKn7_D_BwE&amp;&amp;r=1 " constant="no"/>
<attribute name="REICHELT_NO" value="DEBO SENS COMBI " constant="no"/>
<attribute name="UNIT_PRICE" value="30.52" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="TXB0104PWR" urn="urn:adsk.eagle:component:10752478/6" prefix="U" library_version="76">
<description>&lt;b&gt;Level Translator&lt;/b&gt;&lt;p&gt;
Voltage Levels 4-Bit Bi-directional V-Level Translator&lt;p&gt;
Hook-Up Guide: &lt;a href="https://learn.sparkfun.com/tutorials/txb0104-level-shifter-hookup-guide?_ga=2.72129811.147430699.1557226341-1031609347.1554294114"&gt;TXB0104 Level Shifter Hookup Guide&lt;/a&gt;</description>
<gates>
<gate name="A" symbol="TXB0104PWR" x="0" y="0"/>
</gates>
<devices>
<device name="" package="PW14">
<connects>
<connect gate="A" pin="A1" pad="2"/>
<connect gate="A" pin="A2" pad="3"/>
<connect gate="A" pin="A3" pad="4"/>
<connect gate="A" pin="A4" pad="5"/>
<connect gate="A" pin="B1" pad="13"/>
<connect gate="A" pin="B2" pad="12"/>
<connect gate="A" pin="B3" pad="11"/>
<connect gate="A" pin="B4" pad="10"/>
<connect gate="A" pin="GND" pad="7"/>
<connect gate="A" pin="NC" pad="9"/>
<connect gate="A" pin="NC_2" pad="6"/>
<connect gate="A" pin="OE" pad="8"/>
<connect gate="A" pin="VCCA" pad="1"/>
<connect gate="A" pin="VCCB" pad="14"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10752475/3"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="http://www.ti.com/lit/ds/symlink/txb0104.pdf" constant="no"/>
<attribute name="DESCR" value="Translation - Voltage Levels 4-Bit Bi-directional V-Level Translator" constant="no"/>
<attribute name="FARNELL_NO" value="1607891" constant="no"/>
<attribute name="MF" value="Texas Instruments" constant="no"/>
<attribute name="MF_PN" value="TXB0104PWR" constant="no"/>
<attribute name="MOUSER_NO" value="595-TXB0104PWR" constant="no"/>
<attribute name="PACKAGE" value="TSSOP-14" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/texas-instruments/txb0104pwr/ic-sm-logik-translator/dp/1607891" constant="no"/>
<attribute name="UNIT_PRICE" value="1.11" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="BAS40-04" urn="urn:adsk.eagle:component:10681402/6" prefix="D" library_version="76">
<description>&lt;b&gt;Silicon Schottky Diodes&lt;/b&gt;&lt;p&gt;
General-purpose diode for high-speed switching</description>
<gates>
<gate name="D$1" symbol="SDD_AKAK" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT23">
<connects>
<connect gate="D$1" pin="A1" pad="1"/>
<connect gate="D$1" pin="C1A2" pad="3"/>
<connect gate="D$1" pin="C2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10831617/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.onsemi.com/pub/Collateral/BAS40-04LT1-D.PDF" constant="no"/>
<attribute name="DESCR" value="Schottky Diodes &amp; Rectifiers 40V 225mW Dual" constant="no"/>
<attribute name="FARNELL_NO" value="2317418" constant="no"/>
<attribute name="MF" value="ON Semiconductor" constant="no"/>
<attribute name="MF_PN" value="BAS40-04LT1G" constant="no"/>
<attribute name="MOUSER_NO" value="863-BAS40-04LT1G " constant="no"/>
<attribute name="PACKAGE" value="SOT-23-3" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/on-semiconductor/bas40-04lt1g/schottky-diode-40ma-40v-sot-23/dp/2317418 " constant="no"/>
<attribute name="UNIT_PRICE" value="0.236" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="BSS123" urn="urn:adsk.eagle:component:10681853/5" prefix="Q" library_version="76">
<description>&lt;b&gt;MOSFET&lt;/b&gt;&lt;p&gt;
N-Channel MOSFET&lt;p&gt;</description>
<gates>
<gate name="Q$1" symbol="N-MOS" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT23">
<connects>
<connect gate="Q$1" pin="D" pad="3"/>
<connect gate="Q$1" pin="G" pad="1"/>
<connect gate="Q$1" pin="S" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10831617/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.onsemi.com/pub/Collateral/BSS123-D.PDF" constant="no"/>
<attribute name="DESCR" value="MOSFET SOT-23 N-CH LOGIC" constant="no"/>
<attribute name="FARNELL_NO" value="9845330" constant="no"/>
<attribute name="MF" value="ON Semiconductor" constant="no"/>
<attribute name="MF_PN" value="BSS123" constant="no"/>
<attribute name="MOUSER_NO" value="512-BSS123" constant="no"/>
<attribute name="PACKAGE" value="SOT-23-3" constant="no"/>
<attribute name="PURCHASE" value="https://de.farnell.com/on-semiconductor/bss123/mosfet-n-kanal-100v-sot-23/dp/9845321" constant="no"/>
<attribute name="UNIT_PRICE" value="0.236" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PINHD-1X2" urn="urn:adsk.eagle:component:10738175/4" prefix="JP" library_version="69">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="G$1" symbol="PINHD2" x="2.54" y="0"/>
</gates>
<devices>
<device name="" package="1X02">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22435/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="Straight" constant="no"/>
<attribute name="PACKAGE" value="Pin Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="2" constant="no"/>
<attribute name="ROWS" value="1" constant="no"/>
</technology>
</technologies>
</device>
<device name="/90" package="1X02/90">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22437/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="90" constant="no"/>
<attribute name="DESCR" value="Pin Header 1X2 90DEG" constant="no"/>
<attribute name="PACKAGE" value="Pin Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="2" constant="no"/>
<attribute name="ROWS" value="1" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PINHD-1X3" urn="urn:adsk.eagle:component:12237007/1" prefix="JP" uservalue="yes" library_version="78">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="PINHD3" x="0" y="0"/>
</gates>
<devices>
<device name="" package="1X03">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22458/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="Straight" constant="no"/>
<attribute name="PACKAGE" value="Pin Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="4" constant="no"/>
<attribute name="ROWS" value="1" constant="no"/>
</technology>
</technologies>
</device>
<device name="/90" package="1X03/90">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:22459/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="90" constant="no"/>
<attribute name="PACKAGE" value="Pin Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="3" constant="no"/>
<attribute name="ROWS" value="1" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="U2" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="LM358" device="D" package3d_urn="urn:adsk.eagle:package:10681740/1"/>
<part name="IC1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="ATMEGA*" device="AU" package3d_urn="urn:adsk.eagle:package:10682030/2" technology="2560-16"/>
<part name="R03" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="1,2k"/>
<part name="R02" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="22k"/>
<part name="R07" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="560k"/>
<part name="R08" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="560k"/>
<part name="R52" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="1k 0,1%"/>
<part name="R51" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="10k 0,1%"/>
<part name="C52" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="4,7uF"/>
<part name="C61" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="C62" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="C53" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="C56" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="C54" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="C51" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="C55" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="QG1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="XO91" device="" package3d_urn="urn:adsk.eagle:package:12177396/1"/>
<part name="Q01" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="IRF3808" device="" package3d_urn="urn:adsk.eagle:package:10682687/2"/>
<part name="R04" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="12k"/>
<part name="GND1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND4" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND5" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="C71" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="10nF"/>
<part name="GND6" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="P+1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="P+2" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="P+3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="RN1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="RN04" device="" package3d_urn="urn:adsk.eagle:package:10682942/2" value="10k"/>
<part name="C02" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="R15" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="330"/>
<part name="GND8" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R16" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="330"/>
<part name="GND9" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R17" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="330"/>
<part name="GND10" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R18" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="330"/>
<part name="GND11" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND12" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="P+11" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="GND14" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND15" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="EXT_PINS" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="PINHD-2X5" device="" package3d_urn="urn:adsk.eagle:package:22470/2"/>
<part name="Q14" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="BSS123" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="Q12" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="BSS123" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="Q11" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="BSS123" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="Q13" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="BSS123" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="R/W" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="PINHD-1X2" device="/90" package3d_urn="urn:adsk.eagle:package:22437/2" value="PINHD-1X2/90"/>
<part name="P1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="NCP1117" device="" package3d_urn="urn:adsk.eagle:package:10681910/3"/>
<part name="C31" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="CPOL" device="/6,3X7,7" package3d_urn="urn:adsk.eagle:package:10681938/3" value="220uF"/>
<part name="GND17" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND18" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND19" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="R01" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="22k"/>
<part name="C01" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="CPOL" device="/4X5,8" package3d_urn="urn:adsk.eagle:package:10681681/3" value="10uF"/>
<part name="D01" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="BAS40-04" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="C63" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="CPOL" device="/6,3X7,7" package3d_urn="urn:adsk.eagle:package:10681938/3" value="220uF"/>
<part name="C81" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="CPOL" device="/6,3X7,7" package3d_urn="urn:adsk.eagle:package:10681938/3" value="220uF"/>
<part name="R05" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="0"/>
<part name="R06" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="0"/>
<part name="R11" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="180"/>
<part name="R12" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="180"/>
<part name="R13" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="180"/>
<part name="R14" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="R-EU" device="R0805" package3d_urn="urn:adsk.eagle:package:10736717/2" value="180"/>
<part name="JP1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="WSL_10G" device="" package3d_urn="urn:adsk.eagle:package:10681399/5"/>
<part name="JTAG" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="PINHD-2X5" device="/JTAG" package3d_urn="urn:adsk.eagle:package:10681960/4"/>
<part name="JP2" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="SCREWTERM_4POL_3.5MM" device="" package3d_urn="urn:adsk.eagle:package:10723840/3"/>
<part name="U1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="LM385-1.2/NOPB" device="" package3d_urn="urn:adsk.eagle:package:10681740/1"/>
<part name="IC2" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="RPI-ZERO" device="" package3d_urn="urn:adsk.eagle:package:10723842/6"/>
<part name="A2" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="VNH5019" device="" package3d_urn="urn:adsk.eagle:package:10723836/6"/>
<part name="A1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="BNO055" device="" package3d_urn="urn:adsk.eagle:package:10723845/4"/>
<part name="U3" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="TXB0104PWR" device="" package3d_urn="urn:adsk.eagle:package:10752475/3"/>
<part name="C42" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="C41" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="100nF"/>
<part name="P+6" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="+3V1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+3V3" device=""/>
<part name="+3V3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+3V3" device=""/>
<part name="+3V2" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+3V3" device=""/>
<part name="GND13" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND20" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND21" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="SERVO" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="PINHD-1X3" device="/90" package3d_urn="urn:adsk.eagle:package:22459/2" value="PINHD-1X3/90"/>
</parts>
<sheets>
<sheet>
<plain>
<wire x1="431.8" y1="406.4" x2="589.28" y2="406.4" width="0.8128" layer="199"/>
<wire x1="589.28" y1="406.4" x2="589.28" y2="215.9" width="0.8128" layer="199"/>
<wire x1="589.28" y1="215.9" x2="523.24" y2="215.9" width="0.8128" layer="199"/>
<wire x1="523.24" y1="215.9" x2="431.8" y2="215.9" width="0.8128" layer="199"/>
<wire x1="431.8" y1="215.9" x2="431.8" y2="271.78" width="0.8128" layer="199"/>
<wire x1="431.8" y1="271.78" x2="431.8" y2="406.4" width="0.8128" layer="199"/>
<wire x1="431.8" y1="215.9" x2="431.8" y2="127" width="0.8128" layer="199"/>
<wire x1="431.8" y1="127" x2="523.24" y2="127" width="0.8128" layer="199"/>
<wire x1="523.24" y1="127" x2="589.28" y2="127" width="0.8128" layer="199"/>
<wire x1="589.28" y1="127" x2="589.28" y2="215.9" width="0.8128" layer="199"/>
<text x="27.94" y="170.18" size="3.81" layer="199">Erweiterungs-Pins</text>
<wire x1="431.8" y1="406.4" x2="284.48" y2="406.4" width="0.8128" layer="199"/>
<wire x1="284.48" y1="406.4" x2="193.04" y2="406.4" width="0.8128" layer="199"/>
<wire x1="193.04" y1="406.4" x2="193.04" y2="330.2" width="0.8128" layer="199"/>
<text x="525.78" y="210.82" size="3.81" layer="199">Oszillator</text>
<text x="434.34" y="210.82" size="3.81" layer="199">Spannungswandler</text>
<wire x1="431.8" y1="127" x2="284.48" y2="127" width="0.8128" layer="199"/>
<wire x1="284.48" y1="127" x2="193.04" y2="127" width="0.8128" layer="199"/>
<wire x1="193.04" y1="127" x2="25.4" y2="127" width="0.8128" layer="199"/>
<wire x1="25.4" y1="127" x2="25.4" y2="175.26" width="0.8128" layer="199"/>
<wire x1="25.4" y1="175.26" x2="25.4" y2="220.98" width="0.8128" layer="199"/>
<wire x1="25.4" y1="220.98" x2="25.4" y2="271.78" width="0.8128" layer="199"/>
<wire x1="25.4" y1="271.78" x2="25.4" y2="330.2" width="0.8128" layer="199"/>
<wire x1="25.4" y1="330.2" x2="25.4" y2="406.4" width="0.8128" layer="199"/>
<wire x1="25.4" y1="406.4" x2="193.04" y2="406.4" width="0.8128" layer="199"/>
<wire x1="25.4" y1="330.2" x2="193.04" y2="330.2" width="0.8128" layer="199"/>
<wire x1="284.48" y1="406.4" x2="284.48" y2="330.2" width="0.8128" layer="199"/>
<wire x1="193.04" y1="330.2" x2="193.04" y2="271.78" width="0.8128" layer="199"/>
<wire x1="193.04" y1="271.78" x2="193.04" y2="220.98" width="0.8128" layer="199"/>
<wire x1="193.04" y1="220.98" x2="193.04" y2="175.26" width="0.8128" layer="199"/>
<wire x1="193.04" y1="175.26" x2="193.04" y2="127" width="0.8128" layer="199"/>
<text x="27.94" y="401.32" size="3.81" layer="199">Batterieschutzschaltung</text>
<text x="27.94" y="325.12" size="3.81" layer="199">LED-Ansteuerung</text>
<text x="27.94" y="215.9" size="3.81" layer="199">JTAG</text>
<text x="195.58" y="170.18" size="3.81" layer="199">Spannungsversorgung</text>
<text x="27.94" y="266.7" size="3.81" layer="199">Servo-Anschluss</text>
<text x="195.58" y="325.12" size="3.81" layer="199">Motor-Steuerung</text>
<text x="195.58" y="266.7" size="3.81" layer="199">Drehzallmessung</text>
<text x="195.58" y="401.32" size="3.81" layer="199">IMU</text>
<text x="287.02" y="401.32" size="3.81" layer="199">Raspberry Pi</text>
<text x="434.34" y="401.32" size="3.81" layer="199">uControler</text>
<text x="78.74" y="337.82" size="1.778" layer="97" rot="R180">Statt Transistor
Spannungsregler</text>
<text x="195.58" y="261.62" size="1.778" layer="199">Odometer Anschluss</text>
<text x="195.58" y="256.54" size="1.778" layer="199">LED Anschluss</text>
<wire x1="25.4" y1="271.78" x2="193.04" y2="271.78" width="0.8128" layer="199"/>
<wire x1="523.24" y1="215.9" x2="523.24" y2="127" width="0.8128" layer="199"/>
<wire x1="25.4" y1="175.26" x2="193.04" y2="175.26" width="0.8128" layer="199"/>
<wire x1="25.4" y1="220.98" x2="193.04" y2="220.98" width="0.8128" layer="199"/>
<wire x1="193.04" y1="330.2" x2="284.48" y2="330.2" width="0.8128" layer="199"/>
<wire x1="284.48" y1="271.78" x2="284.48" y2="175.26" width="0.8128" layer="199"/>
<wire x1="284.48" y1="175.26" x2="284.48" y2="127" width="0.8128" layer="199"/>
<wire x1="193.04" y1="271.78" x2="284.48" y2="271.78" width="0.8128" layer="199"/>
<wire x1="193.04" y1="175.26" x2="284.48" y2="175.26" width="0.8128" layer="199"/>
<wire x1="284.48" y1="330.2" x2="284.48" y2="271.78" width="0.8128" layer="199"/>
<text x="294.64" y="256.54" size="1.778" layer="95">A side Vcc from 1.2 to 3.6V</text>
<text x="373.38" y="256.54" size="1.778" layer="95">B side Vcc from 1.65 to 5V</text>
<text x="330.2" y="261.62" size="1.778" layer="95">VccA *must* be less than VccB!</text>
<wire x1="284.48" y1="271.78" x2="431.8" y2="271.78" width="0.8128" layer="199"/>
<text x="287.02" y="266.7" size="3.81" layer="199">SPI Level Converter</text>
</plain>
<instances>
<instance part="U2" gate="A" x="119.38" y="363.22" smashed="yes">
<attribute name="NAME" x="121.92" y="366.395" size="1.778" layer="95"/>
<attribute name="VALUE" x="121.92" y="358.14" size="1.778" layer="96"/>
</instance>
<instance part="IC1" gate="G$1" x="523.24" y="307.34" smashed="yes">
<attribute name="VALUE" x="492.76" y="228.6" size="1.778" layer="96"/>
<attribute name="NAME" x="492.76" y="387.35" size="1.778" layer="95"/>
</instance>
<instance part="R03" gate="G$1" x="99.06" y="368.3" smashed="yes" rot="R90">
<attribute name="NAME" x="97.5614" y="364.49" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="102.362" y="364.49" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R02" gate="G$1" x="99.06" y="381" smashed="yes" rot="R90">
<attribute name="NAME" x="97.5614" y="377.19" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="102.362" y="377.19" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R07" gate="G$1" x="121.92" y="373.38" smashed="yes">
<attribute name="NAME" x="118.11" y="374.8786" size="1.778" layer="95"/>
<attribute name="VALUE" x="118.11" y="370.078" size="1.778" layer="96"/>
</instance>
<instance part="R08" gate="G$1" x="86.36" y="383.54" smashed="yes" rot="R90">
<attribute name="NAME" x="84.8614" y="379.73" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="89.662" y="379.73" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R52" gate="G$1" x="444.5" y="274.32" smashed="yes" rot="R90">
<attribute name="NAME" x="443.0014" y="270.51" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="447.802" y="270.51" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R51" gate="G$1" x="444.5" y="289.56" smashed="yes" rot="R90">
<attribute name="NAME" x="443.0014" y="285.75" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="447.802" y="285.75" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="C52" gate="G$1" x="464.82" y="276.86" smashed="yes">
<attribute name="NAME" x="458.724" y="277.241" size="1.778" layer="95"/>
<attribute name="VALUE" x="458.724" y="272.161" size="1.778" layer="96"/>
</instance>
<instance part="C61" gate="G$1" x="449.58" y="167.64" smashed="yes">
<attribute name="NAME" x="451.104" y="168.021" size="1.778" layer="95"/>
<attribute name="VALUE" x="451.104" y="162.941" size="1.778" layer="96"/>
</instance>
<instance part="C62" gate="G$1" x="497.84" y="167.64" smashed="yes">
<attribute name="NAME" x="499.364" y="168.021" size="1.778" layer="95"/>
<attribute name="VALUE" x="499.364" y="162.941" size="1.778" layer="96"/>
</instance>
<instance part="C53" gate="G$1" x="472.44" y="355.6" smashed="yes" rot="R270">
<attribute name="NAME" x="472.821" y="359.156" size="1.778" layer="95" rot="R270"/>
<attribute name="VALUE" x="475.361" y="361.696" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="C56" gate="G$1" x="467.36" y="347.98" smashed="yes" rot="R270">
<attribute name="NAME" x="460.121" y="346.456" size="1.778" layer="95" rot="R270"/>
<attribute name="VALUE" x="462.661" y="346.456" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="C54" gate="G$1" x="467.36" y="353.06" smashed="yes" rot="R270">
<attribute name="NAME" x="460.121" y="356.616" size="1.778" layer="95" rot="R270"/>
<attribute name="VALUE" x="462.661" y="356.616" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="C51" gate="G$1" x="459.74" y="373.38" smashed="yes" rot="R180">
<attribute name="NAME" x="458.216" y="372.999" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="458.216" y="378.079" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="C55" gate="G$1" x="472.44" y="350.52" smashed="yes" rot="R270">
<attribute name="NAME" x="472.821" y="348.996" size="1.778" layer="95" rot="R270"/>
<attribute name="VALUE" x="475.361" y="348.996" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="QG1" gate="G$1" x="556.26" y="177.8" smashed="yes">
<attribute name="NAME" x="548.64" y="184.15" size="1.778" layer="95"/>
<attribute name="VALUE" x="548.64" y="170.18" size="1.778" layer="96"/>
</instance>
<instance part="Q01" gate="Q$1" x="137.16" y="353.06" smashed="yes" rot="R270">
<attribute name="VALUE" x="137.16" y="364.49" size="1.778" layer="96" rot="R270"/>
<attribute name="NAME" x="139.7" y="364.49" size="1.778" layer="95" rot="R270"/>
</instance>
<instance part="R04" gate="G$1" x="99.06" y="353.06" smashed="yes" rot="R270">
<attribute name="NAME" x="100.5586" y="356.87" size="1.778" layer="95" rot="R270"/>
<attribute name="VALUE" x="95.758" y="356.87" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="U2" gate="P" x="167.64" y="368.3" smashed="yes"/>
<instance part="GND1" gate="1" x="472.44" y="154.94" smashed="yes">
<attribute name="VALUE" x="469.9" y="152.4" size="1.778" layer="96"/>
</instance>
<instance part="GND3" gate="1" x="459.74" y="386.08" smashed="yes" rot="R180">
<attribute name="VALUE" x="462.28" y="388.62" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="GND4" gate="1" x="469.9" y="335.28" smashed="yes">
<attribute name="VALUE" x="467.36" y="332.74" size="1.778" layer="96"/>
</instance>
<instance part="GND5" gate="1" x="444.5" y="363.22" smashed="yes" rot="R270">
<attribute name="VALUE" x="441.96" y="365.76" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="C71" gate="G$1" x="535.94" y="175.26" smashed="yes" rot="R180">
<attribute name="NAME" x="534.416" y="174.879" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="534.416" y="179.959" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="GND6" gate="1" x="541.02" y="165.1" smashed="yes">
<attribute name="VALUE" x="538.48" y="162.56" size="1.778" layer="96"/>
</instance>
<instance part="P+1" gate="1" x="449.58" y="375.92" smashed="yes">
<attribute name="VALUE" x="447.04" y="373.38" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="P+2" gate="1" x="541.02" y="187.96" smashed="yes">
<attribute name="VALUE" x="543.56" y="190.5" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+3" gate="1" x="515.62" y="180.34" smashed="yes" rot="R270">
<attribute name="VALUE" x="510.54" y="182.88" size="1.778" layer="96"/>
</instance>
<instance part="RN1" gate="G$1" x="139.7" y="182.88" smashed="yes" rot="R180">
<attribute name="NAME" x="142.24" y="180.34" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="142.24" y="187.198" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="C02" gate="G$1" x="180.34" y="368.3" smashed="yes">
<attribute name="NAME" x="181.864" y="368.681" size="1.778" layer="95"/>
<attribute name="VALUE" x="181.864" y="363.601" size="1.778" layer="96"/>
</instance>
<instance part="R15" gate="G$1" x="55.88" y="307.34" smashed="yes" rot="R90">
<attribute name="NAME" x="54.3814" y="303.53" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="59.182" y="303.53" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND8" gate="1" x="55.88" y="284.48" smashed="yes">
<attribute name="VALUE" x="53.34" y="281.94" size="1.778" layer="96"/>
</instance>
<instance part="R16" gate="G$1" x="96.52" y="307.34" smashed="yes" rot="R90">
<attribute name="NAME" x="95.0214" y="303.53" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="99.822" y="303.53" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND9" gate="1" x="96.52" y="284.48" smashed="yes">
<attribute name="VALUE" x="93.98" y="281.94" size="1.778" layer="96"/>
</instance>
<instance part="R17" gate="G$1" x="137.16" y="307.34" smashed="yes" rot="R90">
<attribute name="NAME" x="135.6614" y="303.53" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="140.462" y="303.53" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND10" gate="1" x="137.16" y="284.48" smashed="yes">
<attribute name="VALUE" x="134.62" y="281.94" size="1.778" layer="96"/>
</instance>
<instance part="R18" gate="G$1" x="177.8" y="307.34" smashed="yes" rot="R90">
<attribute name="NAME" x="176.3014" y="303.53" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="181.102" y="303.53" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND11" gate="1" x="177.8" y="284.48" smashed="yes">
<attribute name="VALUE" x="175.26" y="281.94" size="1.778" layer="96"/>
</instance>
<instance part="GND12" gate="1" x="464.82" y="266.7" smashed="yes">
<attribute name="VALUE" x="462.28" y="264.16" size="1.778" layer="96"/>
</instance>
<instance part="P+11" gate="1" x="396.24" y="386.08" smashed="yes">
<attribute name="VALUE" x="396.24" y="388.62" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND14" gate="1" x="396.24" y="363.22" smashed="yes">
<attribute name="VALUE" x="393.7" y="360.68" size="1.778" layer="96"/>
</instance>
<instance part="GND15" gate="1" x="444.5" y="259.08" smashed="yes">
<attribute name="VALUE" x="441.96" y="256.54" size="1.778" layer="96"/>
</instance>
<instance part="EXT_PINS" gate="A" x="106.68" y="144.78" smashed="yes">
<attribute name="NAME" x="110.49" y="136.525" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="113.03" y="154.94" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="Q14" gate="Q$1" x="177.8" y="294.64" smashed="yes">
<attribute name="NAME" x="180.34" y="294.64" size="1.778" layer="95"/>
<attribute name="VALUE" x="180.34" y="292.1" size="1.778" layer="96"/>
</instance>
<instance part="Q12" gate="Q$1" x="96.52" y="294.64" smashed="yes">
<attribute name="NAME" x="99.06" y="294.64" size="1.778" layer="95"/>
<attribute name="VALUE" x="99.06" y="292.1" size="1.778" layer="96"/>
</instance>
<instance part="Q11" gate="Q$1" x="55.88" y="294.64" smashed="yes">
<attribute name="NAME" x="58.42" y="294.64" size="1.778" layer="95"/>
<attribute name="VALUE" x="58.42" y="292.1" size="1.778" layer="96"/>
</instance>
<instance part="Q13" gate="Q$1" x="137.16" y="294.64" smashed="yes">
<attribute name="NAME" x="139.7" y="294.64" size="1.778" layer="95"/>
<attribute name="VALUE" x="139.7" y="292.1" size="1.778" layer="96"/>
</instance>
<instance part="R/W" gate="G$1" x="312.42" y="373.38" smashed="yes" rot="R180">
<attribute name="NAME" x="318.77" y="367.665" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="318.77" y="378.46" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P1" gate="P$1" x="474.98" y="182.88" smashed="yes">
<attribute name="NAME" x="457.2" y="167.64" size="1.778" layer="95"/>
<attribute name="VALUE" x="467.36" y="190.5" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="C31" gate="C$1" x="403.86" y="375.92" smashed="yes">
<attribute name="NAME" x="405.003" y="376.4026" size="1.778" layer="95"/>
<attribute name="VALUE" x="405.003" y="371.3226" size="1.778" layer="96"/>
</instance>
<instance part="GND17" gate="1" x="322.58" y="320.04" smashed="yes">
<attribute name="VALUE" x="320.04" y="317.5" size="1.778" layer="96"/>
</instance>
<instance part="GND18" gate="1" x="391.16" y="320.04" smashed="yes">
<attribute name="VALUE" x="388.62" y="317.5" size="1.778" layer="96"/>
</instance>
<instance part="GND19" gate="1" x="322.58" y="363.22" smashed="yes">
<attribute name="VALUE" x="320.04" y="360.68" size="1.778" layer="96"/>
</instance>
<instance part="R01" gate="G$1" x="99.06" y="393.7" smashed="yes" rot="R90">
<attribute name="NAME" x="97.5614" y="389.89" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="102.362" y="389.89" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="C01" gate="C$1" x="50.8" y="378.46" smashed="yes">
<attribute name="NAME" x="51.943" y="378.9426" size="1.778" layer="95"/>
<attribute name="VALUE" x="51.943" y="373.8626" size="1.778" layer="96"/>
</instance>
<instance part="D01" gate="D$1" x="43.18" y="396.24" smashed="yes">
<attribute name="NAME" x="43.942" y="398.2466" size="1.778" layer="95"/>
<attribute name="VALUE" x="38.862" y="392.2776" size="1.778" layer="96"/>
</instance>
<instance part="C63" gate="C$1" x="508" y="167.64" smashed="yes">
<attribute name="NAME" x="509.143" y="168.1226" size="1.778" layer="95"/>
<attribute name="VALUE" x="509.143" y="163.0426" size="1.778" layer="96"/>
</instance>
<instance part="C81" gate="C$1" x="254" y="147.32" smashed="yes">
<attribute name="NAME" x="255.143" y="147.8026" size="1.778" layer="95"/>
<attribute name="VALUE" x="255.143" y="142.7226" size="1.778" layer="96"/>
</instance>
<instance part="R05" gate="G$1" x="104.14" y="345.44" smashed="yes">
<attribute name="NAME" x="100.33" y="346.9386" size="1.778" layer="95"/>
<attribute name="VALUE" x="100.33" y="342.138" size="1.778" layer="96"/>
</instance>
<instance part="R06" gate="G$1" x="116.84" y="345.44" smashed="yes">
<attribute name="NAME" x="113.03" y="346.9386" size="1.778" layer="95"/>
<attribute name="VALUE" x="113.03" y="342.138" size="1.778" layer="96"/>
</instance>
<instance part="R11" gate="G$1" x="43.18" y="292.1" smashed="yes">
<attribute name="NAME" x="39.37" y="293.5986" size="1.778" layer="95"/>
<attribute name="VALUE" x="39.37" y="288.798" size="1.778" layer="96"/>
</instance>
<instance part="R12" gate="G$1" x="83.82" y="292.1" smashed="yes">
<attribute name="NAME" x="80.01" y="293.5986" size="1.778" layer="95"/>
<attribute name="VALUE" x="80.01" y="288.798" size="1.778" layer="96"/>
</instance>
<instance part="R13" gate="G$1" x="124.46" y="292.1" smashed="yes">
<attribute name="NAME" x="120.65" y="293.5986" size="1.778" layer="95"/>
<attribute name="VALUE" x="120.65" y="288.798" size="1.778" layer="96"/>
</instance>
<instance part="R14" gate="G$1" x="165.1" y="292.1" smashed="yes">
<attribute name="NAME" x="161.29" y="293.5986" size="1.778" layer="95"/>
<attribute name="VALUE" x="161.29" y="288.798" size="1.778" layer="96"/>
</instance>
<instance part="JP1" gate="G$1" x="236.22" y="226.06" smashed="yes">
<attribute name="NAME" x="229.87" y="234.315" size="1.778" layer="95"/>
<attribute name="VALUE" x="229.87" y="215.9" size="1.778" layer="96"/>
</instance>
<instance part="JTAG" gate="A" x="109.22" y="195.58" smashed="yes" rot="R180">
<attribute name="NAME" x="115.57" y="187.325" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="115.57" y="205.74" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="JP2" gate="G$1" x="243.84" y="142.24" smashed="yes">
<attribute name="NAME" x="237.49" y="150.495" size="1.778" layer="95"/>
<attribute name="VALUE" x="237.49" y="134.62" size="1.778" layer="96"/>
</instance>
<instance part="U1" gate="G$1" x="73.66" y="353.06" smashed="yes">
<attribute name="NAME" x="71.12" y="365.76" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="63.5" y="340.36" size="1.778" layer="96"/>
</instance>
<instance part="IC2" gate="A$1" x="355.6" y="345.44" smashed="yes">
<attribute name="NAME" x="335.28" y="381" size="1.27" layer="95" font="vector"/>
<attribute name="VALUE" x="335.28" y="379.095" size="1.27" layer="96" font="vector"/>
</instance>
<instance part="A2" gate="G$1" x="233.68" y="297.18" smashed="yes" rot="MR0">
<attribute name="NAME" x="238.76" y="317.5" size="1.778" layer="95" rot="MR180"/>
<attribute name="VALUE" x="246.38" y="284.48" size="1.778" layer="96" rot="MR0"/>
</instance>
<instance part="A1" gate="G$1" x="241.3" y="365.76" smashed="yes">
<attribute name="NAME" x="236.22" y="378.46" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="228.6" y="355.6" size="1.778" layer="96"/>
</instance>
<instance part="U3" gate="A" x="353.06" y="233.68" smashed="yes">
<attribute name="NAME" x="330.5556" y="247.8786" size="2.0828" layer="95" ratio="6" rot="SR0"/>
<attribute name="VALUE" x="329.9206" y="217.3986" size="2.0828" layer="96" ratio="6" rot="SR0"/>
</instance>
<instance part="C42" gate="G$1" x="396.24" y="243.84" smashed="yes" rot="MR180">
<attribute name="NAME" x="397.764" y="243.459" size="1.778" layer="95" rot="MR180"/>
<attribute name="VALUE" x="397.764" y="248.539" size="1.778" layer="96" rot="MR180"/>
</instance>
<instance part="C41" gate="G$1" x="304.8" y="243.84" smashed="yes" rot="R180">
<attribute name="NAME" x="303.276" y="243.459" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="303.276" y="248.539" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+6" gate="1" x="386.08" y="251.46" smashed="yes">
<attribute name="VALUE" x="383.54" y="251.46" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="+3V1" gate="G$1" x="320.04" y="251.46" smashed="yes">
<attribute name="VALUE" x="317.5" y="246.38" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="+3V3" gate="G$1" x="393.7" y="226.06" smashed="yes" rot="R270">
<attribute name="VALUE" x="393.7" y="226.06" size="1.778" layer="96"/>
</instance>
<instance part="+3V2" gate="G$1" x="327.66" y="386.08" smashed="yes">
<attribute name="VALUE" x="325.12" y="381" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND13" gate="1" x="304.8" y="251.46" smashed="yes" rot="R180">
<attribute name="VALUE" x="307.34" y="254" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="GND20" gate="1" x="396.24" y="251.46" smashed="yes" rot="R180">
<attribute name="VALUE" x="398.78" y="254" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="GND21" gate="1" x="307.34" y="226.06" smashed="yes" rot="R270">
<attribute name="VALUE" x="304.8" y="228.6" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="SERVO" gate="A" x="48.26" y="241.3" smashed="yes" rot="R180">
<attribute name="NAME" x="54.61" y="235.585" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="54.61" y="248.92" size="1.778" layer="96" rot="R180"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="N$2" class="0">
<segment>
<pinref part="U2" gate="A" pin="+IN"/>
<wire x1="111.76" y1="365.76" x2="106.68" y2="365.76" width="0.1524" layer="91"/>
<pinref part="R07" gate="G$1" pin="1"/>
<wire x1="106.68" y1="365.76" x2="106.68" y2="373.38" width="0.1524" layer="91"/>
<wire x1="106.68" y1="373.38" x2="116.84" y2="373.38" width="0.1524" layer="91"/>
<pinref part="R03" gate="G$1" pin="1"/>
<pinref part="R04" gate="G$1" pin="1"/>
<wire x1="99.06" y1="358.14" x2="99.06" y2="363.22" width="0.1524" layer="91"/>
<wire x1="106.68" y1="365.76" x2="106.68" y2="363.22" width="0.1524" layer="91"/>
<wire x1="106.68" y1="363.22" x2="99.06" y2="363.22" width="0.1524" layer="91"/>
<junction x="106.68" y="365.76"/>
<junction x="99.06" y="363.22"/>
</segment>
</net>
<net name="BAT_GND" class="0">
<segment>
<label x="27.94" y="340.36" size="1.778" layer="95"/>
<wire x1="50.8" y1="340.36" x2="58.42" y2="340.36" width="0.1524" layer="91"/>
<wire x1="50.8" y1="373.38" x2="50.8" y2="340.36" width="0.1524" layer="91"/>
<wire x1="50.8" y1="340.36" x2="27.94" y2="340.36" width="0.1524" layer="91"/>
<junction x="50.8" y="340.36"/>
<wire x1="58.42" y1="345.44" x2="58.42" y2="340.36" width="0.1524" layer="91"/>
<junction x="58.42" y="340.36"/>
<pinref part="C01" gate="C$1" pin="-"/>
<pinref part="Q01" gate="Q$1" pin="S"/>
<wire x1="134.62" y1="347.98" x2="134.62" y2="340.36" width="0.1524" layer="91"/>
<wire x1="58.42" y1="340.36" x2="121.92" y2="340.36" width="0.1524" layer="91"/>
<pinref part="R06" gate="G$1" pin="2"/>
<wire x1="121.92" y1="340.36" x2="134.62" y2="340.36" width="0.1524" layer="91"/>
<wire x1="121.92" y1="345.44" x2="121.92" y2="340.36" width="0.1524" layer="91"/>
<junction x="121.92" y="340.36"/>
<pinref part="U1" gate="G$1" pin="NG"/>
</segment>
<segment>
<pinref part="U2" gate="P" pin="V-"/>
<wire x1="167.64" y1="360.68" x2="167.64" y2="355.6" width="0.1524" layer="91"/>
<wire x1="167.64" y1="355.6" x2="167.64" y2="342.9" width="0.1524" layer="91"/>
<wire x1="167.64" y1="355.6" x2="180.34" y2="355.6" width="0.1524" layer="91"/>
<wire x1="180.34" y1="355.6" x2="180.34" y2="363.22" width="0.1524" layer="91"/>
<junction x="167.64" y="355.6"/>
<pinref part="C02" gate="G$1" pin="2"/>
<label x="167.64" y="342.9" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="208.28" y="144.78" size="1.778" layer="95"/>
<pinref part="C81" gate="C$1" pin="-"/>
<pinref part="JP2" gate="G$1" pin="2"/>
<wire x1="248.92" y1="144.78" x2="241.3" y2="144.78" width="0.1524" layer="91"/>
<junction x="241.3" y="144.78"/>
<wire x1="241.3" y1="144.78" x2="208.28" y2="144.78" width="0.1524" layer="91"/>
<wire x1="254" y1="142.24" x2="254" y2="139.7" width="0.1524" layer="91"/>
<wire x1="254" y1="139.7" x2="248.92" y2="139.7" width="0.1524" layer="91"/>
<wire x1="248.92" y1="139.7" x2="248.92" y2="144.78" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="U2" gate="A" pin="OUT"/>
<wire x1="134.62" y1="363.22" x2="127" y2="363.22" width="0.1524" layer="91"/>
<wire x1="134.62" y1="363.22" x2="134.62" y2="358.14" width="0.1524" layer="91"/>
<pinref part="Q01" gate="Q$1" pin="G"/>
<pinref part="R07" gate="G$1" pin="2"/>
<wire x1="127" y1="373.38" x2="134.62" y2="373.38" width="0.1524" layer="91"/>
<wire x1="134.62" y1="373.38" x2="134.62" y2="363.22" width="0.1524" layer="91"/>
<junction x="134.62" y="363.22"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<wire x1="472.44" y1="165.1" x2="472.44" y2="162.56" width="0.1524" layer="91"/>
<pinref part="C61" gate="G$1" pin="2"/>
<wire x1="472.44" y1="162.56" x2="472.44" y2="157.48" width="0.1524" layer="91"/>
<wire x1="449.58" y1="162.56" x2="472.44" y2="162.56" width="0.1524" layer="91"/>
<junction x="472.44" y="162.56"/>
<pinref part="C62" gate="G$1" pin="2"/>
<wire x1="497.84" y1="162.56" x2="508" y2="162.56" width="0.1524" layer="91"/>
<wire x1="497.84" y1="162.56" x2="472.44" y2="162.56" width="0.1524" layer="91"/>
<junction x="497.84" y="162.56"/>
<pinref part="GND1" gate="1" pin="GND"/>
<pinref part="P1" gate="P$1" pin="GND"/>
<pinref part="C63" gate="C$1" pin="-"/>
</segment>
<segment>
<pinref part="C51" gate="G$1" pin="2"/>
<wire x1="459.74" y1="378.46" x2="459.74" y2="383.54" width="0.1524" layer="91"/>
<pinref part="GND3" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="GND"/>
<wire x1="487.68" y1="345.44" x2="485.14" y2="345.44" width="0.1524" layer="91"/>
<wire x1="485.14" y1="345.44" x2="485.14" y2="342.9" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="GND1"/>
<wire x1="485.14" y1="342.9" x2="487.68" y2="342.9" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="GND2"/>
<wire x1="485.14" y1="342.9" x2="485.14" y2="340.36" width="0.1524" layer="91"/>
<wire x1="485.14" y1="340.36" x2="487.68" y2="340.36" width="0.1524" layer="91"/>
<junction x="485.14" y="342.9"/>
<pinref part="IC1" gate="G$1" pin="GND3"/>
<wire x1="485.14" y1="340.36" x2="485.14" y2="337.82" width="0.1524" layer="91"/>
<wire x1="485.14" y1="337.82" x2="487.68" y2="337.82" width="0.1524" layer="91"/>
<junction x="485.14" y="340.36"/>
<wire x1="485.14" y1="337.82" x2="469.9" y2="337.82" width="0.1524" layer="91"/>
<junction x="485.14" y="337.82"/>
<pinref part="GND4" gate="1" pin="GND"/>
<pinref part="C53" gate="G$1" pin="2"/>
<wire x1="467.36" y1="355.6" x2="454.66" y2="355.6" width="0.1524" layer="91"/>
<pinref part="C54" gate="G$1" pin="2"/>
<wire x1="462.28" y1="353.06" x2="454.66" y2="353.06" width="0.1524" layer="91"/>
<wire x1="454.66" y1="353.06" x2="454.66" y2="355.6" width="0.1524" layer="91"/>
<pinref part="C55" gate="G$1" pin="2"/>
<wire x1="467.36" y1="350.52" x2="454.66" y2="350.52" width="0.1524" layer="91"/>
<wire x1="454.66" y1="350.52" x2="454.66" y2="353.06" width="0.1524" layer="91"/>
<junction x="454.66" y="353.06"/>
<pinref part="C56" gate="G$1" pin="2"/>
<wire x1="462.28" y1="347.98" x2="454.66" y2="347.98" width="0.1524" layer="91"/>
<wire x1="454.66" y1="347.98" x2="454.66" y2="350.52" width="0.1524" layer="91"/>
<junction x="454.66" y="350.52"/>
<wire x1="454.66" y1="347.98" x2="454.66" y2="337.82" width="0.1524" layer="91"/>
<wire x1="454.66" y1="337.82" x2="469.9" y2="337.82" width="0.1524" layer="91"/>
<junction x="454.66" y="347.98"/>
<junction x="469.9" y="337.82"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="AGND"/>
<wire x1="487.68" y1="363.22" x2="447.04" y2="363.22" width="0.1524" layer="91"/>
<pinref part="GND5" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="QG1" gate="G$1" pin="GND"/>
<wire x1="546.1" y1="175.26" x2="541.02" y2="175.26" width="0.1524" layer="91"/>
<wire x1="541.02" y1="175.26" x2="541.02" y2="172.72" width="0.1524" layer="91"/>
<pinref part="C71" gate="G$1" pin="1"/>
<wire x1="541.02" y1="172.72" x2="535.94" y2="172.72" width="0.1524" layer="91"/>
<wire x1="541.02" y1="172.72" x2="541.02" y2="167.64" width="0.1524" layer="91"/>
<junction x="541.02" y="172.72"/>
<pinref part="GND6" gate="1" pin="GND"/>
</segment>
<segment>
<wire x1="55.88" y1="289.56" x2="55.88" y2="287.02" width="0.1524" layer="91"/>
<pinref part="GND8" gate="1" pin="GND"/>
<pinref part="Q11" gate="Q$1" pin="S"/>
</segment>
<segment>
<wire x1="96.52" y1="289.56" x2="96.52" y2="287.02" width="0.1524" layer="91"/>
<pinref part="GND9" gate="1" pin="GND"/>
<pinref part="Q12" gate="Q$1" pin="S"/>
</segment>
<segment>
<wire x1="137.16" y1="289.56" x2="137.16" y2="287.02" width="0.1524" layer="91"/>
<pinref part="GND10" gate="1" pin="GND"/>
<pinref part="Q13" gate="Q$1" pin="S"/>
</segment>
<segment>
<wire x1="177.8" y1="289.56" x2="177.8" y2="287.02" width="0.1524" layer="91"/>
<pinref part="GND11" gate="1" pin="GND"/>
<pinref part="Q14" gate="Q$1" pin="S"/>
</segment>
<segment>
<pinref part="GND12" gate="1" pin="GND"/>
<pinref part="C52" gate="G$1" pin="2"/>
<wire x1="464.82" y1="269.24" x2="464.82" y2="271.78" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="213.36" y1="307.34" x2="220.98" y2="307.34" width="0.1524" layer="91"/>
<label x="213.36" y="307.34" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="GND@16"/>
</segment>
<segment>
<label x="213.36" y="368.3" size="1.778" layer="95"/>
<wire x1="213.36" y1="368.3" x2="226.06" y2="368.3" width="0.1524" layer="91"/>
<pinref part="A1" gate="G$1" pin="GND@3"/>
</segment>
<segment>
<wire x1="396.24" y1="370.84" x2="391.16" y2="370.84" width="0.1524" layer="91"/>
<pinref part="GND14" gate="1" pin="GND"/>
<wire x1="391.16" y1="370.84" x2="381" y2="370.84" width="0.1524" layer="91"/>
<wire x1="396.24" y1="365.76" x2="396.24" y2="370.84" width="0.1524" layer="91"/>
<pinref part="C31" gate="C$1" pin="-"/>
<wire x1="403.86" y1="370.84" x2="396.24" y2="370.84" width="0.1524" layer="91"/>
<junction x="396.24" y="370.84"/>
<wire x1="381" y1="360.68" x2="391.16" y2="360.68" width="0.1524" layer="91"/>
<wire x1="391.16" y1="360.68" x2="391.16" y2="370.84" width="0.1524" layer="91"/>
<junction x="391.16" y="370.84"/>
<wire x1="381" y1="353.06" x2="391.16" y2="353.06" width="0.1524" layer="91"/>
<wire x1="391.16" y1="353.06" x2="391.16" y2="360.68" width="0.1524" layer="91"/>
<junction x="391.16" y="360.68"/>
<pinref part="IC2" gate="A$1" pin="GND@8"/>
<pinref part="IC2" gate="A$1" pin="GND@4"/>
<pinref part="IC2" gate="A$1" pin="GND@5"/>
</segment>
<segment>
<pinref part="R52" gate="G$1" pin="1"/>
<wire x1="444.5" y1="269.24" x2="444.5" y2="261.62" width="0.1524" layer="91"/>
<pinref part="GND15" gate="1" pin="GND"/>
</segment>
<segment>
<label x="256.54" y="302.26" size="1.778" layer="95"/>
<wire x1="256.54" y1="302.26" x2="251.46" y2="302.26" width="0.1524" layer="91"/>
<wire x1="251.46" y1="302.26" x2="248.92" y2="302.26" width="0.1524" layer="91"/>
<wire x1="248.92" y1="299.72" x2="251.46" y2="299.72" width="0.1524" layer="91"/>
<wire x1="251.46" y1="299.72" x2="251.46" y2="302.26" width="0.1524" layer="91"/>
<junction x="251.46" y="302.26"/>
<pinref part="A2" gate="G$1" pin="GND@3"/>
<pinref part="A2" gate="G$1" pin="GND@4"/>
</segment>
<segment>
<wire x1="332.74" y1="327.66" x2="322.58" y2="327.66" width="0.1524" layer="91"/>
<wire x1="332.74" y1="345.44" x2="322.58" y2="345.44" width="0.1524" layer="91"/>
<wire x1="322.58" y1="345.44" x2="322.58" y2="327.66" width="0.1524" layer="91"/>
<pinref part="GND17" gate="1" pin="GND"/>
<wire x1="322.58" y1="327.66" x2="322.58" y2="322.58" width="0.1524" layer="91"/>
<junction x="322.58" y="327.66"/>
<pinref part="IC2" gate="A$1" pin="GND@2"/>
<pinref part="IC2" gate="A$1" pin="GND@3"/>
</segment>
<segment>
<wire x1="381" y1="340.36" x2="391.16" y2="340.36" width="0.1524" layer="91"/>
<wire x1="391.16" y1="335.28" x2="391.16" y2="340.36" width="0.1524" layer="91"/>
<wire x1="381" y1="335.28" x2="391.16" y2="335.28" width="0.1524" layer="91"/>
<pinref part="GND18" gate="1" pin="GND"/>
<wire x1="391.16" y1="335.28" x2="391.16" y2="322.58" width="0.1524" layer="91"/>
<junction x="391.16" y="335.28"/>
<pinref part="IC2" gate="A$1" pin="GND@6"/>
<pinref part="IC2" gate="A$1" pin="GND@7"/>
</segment>
<segment>
<pinref part="R/W" gate="G$1" pin="1"/>
<wire x1="332.74" y1="365.76" x2="322.58" y2="365.76" width="0.1524" layer="91"/>
<wire x1="314.96" y1="370.84" x2="322.58" y2="370.84" width="0.1524" layer="91"/>
<wire x1="322.58" y1="370.84" x2="322.58" y2="365.76" width="0.1524" layer="91"/>
<pinref part="GND19" gate="1" pin="GND"/>
<junction x="322.58" y="365.76"/>
<pinref part="IC2" gate="A$1" pin="GND@1"/>
</segment>
<segment>
<wire x1="213.36" y1="312.42" x2="220.98" y2="312.42" width="0.1524" layer="91"/>
<label x="213.36" y="312.42" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="GND@18"/>
</segment>
<segment>
<pinref part="C41" gate="G$1" pin="2"/>
<pinref part="GND13" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="C42" gate="G$1" pin="2"/>
<pinref part="GND20" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="GND"/>
<wire x1="309.88" y1="226.06" x2="325.12" y2="226.06" width="0.1524" layer="91"/>
<pinref part="GND21" gate="1" pin="GND"/>
</segment>
<segment>
<wire x1="104.14" y1="200.66" x2="96.52" y2="200.66" width="0.1524" layer="91"/>
<wire x1="96.52" y1="200.66" x2="96.52" y2="190.5" width="0.1524" layer="91"/>
<wire x1="96.52" y1="190.5" x2="104.14" y2="190.5" width="0.1524" layer="91"/>
<wire x1="96.52" y1="190.5" x2="81.28" y2="190.5" width="0.1524" layer="91"/>
<junction x="96.52" y="190.5"/>
<pinref part="JTAG" gate="A" pin="10"/>
<pinref part="JTAG" gate="A" pin="2"/>
<label x="81.28" y="190.5" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="50.8" y1="238.76" x2="60.96" y2="238.76" width="0.1524" layer="91"/>
<label x="60.96" y="238.76" size="1.778" layer="95"/>
<pinref part="SERVO" gate="A" pin="1"/>
</segment>
<segment>
<pinref part="EXT_PINS" gate="A" pin="2"/>
<wire x1="111.76" y1="149.86" x2="119.38" y2="149.86" width="0.1524" layer="91"/>
<label x="119.38" y="149.86" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="Q01" gate="Q$1" pin="D"/>
<wire x1="139.7" y1="347.98" x2="139.7" y2="340.36" width="0.1524" layer="91"/>
<wire x1="139.7" y1="340.36" x2="152.4" y2="340.36" width="0.1524" layer="91"/>
<label x="152.4" y="340.36" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="2"/>
<wire x1="241.3" y1="231.14" x2="254" y2="231.14" width="0.1524" layer="91"/>
<label x="254" y="231.14" size="1.778" layer="95"/>
</segment>
</net>
<net name="VCC_BAT" class="0">
<segment>
<wire x1="452.12" y1="180.34" x2="449.58" y2="180.34" width="0.1524" layer="91"/>
<wire x1="449.58" y1="180.34" x2="439.42" y2="180.34" width="0.1524" layer="91"/>
<pinref part="C61" gate="G$1" pin="1"/>
<wire x1="449.58" y1="170.18" x2="449.58" y2="180.34" width="0.1524" layer="91"/>
<junction x="449.58" y="180.34"/>
<label x="439.42" y="180.34" size="1.778" layer="95"/>
<pinref part="P1" gate="P$1" pin="VIN"/>
</segment>
<segment>
<pinref part="R51" gate="G$1" pin="2"/>
<wire x1="444.5" y1="294.64" x2="444.5" y2="297.18" width="0.1524" layer="91"/>
<label x="444.5" y="297.18" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<label x="256.54" y="307.34" size="1.778" layer="95"/>
<wire x1="248.92" y1="304.8" x2="251.46" y2="304.8" width="0.1524" layer="91"/>
<wire x1="251.46" y1="304.8" x2="251.46" y2="307.34" width="0.1524" layer="91"/>
<wire x1="251.46" y1="307.34" x2="256.54" y2="307.34" width="0.1524" layer="91"/>
<wire x1="248.92" y1="307.34" x2="251.46" y2="307.34" width="0.1524" layer="91"/>
<junction x="251.46" y="307.34"/>
<pinref part="A2" gate="G$1" pin="VIN@1"/>
<pinref part="A2" gate="G$1" pin="VIN@2"/>
</segment>
<segment>
<label x="208.28" y="147.32" size="1.778" layer="95"/>
<pinref part="C81" gate="C$1" pin="+"/>
<pinref part="JP2" gate="G$1" pin="1"/>
<wire x1="208.28" y1="147.32" x2="241.3" y2="147.32" width="0.1524" layer="91"/>
<junction x="241.3" y="147.32"/>
<wire x1="241.3" y1="147.32" x2="248.92" y2="147.32" width="0.1524" layer="91"/>
<wire x1="248.92" y1="147.32" x2="248.92" y2="152.4" width="0.1524" layer="91"/>
<wire x1="248.92" y1="152.4" x2="254" y2="152.4" width="0.1524" layer="91"/>
<wire x1="254" y1="152.4" x2="254" y2="149.86" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="27.94" y1="396.24" x2="38.1" y2="396.24" width="0.1524" layer="91"/>
<label x="27.94" y="396.24" size="1.778" layer="95"/>
<pinref part="D01" gate="D$1" pin="A1"/>
</segment>
<segment>
<wire x1="50.8" y1="241.3" x2="60.96" y2="241.3" width="0.1524" layer="91"/>
<label x="60.96" y="241.3" size="1.778" layer="95"/>
<pinref part="SERVO" gate="A" pin="2"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="R08" gate="G$1" pin="1"/>
<wire x1="86.36" y1="360.68" x2="86.36" y2="378.46" width="0.1524" layer="91"/>
<pinref part="U2" gate="A" pin="-IN"/>
<wire x1="86.36" y1="360.68" x2="111.76" y2="360.68" width="0.1524" layer="91"/>
<pinref part="U1" gate="G$1" pin="POS"/>
<junction x="86.36" y="360.68"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="AREF"/>
<wire x1="487.68" y1="368.3" x2="459.74" y2="368.3" width="0.1524" layer="91"/>
<wire x1="459.74" y1="368.3" x2="459.74" y2="370.84" width="0.1524" layer="91"/>
<pinref part="C51" gate="G$1" pin="1"/>
</segment>
</net>
<net name="XTAL1" class="0">
<segment>
<pinref part="QG1" gate="G$1" pin="OUT"/>
<wire x1="566.42" y1="180.34" x2="571.5" y2="180.34" width="0.1524" layer="91"/>
<label x="571.5" y="180.34" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="XTAL1"/>
<wire x1="487.68" y1="373.38" x2="469.9" y2="373.38" width="0.1524" layer="91"/>
<label x="469.9" y="373.38" size="1.778" layer="95"/>
</segment>
</net>
<net name="+5V" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="AVCC"/>
<wire x1="487.68" y1="365.76" x2="485.14" y2="365.76" width="0.1524" layer="91"/>
<wire x1="485.14" y1="365.76" x2="449.58" y2="365.76" width="0.1524" layer="91"/>
<wire x1="449.58" y1="365.76" x2="449.58" y2="373.38" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="VCC"/>
<wire x1="487.68" y1="355.6" x2="485.14" y2="355.6" width="0.1524" layer="91"/>
<wire x1="485.14" y1="355.6" x2="474.98" y2="355.6" width="0.1524" layer="91"/>
<wire x1="485.14" y1="365.76" x2="485.14" y2="355.6" width="0.1524" layer="91"/>
<junction x="485.14" y="365.76"/>
<junction x="485.14" y="355.6"/>
<pinref part="C53" gate="G$1" pin="1"/>
<pinref part="P+1" gate="1" pin="+5V"/>
<pinref part="IC1" gate="G$1" pin="VCC1"/>
<wire x1="487.68" y1="353.06" x2="485.14" y2="353.06" width="0.1524" layer="91"/>
<pinref part="C54" gate="G$1" pin="1"/>
<wire x1="485.14" y1="353.06" x2="469.9" y2="353.06" width="0.1524" layer="91"/>
<wire x1="485.14" y1="353.06" x2="485.14" y2="355.6" width="0.1524" layer="91"/>
<junction x="485.14" y="353.06"/>
<pinref part="IC1" gate="G$1" pin="VCC2"/>
<wire x1="487.68" y1="350.52" x2="485.14" y2="350.52" width="0.1524" layer="91"/>
<pinref part="C55" gate="G$1" pin="1"/>
<wire x1="485.14" y1="350.52" x2="474.98" y2="350.52" width="0.1524" layer="91"/>
<wire x1="485.14" y1="350.52" x2="485.14" y2="353.06" width="0.1524" layer="91"/>
<junction x="485.14" y="350.52"/>
<pinref part="IC1" gate="G$1" pin="VCC3"/>
<wire x1="487.68" y1="347.98" x2="485.14" y2="347.98" width="0.1524" layer="91"/>
<pinref part="C56" gate="G$1" pin="1"/>
<wire x1="485.14" y1="347.98" x2="469.9" y2="347.98" width="0.1524" layer="91"/>
<wire x1="485.14" y1="347.98" x2="485.14" y2="350.52" width="0.1524" layer="91"/>
<junction x="485.14" y="347.98"/>
</segment>
<segment>
<pinref part="QG1" gate="G$1" pin="E/D"/>
<wire x1="546.1" y1="177.8" x2="541.02" y2="177.8" width="0.1524" layer="91"/>
<wire x1="541.02" y1="177.8" x2="541.02" y2="180.34" width="0.1524" layer="91"/>
<pinref part="QG1" gate="G$1" pin="VCC"/>
<wire x1="546.1" y1="180.34" x2="541.02" y2="180.34" width="0.1524" layer="91"/>
<wire x1="541.02" y1="180.34" x2="535.94" y2="180.34" width="0.1524" layer="91"/>
<junction x="541.02" y="180.34"/>
<wire x1="541.02" y1="180.34" x2="541.02" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C71" gate="G$1" pin="2"/>
<pinref part="P+2" gate="1" pin="+5V"/>
</segment>
<segment>
<wire x1="495.3" y1="180.34" x2="497.84" y2="180.34" width="0.1524" layer="91"/>
<wire x1="497.84" y1="180.34" x2="508" y2="180.34" width="0.1524" layer="91"/>
<pinref part="C62" gate="G$1" pin="1"/>
<wire x1="508" y1="180.34" x2="513.08" y2="180.34" width="0.1524" layer="91"/>
<wire x1="497.84" y1="170.18" x2="497.84" y2="180.34" width="0.1524" layer="91"/>
<junction x="497.84" y="180.34"/>
<wire x1="508" y1="170.18" x2="508" y2="180.34" width="0.1524" layer="91"/>
<junction x="508" y="180.34"/>
<pinref part="P+3" gate="1" pin="+5V"/>
<pinref part="P1" gate="P$1" pin="5V"/>
<pinref part="C63" gate="C$1" pin="+"/>
</segment>
<segment>
<wire x1="213.36" y1="304.8" x2="220.98" y2="304.8" width="0.1524" layer="91"/>
<label x="213.36" y="304.8" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="VDD@15"/>
</segment>
<segment>
<label x="213.36" y="373.38" size="1.778" layer="95"/>
<wire x1="213.36" y1="373.38" x2="226.06" y2="373.38" width="0.1524" layer="91"/>
<pinref part="A1" gate="G$1" pin="VIN@1"/>
</segment>
<segment>
<pinref part="P+11" gate="1" pin="+5V"/>
<pinref part="C31" gate="C$1" pin="+"/>
<wire x1="381" y1="375.92" x2="391.16" y2="375.92" width="0.1524" layer="91"/>
<wire x1="381" y1="373.38" x2="391.16" y2="373.38" width="0.1524" layer="91"/>
<wire x1="391.16" y1="373.38" x2="391.16" y2="375.92" width="0.1524" layer="91"/>
<wire x1="391.16" y1="375.92" x2="391.16" y2="378.46" width="0.1524" layer="91"/>
<junction x="391.16" y="375.92"/>
<pinref part="IC2" gate="A$1" pin="5V0@1"/>
<pinref part="IC2" gate="A$1" pin="5V0@2"/>
<wire x1="391.16" y1="378.46" x2="396.24" y2="378.46" width="0.1524" layer="91"/>
<wire x1="396.24" y1="378.46" x2="396.24" y2="383.54" width="0.1524" layer="91"/>
<wire x1="396.24" y1="378.46" x2="403.86" y2="378.46" width="0.1524" layer="91"/>
<junction x="396.24" y="378.46"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="VCCB"/>
<pinref part="C42" gate="G$1" pin="1"/>
<wire x1="381" y1="241.3" x2="386.08" y2="241.3" width="0.1524" layer="91"/>
<wire x1="386.08" y1="241.3" x2="386.08" y2="248.92" width="0.1524" layer="91"/>
<wire x1="386.08" y1="241.3" x2="396.24" y2="241.3" width="0.1524" layer="91"/>
<junction x="386.08" y="241.3"/>
<pinref part="P+6" gate="1" pin="+5V"/>
</segment>
<segment>
<wire x1="119.38" y1="208.28" x2="93.98" y2="208.28" width="0.1524" layer="91"/>
<wire x1="104.14" y1="193.04" x2="93.98" y2="193.04" width="0.1524" layer="91"/>
<wire x1="93.98" y1="193.04" x2="81.28" y2="193.04" width="0.1524" layer="91"/>
<wire x1="93.98" y1="208.28" x2="93.98" y2="193.04" width="0.1524" layer="91"/>
<junction x="93.98" y="193.04"/>
<wire x1="111.76" y1="198.12" x2="119.38" y2="198.12" width="0.1524" layer="91"/>
<wire x1="119.38" y1="208.28" x2="119.38" y2="198.12" width="0.1524" layer="91"/>
<pinref part="JTAG" gate="A" pin="7"/>
<pinref part="JTAG" gate="A" pin="4"/>
<label x="81.28" y="193.04" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="RN1" gate="G$1" pin="1"/>
<wire x1="144.78" y1="182.88" x2="149.86" y2="182.88" width="0.1524" layer="91"/>
<label x="149.86" y="182.88" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="EXT_PINS" gate="A" pin="1"/>
<wire x1="104.14" y1="149.86" x2="88.9" y2="149.86" width="0.1524" layer="91"/>
<label x="88.9" y="149.86" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="1"/>
<wire x1="233.68" y1="231.14" x2="215.9" y2="231.14" width="0.1524" layer="91"/>
<label x="215.9" y="231.14" size="1.778" layer="95"/>
</segment>
</net>
<net name="/RESET" class="0">
<segment>
<wire x1="104.14" y1="195.58" x2="81.28" y2="195.58" width="0.1524" layer="91"/>
<label x="81.28" y="195.58" size="1.778" layer="95"/>
<pinref part="JTAG" gate="A" pin="6"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="RESET"/>
<wire x1="487.68" y1="383.54" x2="469.9" y2="383.54" width="0.1524" layer="91"/>
<label x="469.9" y="383.54" size="1.778" layer="95"/>
</segment>
</net>
<net name="TMS" class="0">
<segment>
<wire x1="111.76" y1="195.58" x2="129.54" y2="195.58" width="0.1524" layer="91"/>
<pinref part="RN1" gate="G$1" pin="3"/>
<wire x1="129.54" y1="182.88" x2="129.54" y2="195.58" width="0.1524" layer="91"/>
<junction x="129.54" y="195.58"/>
<wire x1="129.54" y1="195.58" x2="149.86" y2="195.58" width="0.1524" layer="91"/>
<label x="149.86" y="195.58" size="1.778" layer="95"/>
<pinref part="JTAG" gate="A" pin="5"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="(ADC5/TMS)PF5"/>
<wire x1="558.8" y1="264.16" x2="563.88" y2="264.16" width="0.1524" layer="91"/>
<label x="563.88" y="264.16" size="1.778" layer="95"/>
</segment>
</net>
<net name="TDO" class="0">
<segment>
<wire x1="111.76" y1="193.04" x2="124.46" y2="193.04" width="0.1524" layer="91"/>
<pinref part="RN1" gate="G$1" pin="4"/>
<wire x1="124.46" y1="193.04" x2="149.86" y2="193.04" width="0.1524" layer="91"/>
<wire x1="124.46" y1="182.88" x2="124.46" y2="193.04" width="0.1524" layer="91"/>
<junction x="124.46" y="193.04"/>
<label x="149.86" y="193.04" size="1.778" layer="95"/>
<pinref part="JTAG" gate="A" pin="3"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="(ADC6/TDO)PF6"/>
<wire x1="558.8" y1="266.7" x2="563.88" y2="266.7" width="0.1524" layer="91"/>
<label x="563.88" y="266.7" size="1.778" layer="95"/>
</segment>
</net>
<net name="TCK" class="0">
<segment>
<wire x1="111.76" y1="190.5" x2="119.38" y2="190.5" width="0.1524" layer="91"/>
<wire x1="119.38" y1="190.5" x2="149.86" y2="190.5" width="0.1524" layer="91"/>
<pinref part="RN1" gate="G$1" pin="5"/>
<wire x1="119.38" y1="182.88" x2="119.38" y2="190.5" width="0.1524" layer="91"/>
<junction x="119.38" y="190.5"/>
<label x="149.86" y="190.5" size="1.778" layer="95"/>
<pinref part="JTAG" gate="A" pin="1"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="(ADC4/TCK)PF4"/>
<wire x1="558.8" y1="261.62" x2="563.88" y2="261.62" width="0.1524" layer="91"/>
<label x="563.88" y="261.62" size="1.778" layer="95"/>
</segment>
</net>
<net name="TDI" class="0">
<segment>
<wire x1="111.76" y1="200.66" x2="134.62" y2="200.66" width="0.1524" layer="91"/>
<pinref part="RN1" gate="G$1" pin="2"/>
<wire x1="134.62" y1="182.88" x2="134.62" y2="200.66" width="0.1524" layer="91"/>
<wire x1="134.62" y1="200.66" x2="149.86" y2="200.66" width="0.1524" layer="91"/>
<junction x="134.62" y="200.66"/>
<label x="149.86" y="200.66" size="1.778" layer="95"/>
<pinref part="JTAG" gate="A" pin="9"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="(ADC7/TDI)PF7"/>
<wire x1="558.8" y1="269.24" x2="563.88" y2="269.24" width="0.1524" layer="91"/>
<label x="563.88" y="269.24" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$18" class="0">
<segment>
<pinref part="R15" gate="G$1" pin="1"/>
<wire x1="55.88" y1="299.72" x2="55.88" y2="302.26" width="0.1524" layer="91"/>
<pinref part="Q11" gate="Q$1" pin="D"/>
</segment>
</net>
<net name="LED1" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A15)PC7"/>
<wire x1="558.8" y1="337.82" x2="563.88" y2="337.82" width="0.1524" layer="91"/>
<label x="563.88" y="337.82" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="38.1" y1="292.1" x2="30.48" y2="292.1" width="0.1524" layer="91"/>
<label x="30.48" y="292.1" size="1.778" layer="95"/>
<pinref part="R11" gate="G$1" pin="1"/>
</segment>
</net>
<net name="ENB" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A14)PC6"/>
<wire x1="558.8" y1="335.28" x2="563.88" y2="335.28" width="0.1524" layer="91"/>
<label x="563.88" y="335.28" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="213.36" y1="299.72" x2="220.98" y2="299.72" width="0.1524" layer="91"/>
<label x="213.36" y="299.72" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="ENB@13"/>
</segment>
</net>
<net name="INB" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A13)PC5"/>
<wire x1="558.8" y1="332.74" x2="563.88" y2="332.74" width="0.1524" layer="91"/>
<label x="563.88" y="332.74" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="213.36" y1="302.26" x2="220.98" y2="302.26" width="0.1524" layer="91"/>
<label x="213.36" y="302.26" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="INB@14"/>
</segment>
</net>
<net name="ENA" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A12)PC4"/>
<wire x1="558.8" y1="330.2" x2="563.88" y2="330.2" width="0.1524" layer="91"/>
<label x="563.88" y="330.2" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="213.36" y1="292.1" x2="220.98" y2="292.1" width="0.1524" layer="91"/>
<label x="213.36" y="292.1" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="ENA@10"/>
</segment>
</net>
<net name="INA" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A11)PC3"/>
<wire x1="558.8" y1="327.66" x2="563.88" y2="327.66" width="0.1524" layer="91"/>
<label x="563.88" y="327.66" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="213.36" y1="289.56" x2="220.98" y2="289.56" width="0.1524" layer="91"/>
<label x="213.36" y="289.56" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="INA@9"/>
</segment>
</net>
<net name="LED2" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A10)PC2"/>
<wire x1="558.8" y1="325.12" x2="563.88" y2="325.12" width="0.1524" layer="91"/>
<label x="563.88" y="325.12" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="78.74" y1="292.1" x2="71.12" y2="292.1" width="0.1524" layer="91"/>
<label x="71.12" y="292.1" size="1.778" layer="95"/>
<pinref part="R12" gate="G$1" pin="1"/>
</segment>
</net>
<net name="LED3" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A9)PC1"/>
<wire x1="558.8" y1="322.58" x2="563.88" y2="322.58" width="0.1524" layer="91"/>
<label x="563.88" y="322.58" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="119.38" y1="292.1" x2="111.76" y2="292.1" width="0.1524" layer="91"/>
<label x="111.76" y="292.1" size="1.778" layer="95"/>
<pinref part="R13" gate="G$1" pin="1"/>
</segment>
</net>
<net name="LED4" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(A8)PC0"/>
<wire x1="558.8" y1="320.04" x2="563.88" y2="320.04" width="0.1524" layer="91"/>
<label x="563.88" y="320.04" size="1.778" layer="95"/>
</segment>
<segment>
<label x="152.4" y="292.1" size="1.778" layer="95"/>
<wire x1="160.02" y1="292.1" x2="152.4" y2="292.1" width="0.1524" layer="91"/>
<pinref part="R14" gate="G$1" pin="1"/>
</segment>
</net>
<net name="LED1_PIN" class="0">
<segment>
<pinref part="R15" gate="G$1" pin="2"/>
<wire x1="55.88" y1="312.42" x2="55.88" y2="314.96" width="0.1524" layer="91"/>
<label x="55.88" y="314.96" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="5"/>
<wire x1="233.68" y1="226.06" x2="215.9" y2="226.06" width="0.1524" layer="91"/>
<label x="215.9" y="226.06" size="1.778" layer="95"/>
</segment>
</net>
<net name="LED2_PIN" class="0">
<segment>
<pinref part="R16" gate="G$1" pin="2"/>
<wire x1="96.52" y1="312.42" x2="96.52" y2="314.96" width="0.1524" layer="91"/>
<label x="96.52" y="314.96" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="6"/>
<wire x1="241.3" y1="226.06" x2="254" y2="226.06" width="0.1524" layer="91"/>
<label x="254" y="226.06" size="1.778" layer="95"/>
</segment>
</net>
<net name="LED3_PIN" class="0">
<segment>
<pinref part="R17" gate="G$1" pin="2"/>
<wire x1="137.16" y1="312.42" x2="137.16" y2="314.96" width="0.1524" layer="91"/>
<label x="137.16" y="314.96" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="3"/>
<wire x1="233.68" y1="228.6" x2="215.9" y2="228.6" width="0.1524" layer="91"/>
<label x="215.9" y="228.6" size="1.778" layer="95"/>
</segment>
</net>
<net name="LED4_PIN" class="0">
<segment>
<pinref part="R18" gate="G$1" pin="2"/>
<wire x1="177.8" y1="312.42" x2="177.8" y2="314.96" width="0.1524" layer="91"/>
<label x="177.8" y="314.96" size="1.778" layer="95" rot="R90"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="4"/>
<wire x1="241.3" y1="228.6" x2="254" y2="228.6" width="0.1524" layer="91"/>
<label x="254" y="228.6" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$19" class="0">
<segment>
<pinref part="R16" gate="G$1" pin="1"/>
<wire x1="96.52" y1="299.72" x2="96.52" y2="302.26" width="0.1524" layer="91"/>
<pinref part="Q12" gate="Q$1" pin="D"/>
</segment>
</net>
<net name="N$26" class="0">
<segment>
<pinref part="R17" gate="G$1" pin="1"/>
<wire x1="137.16" y1="299.72" x2="137.16" y2="302.26" width="0.1524" layer="91"/>
<pinref part="Q13" gate="Q$1" pin="D"/>
</segment>
</net>
<net name="N$29" class="0">
<segment>
<pinref part="R18" gate="G$1" pin="1"/>
<wire x1="177.8" y1="299.72" x2="177.8" y2="302.26" width="0.1524" layer="91"/>
<pinref part="Q14" gate="Q$1" pin="D"/>
</segment>
</net>
<net name="N$30" class="0">
<segment>
<pinref part="R51" gate="G$1" pin="1"/>
<pinref part="R52" gate="G$1" pin="2"/>
<wire x1="444.5" y1="284.48" x2="444.5" y2="281.94" width="0.1524" layer="91"/>
<pinref part="IC1" gate="G$1" pin="PK1(ADC9/PCINT17)"/>
<wire x1="444.5" y1="281.94" x2="444.5" y2="279.4" width="0.1524" layer="91"/>
<wire x1="487.68" y1="281.94" x2="444.5" y2="281.94" width="0.1524" layer="91"/>
<junction x="444.5" y="281.94"/>
</segment>
</net>
<net name="SS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(SS/PCINT0)PB0"/>
<wire x1="558.8" y1="342.9" x2="563.88" y2="342.9" width="0.1524" layer="91"/>
<label x="563.88" y="342.9" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="B1"/>
<wire x1="381" y1="238.76" x2="393.7" y2="238.76" width="0.1524" layer="91"/>
<label x="393.7" y="238.76" size="1.778" layer="95"/>
</segment>
</net>
<net name="PWM" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PH4(OC4B)"/>
<wire x1="487.68" y1="243.84" x2="469.9" y2="243.84" width="0.1524" layer="91"/>
<label x="469.9" y="243.84" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="213.36" y1="294.64" x2="220.98" y2="294.64" width="0.1524" layer="91"/>
<label x="213.36" y="294.64" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="PWM@11"/>
</segment>
</net>
<net name="OUTA" class="0">
<segment>
<label x="256.54" y="292.1" size="1.778" layer="95"/>
<wire x1="256.54" y1="292.1" x2="251.46" y2="292.1" width="0.1524" layer="91"/>
<wire x1="251.46" y1="292.1" x2="248.92" y2="292.1" width="0.1524" layer="91"/>
<wire x1="248.92" y1="289.56" x2="251.46" y2="289.56" width="0.1524" layer="91"/>
<wire x1="251.46" y1="289.56" x2="251.46" y2="292.1" width="0.1524" layer="91"/>
<junction x="251.46" y="292.1"/>
<pinref part="A2" gate="G$1" pin="OUTA@7"/>
<pinref part="A2" gate="G$1" pin="OUTA@8"/>
</segment>
<segment>
<label x="208.28" y="139.7" size="1.778" layer="95"/>
<wire x1="208.28" y1="139.7" x2="241.3" y2="139.7" width="0.1524" layer="91"/>
<pinref part="JP2" gate="G$1" pin="4"/>
</segment>
</net>
<net name="OUTB" class="0">
<segment>
<label x="256.54" y="297.18" size="1.778" layer="95"/>
<wire x1="248.92" y1="294.64" x2="251.46" y2="294.64" width="0.1524" layer="91"/>
<wire x1="251.46" y1="294.64" x2="251.46" y2="297.18" width="0.1524" layer="91"/>
<wire x1="251.46" y1="297.18" x2="256.54" y2="297.18" width="0.1524" layer="91"/>
<wire x1="248.92" y1="297.18" x2="251.46" y2="297.18" width="0.1524" layer="91"/>
<junction x="251.46" y="297.18"/>
<pinref part="A2" gate="G$1" pin="OUTB@5"/>
<pinref part="A2" gate="G$1" pin="OUTB@6"/>
</segment>
<segment>
<label x="208.28" y="142.24" size="1.778" layer="95"/>
<wire x1="208.28" y1="142.24" x2="241.3" y2="142.24" width="0.1524" layer="91"/>
<pinref part="JP2" gate="G$1" pin="3"/>
</segment>
</net>
<net name="SCL" class="0">
<segment>
<label x="213.36" y="363.22" size="1.778" layer="95"/>
<wire x1="213.36" y1="363.22" x2="226.06" y2="363.22" width="0.1524" layer="91"/>
<pinref part="A1" gate="G$1" pin="SCL@5"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="(SCL/INT0)PD0"/>
<wire x1="558.8" y1="297.18" x2="563.88" y2="297.18" width="0.1524" layer="91"/>
<label x="563.88" y="297.18" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA" class="0">
<segment>
<label x="213.36" y="365.76" size="1.778" layer="95"/>
<wire x1="213.36" y1="365.76" x2="226.06" y2="365.76" width="0.1524" layer="91"/>
<pinref part="A1" gate="G$1" pin="SDA@4"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="(SDA/INT1)PD1"/>
<wire x1="558.8" y1="299.72" x2="563.88" y2="299.72" width="0.1524" layer="91"/>
<label x="563.88" y="299.72" size="1.778" layer="95"/>
</segment>
</net>
<net name="ERW1" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD7)PA7"/>
<wire x1="558.8" y1="383.54" x2="563.88" y2="383.54" width="0.1524" layer="91"/>
<label x="563.88" y="383.54" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="104.14" y1="147.32" x2="88.9" y2="147.32" width="0.1524" layer="91"/>
<label x="88.9" y="147.32" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="3"/>
</segment>
</net>
<net name="ERW2" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD6)PA6"/>
<wire x1="558.8" y1="381" x2="563.88" y2="381" width="0.1524" layer="91"/>
<label x="563.88" y="381" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="104.14" y1="144.78" x2="88.9" y2="144.78" width="0.1524" layer="91"/>
<label x="88.9" y="144.78" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="5"/>
</segment>
</net>
<net name="ERW3" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD5)PA5"/>
<wire x1="558.8" y1="378.46" x2="563.88" y2="378.46" width="0.1524" layer="91"/>
<label x="563.88" y="378.46" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="104.14" y1="142.24" x2="88.9" y2="142.24" width="0.1524" layer="91"/>
<label x="88.9" y="142.24" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="7"/>
</segment>
</net>
<net name="ERW4" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD4)PA4"/>
<wire x1="558.8" y1="375.92" x2="563.88" y2="375.92" width="0.1524" layer="91"/>
<label x="563.88" y="375.92" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="104.14" y1="139.7" x2="88.9" y2="139.7" width="0.1524" layer="91"/>
<label x="88.9" y="139.7" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="9"/>
</segment>
</net>
<net name="ERW5" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD3)PA3"/>
<wire x1="558.8" y1="373.38" x2="563.88" y2="373.38" width="0.1524" layer="91"/>
<label x="563.88" y="373.38" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="111.76" y1="147.32" x2="119.38" y2="147.32" width="0.1524" layer="91"/>
<label x="119.38" y="147.32" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="4"/>
</segment>
</net>
<net name="ERW6" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD2)PA2"/>
<wire x1="558.8" y1="370.84" x2="563.88" y2="370.84" width="0.1524" layer="91"/>
<label x="563.88" y="370.84" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="111.76" y1="144.78" x2="119.38" y2="144.78" width="0.1524" layer="91"/>
<label x="119.38" y="144.78" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="6"/>
</segment>
</net>
<net name="ERW7" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD1)PA1"/>
<wire x1="558.8" y1="368.3" x2="563.88" y2="368.3" width="0.1524" layer="91"/>
<label x="563.88" y="368.3" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="111.76" y1="142.24" x2="119.38" y2="142.24" width="0.1524" layer="91"/>
<label x="119.38" y="142.24" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="8"/>
</segment>
</net>
<net name="ERW8" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(AD0)PA0"/>
<wire x1="558.8" y1="365.76" x2="563.88" y2="365.76" width="0.1524" layer="91"/>
<label x="563.88" y="365.76" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="111.76" y1="139.7" x2="119.38" y2="139.7" width="0.1524" layer="91"/>
<label x="119.38" y="139.7" size="1.778" layer="95"/>
<pinref part="EXT_PINS" gate="A" pin="10"/>
</segment>
</net>
<net name="SERVO_PWM" class="0">
<segment>
<wire x1="50.8" y1="243.84" x2="60.96" y2="243.84" width="0.1524" layer="91"/>
<label x="60.96" y="243.84" size="1.778" layer="95"/>
<pinref part="SERVO" gate="A" pin="3"/>
</segment>
<segment>
<pinref part="IC1" gate="G$1" pin="(OC3C/INT5)PE5"/>
<wire x1="558.8" y1="287.02" x2="563.88" y2="287.02" width="0.1524" layer="91"/>
<label x="563.88" y="287.02" size="1.778" layer="95"/>
</segment>
</net>
<net name="SENSOR2" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PK3(ADC11/PCINT19)"/>
<wire x1="487.68" y1="287.02" x2="469.9" y2="287.02" width="0.1524" layer="91"/>
<label x="469.9" y="287.02" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="10"/>
<wire x1="241.3" y1="220.98" x2="254" y2="220.98" width="0.1524" layer="91"/>
<label x="254" y="220.98" size="1.778" layer="95"/>
</segment>
</net>
<net name="SENSOR1" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PK4(ADC12/PCINT20)"/>
<wire x1="487.68" y1="289.56" x2="469.9" y2="289.56" width="0.1524" layer="91"/>
<label x="469.9" y="289.56" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="9"/>
<wire x1="233.68" y1="220.98" x2="215.9" y2="220.98" width="0.1524" layer="91"/>
<label x="215.9" y="220.98" size="1.778" layer="95"/>
</segment>
</net>
<net name="SENSOR3" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PK2(ADC10/PCINT18)"/>
<wire x1="487.68" y1="284.48" x2="469.9" y2="284.48" width="0.1524" layer="91"/>
<label x="469.9" y="284.48" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="7"/>
<wire x1="233.68" y1="223.52" x2="215.9" y2="223.52" width="0.1524" layer="91"/>
<label x="215.9" y="223.52" size="1.778" layer="95"/>
</segment>
</net>
<net name="MOSI" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(MOSI/PCINT2)PB2"/>
<wire x1="558.8" y1="347.98" x2="563.88" y2="347.98" width="0.1524" layer="91"/>
<label x="563.88" y="347.98" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="B3"/>
<wire x1="381" y1="233.68" x2="393.7" y2="233.68" width="0.1524" layer="91"/>
<label x="393.7" y="233.68" size="1.778" layer="95"/>
</segment>
</net>
<net name="SCK" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(SCK/PCINT1)PB1"/>
<wire x1="558.8" y1="345.44" x2="563.88" y2="345.44" width="0.1524" layer="91"/>
<label x="563.88" y="345.44" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="B2"/>
<wire x1="381" y1="236.22" x2="393.7" y2="236.22" width="0.1524" layer="91"/>
<label x="393.7" y="236.22" size="1.778" layer="95"/>
</segment>
</net>
<net name="MISO" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="(MISO/PCINT3)PB3"/>
<wire x1="558.8" y1="350.52" x2="563.88" y2="350.52" width="0.1524" layer="91"/>
<label x="563.88" y="350.52" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="B4"/>
<wire x1="381" y1="231.14" x2="393.7" y2="231.14" width="0.1524" layer="91"/>
<label x="393.7" y="231.14" size="1.778" layer="95"/>
</segment>
</net>
<net name="CS" class="0">
<segment>
<pinref part="IC1" gate="G$1" pin="PK0(ADC8/PCINT16)"/>
<wire x1="487.68" y1="279.4" x2="464.82" y2="279.4" width="0.1524" layer="91"/>
<label x="469.9" y="279.4" size="1.778" layer="95"/>
<pinref part="C52" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="213.36" y1="297.18" x2="220.98" y2="297.18" width="0.1524" layer="91"/>
<label x="213.36" y="297.18" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="CS@12"/>
</segment>
</net>
<net name="N$8" class="0">
<segment>
<pinref part="R/W" gate="G$1" pin="2"/>
<pinref part="IC2" gate="A$1" pin="GPIO2/SDA1"/>
<wire x1="332.74" y1="373.38" x2="314.96" y2="373.38" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VCC_BAT_LP" class="0">
<segment>
<wire x1="86.36" y1="398.78" x2="99.06" y2="398.78" width="0.1524" layer="91"/>
<pinref part="R08" gate="G$1" pin="2"/>
<wire x1="99.06" y1="398.78" x2="144.78" y2="398.78" width="0.1524" layer="91"/>
<wire x1="86.36" y1="388.62" x2="86.36" y2="398.78" width="0.1524" layer="91"/>
<label x="144.78" y="398.78" size="1.778" layer="95"/>
<wire x1="50.8" y1="398.78" x2="50.8" y2="381" width="0.1524" layer="91"/>
<wire x1="50.8" y1="398.78" x2="86.36" y2="398.78" width="0.1524" layer="91"/>
<junction x="50.8" y="398.78"/>
<junction x="86.36" y="398.78"/>
<pinref part="R01" gate="G$1" pin="2"/>
<junction x="99.06" y="398.78"/>
<pinref part="C01" gate="C$1" pin="+"/>
<pinref part="D01" gate="D$1" pin="C1A2"/>
<wire x1="43.18" y1="398.78" x2="50.8" y2="398.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U2" gate="P" pin="V+"/>
<wire x1="167.64" y1="375.92" x2="167.64" y2="378.46" width="0.1524" layer="91"/>
<wire x1="167.64" y1="378.46" x2="167.64" y2="381" width="0.1524" layer="91"/>
<wire x1="167.64" y1="378.46" x2="180.34" y2="378.46" width="0.1524" layer="91"/>
<wire x1="180.34" y1="378.46" x2="180.34" y2="370.84" width="0.1524" layer="91"/>
<junction x="167.64" y="378.46"/>
<pinref part="C02" gate="G$1" pin="1"/>
<label x="167.64" y="381" size="1.778" layer="95" rot="R90"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="R02" gate="G$1" pin="2"/>
<pinref part="R01" gate="G$1" pin="1"/>
<wire x1="99.06" y1="386.08" x2="99.06" y2="388.62" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$7" class="0">
<segment>
<pinref part="R02" gate="G$1" pin="1"/>
<pinref part="R03" gate="G$1" pin="2"/>
<wire x1="99.06" y1="373.38" x2="99.06" y2="375.92" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="R06" gate="G$1" pin="1"/>
<pinref part="R05" gate="G$1" pin="2"/>
<wire x1="111.76" y1="345.44" x2="109.22" y2="345.44" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$12" class="0">
<segment>
<pinref part="R05" gate="G$1" pin="1"/>
<pinref part="R04" gate="G$1" pin="2"/>
<wire x1="99.06" y1="345.44" x2="99.06" y2="347.98" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$9" class="0">
<segment>
<pinref part="Q11" gate="Q$1" pin="G"/>
<wire x1="50.8" y1="292.1" x2="48.26" y2="292.1" width="0.1524" layer="91"/>
<pinref part="R11" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$10" class="0">
<segment>
<pinref part="Q12" gate="Q$1" pin="G"/>
<pinref part="R12" gate="G$1" pin="2"/>
<wire x1="91.44" y1="292.1" x2="88.9" y2="292.1" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$13" class="0">
<segment>
<pinref part="Q13" gate="Q$1" pin="G"/>
<wire x1="132.08" y1="292.1" x2="129.54" y2="292.1" width="0.1524" layer="91"/>
<pinref part="R13" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="Q14" gate="Q$1" pin="G"/>
<wire x1="172.72" y1="292.1" x2="170.18" y2="292.1" width="0.1524" layer="91"/>
<pinref part="R14" gate="G$1" pin="2"/>
</segment>
</net>
<net name="MOSI_PI" class="0">
<segment>
<label x="309.88" y="353.06" size="1.778" layer="95"/>
<pinref part="IC2" gate="A$1" pin="GPIO10/MOSI"/>
<wire x1="332.74" y1="353.06" x2="309.88" y2="353.06" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="A3"/>
<wire x1="325.12" y1="233.68" x2="304.8" y2="233.68" width="0.1524" layer="91"/>
<label x="304.8" y="233.68" size="1.778" layer="95"/>
</segment>
</net>
<net name="MISO_PI" class="0">
<segment>
<label x="309.88" y="350.52" size="1.778" layer="95"/>
<pinref part="IC2" gate="A$1" pin="GPIO9/MISO"/>
<wire x1="332.74" y1="350.52" x2="309.88" y2="350.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="A4"/>
<wire x1="325.12" y1="231.14" x2="304.8" y2="231.14" width="0.1524" layer="91"/>
<label x="304.8" y="231.14" size="1.778" layer="95"/>
</segment>
</net>
<net name="SCK_PI" class="0">
<segment>
<label x="309.88" y="347.98" size="1.778" layer="95"/>
<pinref part="IC2" gate="A$1" pin="GPIO11/SCLK"/>
<wire x1="332.74" y1="347.98" x2="309.88" y2="347.98" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="A2"/>
<wire x1="325.12" y1="236.22" x2="304.8" y2="236.22" width="0.1524" layer="91"/>
<label x="304.8" y="236.22" size="1.778" layer="95"/>
</segment>
</net>
<net name="SS_PI" class="0">
<segment>
<label x="401.32" y="347.98" size="1.778" layer="95"/>
<pinref part="IC2" gate="A$1" pin="!CE0!/GPIO8"/>
<wire x1="381" y1="347.98" x2="401.32" y2="347.98" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="A1"/>
<wire x1="325.12" y1="238.76" x2="304.8" y2="238.76" width="0.1524" layer="91"/>
<label x="304.8" y="238.76" size="1.778" layer="95"/>
</segment>
</net>
<net name="+3V3" class="0">
<segment>
<pinref part="C41" gate="G$1" pin="1"/>
<pinref part="U3" gate="A" pin="VCCA"/>
<wire x1="304.8" y1="241.3" x2="320.04" y2="241.3" width="0.1524" layer="91"/>
<wire x1="320.04" y1="241.3" x2="325.12" y2="241.3" width="0.1524" layer="91"/>
<wire x1="320.04" y1="241.3" x2="320.04" y2="248.92" width="0.1524" layer="91"/>
<junction x="320.04" y="241.3"/>
<pinref part="+3V1" gate="G$1" pin="+3V3"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="OE"/>
<wire x1="381" y1="226.06" x2="391.16" y2="226.06" width="0.1524" layer="91"/>
<pinref part="+3V3" gate="G$1" pin="+3V3"/>
</segment>
<segment>
<pinref part="IC2" gate="A$1" pin="3V3@1"/>
<wire x1="332.74" y1="375.92" x2="327.66" y2="375.92" width="0.1524" layer="91"/>
<wire x1="327.66" y1="375.92" x2="327.66" y2="383.54" width="0.1524" layer="91"/>
<pinref part="+3V2" gate="G$1" pin="+3V3"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
<errors>
<approved hash="102,1,381,375.92,5V0,+5V,,,,"/>
<approved hash="102,1,381,373.38,5V0,+5V,,,,"/>
<approved hash="114,1,119.464,363.251,U2,B,-IN,,,"/>
<approved hash="114,1,119.464,363.251,U2,B,+IN,,,"/>
<approved hash="104,1,167.64,375.92,U2P,V+,VCC_BAT_LP,,,"/>
<approved hash="104,1,167.64,360.68,U2P,V-,BAT_GND,,,"/>
<approved hash="104,1,487.68,363.22,IC1,AGND,GND,,,"/>
<approved hash="104,1,487.68,365.76,IC1,AVCC,+5V,,,"/>
<approved hash="104,1,487.68,342.9,IC1,GND1,GND,,,"/>
<approved hash="104,1,487.68,340.36,IC1,GND2,GND,,,"/>
<approved hash="104,1,487.68,337.82,IC1,GND3,GND,,,"/>
<approved hash="104,1,487.68,355.6,IC1,VCC,+5V,,,"/>
<approved hash="104,1,487.68,353.06,IC1,VCC1,+5V,,,"/>
<approved hash="104,1,487.68,350.52,IC1,VCC2,+5V,,,"/>
<approved hash="104,1,487.68,347.98,IC1,VCC3,+5V,,,"/>
<approved hash="104,1,546.1,180.34,QG1,VCC,+5V,,,"/>
<approved hash="104,1,325.12,241.3,U3,VCCA,+3V3,,,"/>
<approved hash="104,1,381,241.3,U3,VCCB,+5V,,,"/>
</errors>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports the association of 3D packages
with devices in libraries, schematics, and board files. Those 3D
packages will not be understood (or retained) with this version.
</note>
</compatibility>
</eagle>
