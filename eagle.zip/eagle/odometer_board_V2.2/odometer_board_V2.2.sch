<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.3.1">
<drawing>
<settings>
<setting alwaysvectorfont="yes"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="16" fill="1" visible="no" active="no"/>
<layer number="3" name="Route3" color="17" fill="1" visible="no" active="no"/>
<layer number="4" name="Route4" color="18" fill="1" visible="no" active="no"/>
<layer number="5" name="Route5" color="19" fill="1" visible="no" active="no"/>
<layer number="6" name="Route6" color="25" fill="1" visible="no" active="no"/>
<layer number="7" name="Route7" color="26" fill="1" visible="no" active="no"/>
<layer number="8" name="Route8" color="27" fill="1" visible="no" active="no"/>
<layer number="9" name="Route9" color="28" fill="1" visible="no" active="no"/>
<layer number="10" name="Route10" color="29" fill="1" visible="no" active="no"/>
<layer number="11" name="Route11" color="30" fill="1" visible="no" active="no"/>
<layer number="12" name="Route12" color="20" fill="1" visible="no" active="no"/>
<layer number="13" name="Route13" color="21" fill="1" visible="no" active="no"/>
<layer number="14" name="Route14" color="22" fill="1" visible="no" active="no"/>
<layer number="15" name="Route15" color="23" fill="1" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="24" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="9" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="1" fill="9" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="no" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="5" fill="1" visible="yes" active="yes"/>
<layer number="100" name="help" color="7" fill="1" visible="yes" active="yes"/>
<layer number="101" name="DOC" color="7" fill="1" visible="yes" active="yes"/>
<layer number="102" name="bot_pads" color="7" fill="1" visible="yes" active="yes"/>
<layer number="103" name="tMap" color="7" fill="1" visible="no" active="yes"/>
<layer number="104" name="S_DOKU" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="no" active="yes"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="no" active="yes"/>
<layer number="107" name="Crop" color="7" fill="1" visible="no" active="yes"/>
<layer number="108" name="tplace-old" color="10" fill="1" visible="yes" active="yes"/>
<layer number="109" name="ref-old" color="11" fill="1" visible="yes" active="yes"/>
<layer number="110" name="fp0" color="7" fill="1" visible="yes" active="yes"/>
<layer number="111" name="LPC17xx" color="7" fill="1" visible="yes" active="yes"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="113" name="IDFDebug" color="7" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="7" fill="1" visible="yes" active="yes"/>
<layer number="117" name="mPads" color="7" fill="1" visible="yes" active="yes"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="yes" active="yes"/>
<layer number="119" name="mUnrouted" color="7" fill="1" visible="yes" active="yes"/>
<layer number="120" name="mDimension" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="no" active="yes"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="129" name="Mask" color="7" fill="1" visible="yes" active="yes"/>
<layer number="130" name="mbStop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="133" name="mtFinish" color="7" fill="1" visible="yes" active="yes"/>
<layer number="134" name="mbFinish" color="7" fill="1" visible="yes" active="yes"/>
<layer number="135" name="mtGlue" color="7" fill="1" visible="yes" active="yes"/>
<layer number="136" name="mbGlue" color="7" fill="1" visible="yes" active="yes"/>
<layer number="137" name="mtTest" color="7" fill="1" visible="yes" active="yes"/>
<layer number="138" name="mbTest" color="7" fill="1" visible="yes" active="yes"/>
<layer number="139" name="mtKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="140" name="mbKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="141" name="mtRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="142" name="mbRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="143" name="mvRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="no" active="yes"/>
<layer number="145" name="mHoles" color="7" fill="1" visible="yes" active="yes"/>
<layer number="146" name="mMilling" color="7" fill="1" visible="yes" active="yes"/>
<layer number="147" name="mMeasures" color="7" fill="1" visible="yes" active="yes"/>
<layer number="148" name="mDocument" color="7" fill="1" visible="yes" active="yes"/>
<layer number="149" name="mReference" color="7" fill="1" visible="yes" active="yes"/>
<layer number="150" name="Notes" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="no" active="yes"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="153" name="FabDoc1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="154" name="FabDoc2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="155" name="FabDoc3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="191" name="mNets" color="7" fill="1" visible="yes" active="yes"/>
<layer number="192" name="mBusses" color="7" fill="1" visible="yes" active="yes"/>
<layer number="193" name="mPins" color="7" fill="1" visible="yes" active="yes"/>
<layer number="194" name="mSymbols" color="7" fill="1" visible="yes" active="yes"/>
<layer number="195" name="mNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="196" name="mValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="yes" active="yes"/>
<layer number="201" name="201bmp" color="2" fill="10" visible="yes" active="yes"/>
<layer number="202" name="202bmp" color="3" fill="10" visible="no" active="yes"/>
<layer number="203" name="203bmp" color="4" fill="10" visible="no" active="yes"/>
<layer number="204" name="204bmp" color="5" fill="10" visible="no" active="yes"/>
<layer number="205" name="205bmp" color="6" fill="10" visible="no" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="10" visible="no" active="yes"/>
<layer number="207" name="207bmp" color="8" fill="10" visible="no" active="yes"/>
<layer number="208" name="208bmp" color="9" fill="10" visible="no" active="yes"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="217" name="217bmp" color="18" fill="1" visible="no" active="no"/>
<layer number="218" name="218bmp" color="19" fill="1" visible="no" active="no"/>
<layer number="219" name="219bmp" color="20" fill="1" visible="no" active="no"/>
<layer number="220" name="220bmp" color="21" fill="1" visible="no" active="no"/>
<layer number="221" name="221bmp" color="22" fill="1" visible="no" active="no"/>
<layer number="222" name="222bmp" color="23" fill="1" visible="no" active="no"/>
<layer number="223" name="223bmp" color="24" fill="1" visible="no" active="no"/>
<layer number="224" name="224bmp" color="25" fill="1" visible="no" active="no"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="227" name="227bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="228" name="228bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="229" name="229bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="230" name="230bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="231" name="231bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="232" name="Eagle3D_PG2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="233" name="Eagle3D_PG3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="248" name="Housing" color="7" fill="1" visible="yes" active="yes"/>
<layer number="249" name="Edge" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="254" name="OrgLBR" color="7" fill="1" visible="yes" active="yes"/>
<layer number="255" name="HELP" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="embedded" urn="urn:adsk.eagle:library:10681391">
<packages>
<package name="WSL_10G" urn="urn:adsk.eagle:footprint:10681396/3" library_version="71">
<description>&lt;b&gt;CONNECTOR&lt;/b&gt;&lt;p&gt;
series 057 contact pc board low profile headers&lt;p&gt;
straight</description>
<wire x1="-1.9" y1="-3.32" x2="-1.9" y2="-4.03" width="0.2032" layer="21"/>
<wire x1="1.9" y1="-3.32" x2="1.9" y2="-4.03" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="-4.1" x2="-10.21" y2="4.1" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="-4.1" x2="10.21" y2="-4.1" width="0.2032" layer="21"/>
<wire x1="10.21" y1="-4.1" x2="10.21" y2="4.1" width="0.2032" layer="21"/>
<wire x1="10.21" y1="4.1" x2="-10.21" y2="4.1" width="0.2032" layer="21"/>
<wire x1="-9.41" y1="-3.3" x2="-9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="-9.41" y1="3.3" x2="9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="9.41" y1="3.3" x2="9.41" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="9.41" y1="-3.3" x2="1.9" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="-1.9" y1="-3.3" x2="-9.41" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="4.1" x2="-9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="-10.21" y1="-4.1" x2="-9.41" y2="-3.3" width="0.2032" layer="21"/>
<wire x1="10.21" y1="4.1" x2="9.41" y2="3.3" width="0.2032" layer="21"/>
<wire x1="9.41" y1="-3.3" x2="10.21" y2="-4.1" width="0.2032" layer="21"/>
<pad name="1" x="-5.08" y="-1.27" drill="1" shape="octagon"/>
<pad name="2" x="-5.08" y="1.27" drill="1" shape="octagon"/>
<pad name="3" x="-2.54" y="-1.27" drill="1" shape="octagon"/>
<pad name="4" x="-2.54" y="1.27" drill="1" shape="octagon"/>
<pad name="5" x="0" y="-1.27" drill="1" shape="octagon"/>
<pad name="6" x="0" y="1.27" drill="1" shape="octagon"/>
<pad name="7" x="2.54" y="-1.27" drill="1" shape="octagon"/>
<pad name="8" x="2.54" y="1.27" drill="1" shape="octagon"/>
<pad name="9" x="5.08" y="-1.27" drill="1" shape="octagon"/>
<pad name="10" x="5.08" y="1.27" drill="1" shape="octagon"/>
<text x="2.56" y="-6.88" size="1.778" layer="25">&gt;NAME</text>
<text x="-8.35" y="4.55" size="1.778" layer="27">&gt;VALUE</text>
<circle x="-6.858" y="-2.286" radius="0.254" width="0.508" layer="21"/>
</package>
<package name="C0805" urn="urn:adsk.eagle:footprint:10736670/2" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;</description>
<wire x1="-1.719" y1="0.8814" x2="1.719" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="1.719" y1="-0.8814" x2="-1.719" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="-1.719" y1="-0.8814" x2="-1.719" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<wire x1="1.719" y1="0.8814" x2="1.719" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="-0.762" y1="0.8128" x2="0.8382" y2="0.8128" width="0.0762" layer="21"/>
<wire x1="0.8382" y1="-0.8128" x2="-0.762" y2="-0.8128" width="0.0762" layer="21"/>
<smd name="1" x="-0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.95" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C0201" urn="urn:adsk.eagle:footprint:10736660/1" library_version="70">
<description>Source: http://www.avxcorp.com/docs/catalogs/cx5r.pdf</description>
<smd name="1" x="-0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<smd name="2" x="0.25" y="0" dx="0.25" dy="0.35" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.3" y1="-0.15" x2="-0.15" y2="0.15" layer="51"/>
<rectangle x1="0.15" y1="-0.15" x2="0.3" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="0.1" x2="0.15" y2="0.15" layer="51"/>
<rectangle x1="-0.15" y1="-0.15" x2="0.15" y2="-0.1" layer="51"/>
<wire x1="-0.508" y1="-0.3048" x2="-0.508" y2="0.3048" width="0.0508" layer="39"/>
<wire x1="-0.508" y1="0.3048" x2="0.508" y2="0.3048" width="0.0508" layer="39"/>
<wire x1="0.508" y1="0.3048" x2="0.508" y2="-0.3048" width="0.0508" layer="39"/>
<wire x1="0.508" y1="-0.3048" x2="-0.508" y2="-0.3048" width="0.0508" layer="39"/>
</package>
<package name="C0504" urn="urn:adsk.eagle:footprint:10736661/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.3206" y1="0.7798" x2="1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="0.7798" x2="1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="-0.7798" x2="-1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="-1.3206" y1="-0.7798" x2="-1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C0603" urn="urn:adsk.eagle:footprint:10736667/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.5238" y1="0.6274" x2="1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="0.6274" x2="1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="-0.6274" x2="-1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="-1.5238" y1="-0.6274" x2="-1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C1206" urn="urn:adsk.eagle:footprint:10736673/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.0338" x2="2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.0338" x2="-2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.0338" x2="-2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="1.0338" x2="2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1210" urn="urn:adsk.eagle:footprint:10736659/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.483" x2="2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.483" x2="-2.3206" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.483" x2="-2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.3206" y1="1.483" x2="2.3206" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="C1310" urn="urn:adsk.eagle:footprint:10736665/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.3206" y1="0.7798" x2="1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="0.7798" x2="1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="1.3206" y1="-0.7798" x2="-1.3206" y2="-0.7798" width="0.0508" layer="39"/>
<wire x1="-1.3206" y1="-0.7798" x2="-1.3206" y2="0.7798" width="0.0508" layer="39"/>
<wire x1="-0.294" y1="0.559" x2="0.294" y2="0.559" width="0.1016" layer="51"/>
<wire x1="-0.294" y1="-0.559" x2="0.294" y2="-0.559" width="0.1016" layer="51"/>
<smd name="1" x="-0.7" y="0" dx="1" dy="1.3" layer="1"/>
<smd name="2" x="0.7" y="0" dx="1" dy="1.3" layer="1"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.6604" y1="-0.6223" x2="-0.2804" y2="0.6276" layer="51"/>
<rectangle x1="0.2794" y1="-0.6223" x2="0.6594" y2="0.6276" layer="51"/>
<rectangle x1="-0.1001" y1="-0.3" x2="0.1001" y2="0.3" layer="35"/>
</package>
<package name="C1608" urn="urn:adsk.eagle:footprint:10736664/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.5238" y1="0.6274" x2="1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="0.6274" x2="1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="1.5238" y1="-0.6274" x2="-1.5238" y2="-0.6274" width="0.0508" layer="39"/>
<wire x1="-1.5238" y1="-0.6274" x2="-1.5238" y2="0.6274" width="0.0508" layer="39"/>
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.1" dy="1" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.1" dy="1" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="C1808" urn="urn:adsk.eagle:footprint:10736658/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-1.4732" y1="0.9502" x2="1.4732" y2="0.9502" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-0.9502" x2="1.4732" y2="-0.9502" width="0.1016" layer="51"/>
<wire x1="-2.8956" y1="-1.2192" x2="-2.8956" y2="1.2192" width="0.0508" layer="39"/>
<wire x1="-2.8956" y1="1.2192" x2="2.8956" y2="1.2192" width="0.0508" layer="39"/>
<wire x1="2.8956" y1="1.2192" x2="2.8956" y2="-1.2192" width="0.0508" layer="39"/>
<wire x1="2.8956" y1="-1.2192" x2="-2.8956" y2="-1.2192" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.6" dy="2.2" layer="1"/>
<text x="-2.233" y="1.827" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.233" y="-2.842" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.275" y1="-1.015" x2="-1.225" y2="1.015" layer="51"/>
<rectangle x1="1.225" y1="-1.015" x2="2.275" y2="1.015" layer="51"/>
</package>
<package name="C1812" urn="urn:adsk.eagle:footprint:10736668/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0238" y1="1.8306" x2="3.0238" y2="1.8306" width="0.0508" layer="39"/>
<wire x1="3.0238" y1="-1.8306" x2="-3.0238" y2="-1.8306" width="0.0508" layer="39"/>
<wire x1="-3.0238" y1="-1.8306" x2="-3.0238" y2="1.8306" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="3.0238" y1="1.8306" x2="3.0238" y2="-1.8306" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.3" y1="-0.4001" x2="0.3" y2="0.4001" layer="35"/>
</package>
<package name="C1825" urn="urn:adsk.eagle:footprint:10736666/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0238" y1="3.5338" x2="3.0238" y2="3.5338" width="0.0508" layer="39"/>
<wire x1="3.0238" y1="-3.5338" x2="-3.0238" y2="-3.5338" width="0.0508" layer="39"/>
<wire x1="-3.0238" y1="-3.5338" x2="-3.0238" y2="3.5338" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="3.0238" y1="3.5338" x2="3.0238" y2="-3.5338" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.7" y1="-0.7" x2="0.7" y2="0.7" layer="35"/>
</package>
<package name="C2012" urn="urn:adsk.eagle:footprint:10736669/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-1.6174" y1="0.8814" x2="1.6174" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="1.6174" y1="0.8814" x2="1.6174" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="1.6174" y1="-0.8814" x2="-1.6174" y2="-0.8814" width="0.0508" layer="39"/>
<wire x1="-1.6174" y1="-0.8814" x2="-1.6174" y2="0.8814" width="0.0508" layer="39"/>
<wire x1="-0.381" y1="0.66" x2="0.381" y2="0.66" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.66" x2="0.381" y2="-0.66" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.3" dy="1.5" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.0922" y1="-0.7239" x2="-0.3421" y2="0.7262" layer="51"/>
<rectangle x1="0.3556" y1="-0.7239" x2="1.1057" y2="0.7262" layer="51"/>
<rectangle x1="-0.1001" y1="-0.4001" x2="0.1001" y2="0.4001" layer="35"/>
</package>
<package name="C3216" urn="urn:adsk.eagle:footprint:10736676/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.0338" x2="2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.0338" x2="-2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.0338" x2="-2.3206" y2="1.0338" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="1.0338" x2="2.3206" y2="-1.0338" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-2.54" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.3" y1="-0.5001" x2="0.3" y2="0.5001" layer="35"/>
</package>
<package name="C3225" urn="urn:adsk.eagle:footprint:10736672/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-2.3206" y1="1.483" x2="2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="2.3206" y1="-1.483" x2="-2.3206" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-2.3206" y1="-1.483" x2="-2.3206" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-0.9652" y1="1.2446" x2="0.9652" y2="1.2446" width="0.1016" layer="51"/>
<wire x1="-0.9652" y1="-1.2446" x2="0.9652" y2="-1.2446" width="0.1016" layer="51"/>
<wire x1="2.3206" y1="1.483" x2="2.3206" y2="-1.483" width="0.0508" layer="39"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="2.7" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-1.2954" x2="-0.9517" y2="1.3045" layer="51"/>
<rectangle x1="0.9517" y1="-1.3045" x2="1.7018" y2="1.2954" layer="51"/>
<rectangle x1="-0.1999" y1="-0.5001" x2="0.1999" y2="0.5001" layer="35"/>
</package>
<package name="C3640" urn="urn:adsk.eagle:footprint:10736674/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<wire x1="-3.8322" y1="5.0496" x2="3.8322" y2="5.0496" width="0.1016" layer="51"/>
<wire x1="-3.8322" y1="-5.0496" x2="3.8322" y2="-5.0496" width="0.1016" layer="51"/>
<wire x1="-5.7912" y1="5.588" x2="5.7912" y2="5.588" width="0.0508" layer="39"/>
<wire x1="5.7912" y1="5.588" x2="5.7912" y2="-5.588" width="0.0508" layer="39"/>
<wire x1="5.7912" y1="-5.588" x2="-5.7912" y2="-5.588" width="0.0508" layer="39"/>
<wire x1="-5.7912" y1="-5.588" x2="-5.7912" y2="5.588" width="0.0508" layer="39"/>
<smd name="1" x="-4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<smd name="2" x="4.267" y="0" dx="2.6" dy="10.7" layer="1"/>
<text x="-4.647" y="6.465" size="1.27" layer="25">&gt;NAME</text>
<text x="-4.647" y="-7.255" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-4.57" y1="-5.1" x2="-3.05" y2="5.1" layer="51"/>
<rectangle x1="3.05" y1="-5.1" x2="4.5688" y2="5.1" layer="51"/>
</package>
<package name="C4532" urn="urn:adsk.eagle:footprint:10736671/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0746" y1="1.9322" x2="3.0746" y2="1.9322" width="0.0508" layer="39"/>
<wire x1="3.0746" y1="-1.9322" x2="-3.0746" y2="-1.9322" width="0.0508" layer="39"/>
<wire x1="-3.0746" y1="-1.9322" x2="-3.0746" y2="1.9322" width="0.0508" layer="39"/>
<wire x1="-1.4732" y1="1.6002" x2="1.4732" y2="1.6002" width="0.1016" layer="51"/>
<wire x1="-1.4478" y1="-1.6002" x2="1.4732" y2="-1.6002" width="0.1016" layer="51"/>
<wire x1="3.0746" y1="1.9322" x2="3.0746" y2="-1.9322" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="3.4" layer="1"/>
<text x="-1.905" y="2.54" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.81" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.3876" y1="-1.651" x2="-1.4376" y2="1.649" layer="51"/>
<rectangle x1="1.4478" y1="-1.651" x2="2.3978" y2="1.649" layer="51"/>
<rectangle x1="-0.4001" y1="-0.7" x2="0.4001" y2="0.7" layer="35"/>
</package>
<package name="C4564" urn="urn:adsk.eagle:footprint:10736675/1" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-3.0746" y1="3.5846" x2="3.0746" y2="3.5846" width="0.0508" layer="39"/>
<wire x1="3.0746" y1="-3.5846" x2="-3.0746" y2="-3.5846" width="0.0508" layer="39"/>
<wire x1="-3.0746" y1="-3.5846" x2="-3.0746" y2="3.5846" width="0.0508" layer="39"/>
<wire x1="-1.4986" y1="3.2766" x2="1.4732" y2="3.2766" width="0.1016" layer="51"/>
<wire x1="-1.4732" y1="-3.2766" x2="1.4986" y2="-3.2766" width="0.1016" layer="51"/>
<wire x1="3.0746" y1="3.5846" x2="3.0746" y2="-3.5846" width="0.0508" layer="39"/>
<smd name="1" x="-1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="1.9" dy="6.8" layer="1"/>
<text x="-1.905" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-5.08" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.413" y1="-3.3528" x2="-1.463" y2="3.3472" layer="51"/>
<rectangle x1="1.4478" y1="-3.3528" x2="2.3978" y2="3.3472" layer="51"/>
<rectangle x1="-0.5001" y1="-1" x2="0.5001" y2="1" layer="35"/>
</package>
<package name="C0402" urn="urn:adsk.eagle:footprint:10724855/2" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<wire x1="-0.245" y1="0.224" x2="0.245" y2="0.224" width="0.1524" layer="51"/>
<wire x1="0.245" y1="-0.224" x2="-0.245" y2="-0.224" width="0.1524" layer="51"/>
<wire x1="-1.1174" y1="0.5846" x2="1.1174" y2="0.5846" width="0.0508" layer="39"/>
<wire x1="1.1174" y1="0.5846" x2="1.1174" y2="-0.5846" width="0.0508" layer="39"/>
<wire x1="1.1174" y1="-0.5846" x2="-1.1174" y2="-0.5846" width="0.0508" layer="39"/>
<wire x1="-1.1174" y1="-0.5846" x2="-1.1174" y2="0.5846" width="0.0508" layer="39"/>
<smd name="1" x="-0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<smd name="2" x="0.65" y="0" dx="0.7" dy="0.9" layer="1"/>
<text x="-0.635" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.635" y="-1.905" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.554" y1="-0.3048" x2="-0.254" y2="0.2951" layer="51"/>
<rectangle x1="0.2588" y1="-0.3048" x2="0.5588" y2="0.2951" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
</package>
<package name="SOT23" urn="urn:adsk.eagle:footprint:15704/1" library_version="70" library_locally_modified="yes">
<description>&lt;b&gt;SOT-23&lt;/b&gt;</description>
<wire x1="1.4224" y1="0.6604" x2="1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="1.4224" y1="-0.6604" x2="-1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="-0.6604" x2="-1.4224" y2="0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="0.6604" x2="1.4224" y2="0.6604" width="0.1524" layer="51"/>
<smd name="3" x="0" y="1.1" dx="1" dy="1.4" layer="1"/>
<smd name="2" x="0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<smd name="1" x="-0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.2286" y1="0.7112" x2="0.2286" y2="1.2954" layer="51"/>
<rectangle x1="0.7112" y1="-1.2954" x2="1.1684" y2="-0.7112" layer="51"/>
<rectangle x1="-1.1684" y1="-1.2954" x2="-0.7112" y2="-0.7112" layer="51"/>
</package>
<package name="EXT_LED" urn="urn:adsk.eagle:footprint:10861657/2" library_version="75">
<smd name="-" x="-1.29" y="1.27" dx="1.5" dy="2.5" layer="1"/>
<smd name="+" x="1.29" y="-1.25" dx="1.5" dy="2.5" layer="1"/>
<text x="-2.032" y="2.794" size="0.762" layer="25">&gt;NAME</text>
<text x="0.508" y="0.254" size="0.762" layer="25">+5V</text>
</package>
</packages>
<packages3d>
<package3d name="WSL_10G" urn="urn:adsk.eagle:package:10681399/5" type="model" library_version="71">
<description>&lt;b&gt;CONNECTOR&lt;/b&gt;&lt;p&gt;
series 057 contact pc board low profile headers&lt;p&gt;
straight</description>
<packageinstances>
<packageinstance name="WSL_10G"/>
</packageinstances>
</package3d>
<package3d name="C0805" urn="urn:adsk.eagle:package:10736691/2" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;</description>
<packageinstances>
<packageinstance name="C0805"/>
</packageinstances>
</package3d>
<package3d name="C0201" urn="urn:adsk.eagle:package:10736697/1" type="model" library_version="70">
<description>Source: http://www.avxcorp.com/docs/catalogs/cx5r.pdf</description>
<packageinstances>
<packageinstance name="C0201"/>
</packageinstances>
</package3d>
<package3d name="C0504" urn="urn:adsk.eagle:package:10736700/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C0504"/>
</packageinstances>
</package3d>
<package3d name="C0603" urn="urn:adsk.eagle:package:10736694/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C0603"/>
</packageinstances>
</package3d>
<package3d name="C1206" urn="urn:adsk.eagle:package:10736689/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1206"/>
</packageinstances>
</package3d>
<package3d name="C1210" urn="urn:adsk.eagle:package:10736698/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1210"/>
</packageinstances>
</package3d>
<package3d name="C1310" urn="urn:adsk.eagle:package:10736704/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1310"/>
</packageinstances>
</package3d>
<package3d name="C1608" urn="urn:adsk.eagle:package:10736695/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1608"/>
</packageinstances>
</package3d>
<package3d name="C1808" urn="urn:adsk.eagle:package:10736706/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<packageinstances>
<packageinstance name="C1808"/>
</packageinstances>
</package3d>
<package3d name="C1812" urn="urn:adsk.eagle:package:10736703/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1812"/>
</packageinstances>
</package3d>
<package3d name="C1825" urn="urn:adsk.eagle:package:10736696/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C1825"/>
</packageinstances>
</package3d>
<package3d name="C2012" urn="urn:adsk.eagle:package:10736702/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C2012"/>
</packageinstances>
</package3d>
<package3d name="C3216" urn="urn:adsk.eagle:package:10736690/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C3216"/>
</packageinstances>
</package3d>
<package3d name="C3225" urn="urn:adsk.eagle:package:10736705/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C3225"/>
</packageinstances>
</package3d>
<package3d name="C3640" urn="urn:adsk.eagle:package:10736692/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
Source: AVX .. aphvc.pdf</description>
<packageinstances>
<packageinstance name="C3640"/>
</packageinstances>
</package3d>
<package3d name="C4532" urn="urn:adsk.eagle:package:10736693/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C4532"/>
</packageinstances>
</package3d>
<package3d name="C4564" urn="urn:adsk.eagle:package:10736688/1" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C4564"/>
</packageinstances>
</package3d>
<package3d name="C0402" urn="urn:adsk.eagle:package:10724827/4" type="model" library_version="70">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;</description>
<packageinstances>
<packageinstance name="C0402"/>
</packageinstances>
</package3d>
<package3d name="SOT23" urn="urn:adsk.eagle:package:10831617/1" type="model" library_version="71">
<description>SOT-23</description>
<packageinstances>
<packageinstance name="SOT23"/>
</packageinstances>
</package3d>
<package3d name="EXT_LED" urn="urn:adsk.eagle:package:10861658/3" type="box" library_version="75">
<packageinstances>
<packageinstance name="EXT_LED"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="PINH2X5" urn="urn:adsk.eagle:symbol:10681959/1" library_version="70">
<wire x1="-6.35" y1="-7.62" x2="8.89" y2="-7.62" width="0.4064" layer="94"/>
<wire x1="8.89" y1="-7.62" x2="8.89" y2="7.62" width="0.4064" layer="94"/>
<wire x1="8.89" y1="7.62" x2="-6.35" y2="7.62" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="7.62" x2="-6.35" y2="-7.62" width="0.4064" layer="94"/>
<text x="-6.35" y="8.255" size="1.778" layer="95">&gt;NAME</text>
<text x="-6.35" y="-10.16" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="5.08" y="5.08" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="3" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="5.08" y="2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="5" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="6" x="5.08" y="0" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="7" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="8" x="5.08" y="-2.54" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
<pin name="9" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="10" x="5.08" y="-5.08" visible="pad" length="short" direction="pas" function="dot" rot="R180"/>
</symbol>
<symbol name="C-EU" urn="urn:adsk.eagle:symbol:10724083/1" library_version="70">
<wire x1="0" y1="0" x2="0" y2="-0.508" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<text x="1.524" y="0.381" size="1.778" layer="95">&gt;NAME</text>
<text x="1.524" y="-4.699" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-2.032" y1="-2.032" x2="2.032" y2="-1.524" layer="94"/>
<rectangle x1="-2.032" y1="-1.016" x2="2.032" y2="-0.508" layer="94"/>
<pin name="1" x="0" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="SS311PT" urn="urn:adsk.eagle:symbol:10831616/1" library_version="71">
<wire x1="-7.62" y1="7.62" x2="-7.62" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="-7.62" y1="-7.62" x2="7.62" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-7.62" x2="7.62" y2="7.62" width="0.1524" layer="94"/>
<wire x1="7.62" y1="7.62" x2="-7.62" y2="7.62" width="0.1524" layer="94"/>
<pin name="VCC" x="-12.7" y="5.08" length="middle"/>
<pin name="OUT" x="-12.7" y="-5.08" length="middle"/>
<pin name="GND" x="12.7" y="0" length="middle" rot="R180"/>
<text x="0" y="10.16" size="1.778" layer="95" rot="R180">&gt;NAME</text>
<text x="-7.62" y="-10.16" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="EXT_LED" urn="urn:adsk.eagle:symbol:10861656/1" library_version="73">
<pin name="+" x="-5.08" y="0" visible="pad" length="short" direction="pas"/>
<pin name="-" x="5.08" y="0" visible="pad" length="short" direction="pas" rot="R180"/>
<text x="0" y="5.08" size="1.778" layer="95" rot="R180">&gt;NAME</text>
<rectangle x1="-2.54" y1="-1.905" x2="-0.635" y2="1.905" layer="94"/>
<rectangle x1="0.635" y1="-1.905" x2="2.54" y2="1.905" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="WSL_10G" urn="urn:adsk.eagle:component:10681403/8" prefix="JP" library_version="76">
<description>&lt;b&gt;Connector&lt;/b&gt;&lt;p&gt;
WSL 10G&lt;p&gt;
WANNENSTECKER, 10-POLIG&lt;p&gt;
BOX HEADER&lt;p&gt;
Source: &lt;a href="https://cdn-reichelt.de/documents/datenblatt/C151/BH1S-XX-L.pdf"&gt;Box Header&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="PINH2X5" x="0" y="0"/>
</gates>
<devices>
<device name="" package="WSL_10G">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10" pad="10"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8" pad="8"/>
<connect gate="G$1" pin="9" pad="9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10681399/5"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="ANGLE" value="Straight" constant="no"/>
<attribute name="DATASHEET" value="https://cdn-reichelt.de/documents/datenblatt/C151/BH1S-XX-L.pdf" constant="no"/>
<attribute name="DESCR" value="Box connector 10pin straight" constant="no"/>
<attribute name="MF" value="Amtek" constant="no"/>
<attribute name="MF_PN" value="WSL-10G" constant="no"/>
<attribute name="PACKAGE" value="Box Header" constant="no"/>
<attribute name="PITCH" value="2.54mm" constant="no"/>
<attribute name="POS" value="10" constant="no"/>
<attribute name="PURCHASE" value="https://www.reichelt.de/box-connector-10-pin-straight-wsl-10g-p22816.html?r=1" constant="no"/>
<attribute name="REICHELT_NO" value="WSL 10G" constant="no"/>
<attribute name="ROWS" value="2" constant="no"/>
<attribute name="UNIT_PRICE" value="0.1" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="C-EU" urn="urn:adsk.eagle:component:10724564/9" prefix="C" uservalue="yes" library_version="70">
<description>&lt;b&gt;Capacitor&lt;/b&gt;&lt;p&gt;
European Symbol&lt;p&gt;

&lt;p&gt;
The shape and size of surface mount devices are standardized, most manufacturers use the JEDEC standards. The size of SMD capacitors/resistors is indicated by a numerical code, such as 0603. This code contains the width and height of the package. So in the example of 0603 Imperial code, this indicates a length of 0.060″ and a width of 0.030″. This code can be given in Imperial or Metric units.&lt;br&gt;&amp;nbsp;
&lt;img src="http://www.resistorguide.com/pictures/resistor-sizes.png" alt="" title="" width="350"&gt;
&lt;/p&gt;

&lt;table class="CSSTable" style="margin: 0px auto;"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td colspan="2"&gt;Code&lt;/td&gt;
&lt;td colspan="2"&gt;Length (l)&lt;/td&gt;
&lt;td colspan="2"&gt;Width (w)&lt;/td&gt;
&lt;td colspan="2"&gt;Height (h)&lt;/td&gt;
&lt;td&gt;Power&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td bgcolor="#CBD9EC"&gt;Imperial&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;Metric&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;inch&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;mm&lt;/td&gt;
&lt;td bgcolor="#CBD9EC"&gt;Watt&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0201&lt;/td&gt;
&lt;td&gt;0603&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;0.012&lt;/td&gt;
&lt;td&gt;0.3&lt;/td&gt;
&lt;td&gt;0.01&lt;/td&gt;
&lt;td&gt;0.25&lt;/td&gt;
&lt;td&gt;1/20 (0.05)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0402&lt;/td&gt;
&lt;td&gt;1005&lt;/td&gt;
&lt;td&gt;0.04&lt;/td&gt;
&lt;td&gt;1.0&lt;/td&gt;
&lt;td&gt;0.02&lt;/td&gt;
&lt;td&gt;0.5&lt;/td&gt;
&lt;td&gt;0.014&lt;/td&gt;
&lt;td&gt;0.35&lt;/td&gt;
&lt;td&gt;1/16 (0.062)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0603&lt;/td&gt;
&lt;td&gt;1608&lt;/td&gt;
&lt;td&gt;0.06&lt;/td&gt;
&lt;td&gt;1.55&lt;/td&gt;
&lt;td&gt;0.03&lt;/td&gt;
&lt;td&gt;0.85&lt;/td&gt;
&lt;td&gt;0.018&lt;/td&gt;
&lt;td&gt;0.45&lt;/td&gt;
&lt;td&gt;1/10 (0.10)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;0805&lt;/td&gt;
&lt;td&gt;2012&lt;/td&gt;
&lt;td&gt;0.08&lt;/td&gt;
&lt;td&gt;2.0&lt;/td&gt;
&lt;td&gt;0.05&lt;/td&gt;
&lt;td&gt;1.2&lt;/td&gt;
&lt;td&gt;0.018&lt;/td&gt;
&lt;td&gt;0.45&lt;/td&gt;
&lt;td&gt;1/8 (0.125)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1206&lt;/td&gt;
&lt;td&gt;3216&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.06&lt;/td&gt;
&lt;td&gt;1.6&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1/4 (0.25)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1210&lt;/td&gt;
&lt;td&gt;3225&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.10&lt;/td&gt;
&lt;td&gt;2.5&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1/2 (0.50)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;1218&lt;/td&gt;
&lt;td&gt;3246&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.18&lt;/td&gt;
&lt;td&gt;4.6&lt;/td&gt;
&lt;td&gt;0.022&lt;/td&gt;
&lt;td&gt;0.55&lt;/td&gt;
&lt;td&gt;1&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;2010&lt;/td&gt;
&lt;td&gt;5025&lt;/td&gt;
&lt;td&gt;0.20&lt;/td&gt;
&lt;td&gt;5.0&lt;/td&gt;
&lt;td&gt;0.10&lt;/td&gt;
&lt;td&gt;2.5&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;3/4 (0.75)&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;2512&lt;/td&gt;
&lt;td&gt;6332&lt;/td&gt;
&lt;td&gt;0.25&lt;/td&gt;
&lt;td&gt;6.3&lt;/td&gt;
&lt;td&gt;0.12&lt;/td&gt;
&lt;td&gt;3.2&lt;/td&gt;
&lt;td&gt;0.024&lt;/td&gt;
&lt;td&gt;0.6&lt;/td&gt;
&lt;td&gt;1&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;

&lt;p&gt;
&lt;img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/SMT_sizes%2C_based_on_original_by_Zureks.svg/800px-SMT_sizes%2C_based_on_original_by_Zureks.svg.png" alt="" title="" width="350"&gt;
&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="C-EU" x="0" y="2.54"/>
</gates>
<devices>
<device name="C0201" package="C0201">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736697/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0504" package="C0504">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736700/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0603" package="C0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736694/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0805" package="C0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736691/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DESCR" value="SMD Capacitor" constant="no"/>
<attribute name="PACKAGE" value="C0805" constant="no"/>
<attribute name="SIZE" value="0805in" constant="no"/>
</technology>
</technologies>
</device>
<device name="C1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736689/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1210" package="C1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736698/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1310" package="C1310">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736704/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1608" package="C1608">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736695/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1808" package="C1808">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736706/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1812" package="C1812">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736703/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C1825" package="C1825">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736696/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C2012" package="C2012">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736702/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3216" package="C3216">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736690/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3225" package="C3225">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736705/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C3640" package="C3640">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736692/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C4532" package="C4532">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736693/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C4564" package="C4564">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10736688/1"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="C0402" package="C0402">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10724827/4"/>
</package3dinstances>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SS311PT" urn="urn:adsk.eagle:component:10831618/2" prefix="HE" library_version="76">
<description>&lt;b&gt;Hall Effect Sensor&lt;/b&gt;&lt;p&gt;</description>
<gates>
<gate name="G$1" symbol="SS311PT" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT23">
<connects>
<connect gate="G$1" pin="GND" pad="3"/>
<connect gate="G$1" pin="OUT" pad="2"/>
<connect gate="G$1" pin="VCC" pad="1"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10831617/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://www.mouser.de/datasheet/2/187/ProductSheet_SS311_411-1168392.pdf" constant="no"/>
<attribute name="DESCR" value="Digital Switch Latch Open Collector Hall Effect SOT-23-3" constant="no"/>
<attribute name="DIGIKEY_NO" value="480-5345-1-ND" constant="no"/>
<attribute name="MF" value="Honeywell" constant="no"/>
<attribute name="MF_PN" value="SS311PT" constant="no"/>
<attribute name="MOUSER_NO" value="785-SS311PT" constant="no"/>
<attribute name="PACKAGE" value="SOT-23-3" constant="no"/>
<attribute name="PURCHASE" value="https://www.mouser.de/ProductDetail/Honeywell/SS311PT?qs=sp0Ey2PL6%252B5pUIwW0wqZZw==" constant="no"/>
<attribute name="UNIT_PRICE" value="1.23000" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="EXT_LED" urn="urn:adsk.eagle:component:10861659/4" prefix="LED" library_version="76">
<description>&lt;b&gt;Connector&lt;/b&gt;&lt;p&gt;
External LED solder pad</description>
<gates>
<gate name="G$1" symbol="EXT_LED" x="0" y="0"/>
</gates>
<devices>
<device name="" package="EXT_LED">
<connects>
<connect gate="G$1" pin="+" pad="+"/>
<connect gate="G$1" pin="-" pad="-"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:10861658/3"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="CONRAD_NO" value="405622 - 62" constant="no"/>
<attribute name="DATASHEET" value="https://produktinfo.conrad.com/datenblaetter/400000-424999/405622-da-01-en-LED_5MM_NSDW570GS_K1__C0_P10_.pdf" constant="no"/>
<attribute name="DESCR" value="LED 5mm Radial" constant="no"/>
<attribute name="MF" value="NICHIA" constant="no"/>
<attribute name="MF_PN" value="NSDW570GS-K1" constant="no"/>
<attribute name="PACKAGE" value="LED 5mm Radial" constant="no"/>
<attribute name="PURCHASE" value="https://www.conrad.de/de/p/nichia-nsdw570gs-k1-led-bedrahtet-weiss-rund-5-mm-140-70-ma-3-4-v-405622.html" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="supply1" urn="urn:adsk.eagle:library:371">
<description>&lt;b&gt;Supply Symbols&lt;/b&gt;&lt;p&gt;
 GND, VCC, 0V, +5V, -5V, etc.&lt;p&gt;
 Please keep in mind, that these devices are necessary for the
 automatic wiring of the supply signals.&lt;p&gt;
 The pin name defined in the symbol is identical to the net which is to be wired automatically.&lt;p&gt;
 In this library the device names are the same as the pin names of the symbols, therefore the correct signal names appear next to the supply symbols in the schematic.&lt;p&gt;
 &lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
</packages>
<symbols>
<symbol name="+5V" urn="urn:adsk.eagle:symbol:26929/1" library_version="1">
<wire x1="1.27" y1="-1.905" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="-1.905" width="0.254" layer="94"/>
<text x="-2.54" y="-5.08" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="+5V" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
<symbol name="GND" urn="urn:adsk.eagle:symbol:26925/1" library_version="1">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="+5V" urn="urn:adsk.eagle:component:26963/1" prefix="P+" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="+5V" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="GND" urn="urn:adsk.eagle:component:26954/1" prefix="GND" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="C1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="C-EU" device="C0805" package3d_urn="urn:adsk.eagle:package:10736691/2" value="10uF"/>
<part name="JP1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="WSL_10G" device="" package3d_urn="urn:adsk.eagle:package:10681399/5"/>
<part name="P+1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="GND1" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="P+2" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="P+3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="P+4" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
<part name="HE1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="SS311PT" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="HE2" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="SS311PT" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="HE3" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="SS311PT" device="" package3d_urn="urn:adsk.eagle:package:10831617/1"/>
<part name="LED1" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="EXT_LED" device="" package3d_urn="urn:adsk.eagle:package:10861658/3"/>
<part name="LED2" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="EXT_LED" device="" package3d_urn="urn:adsk.eagle:package:10861658/3"/>
<part name="LED3" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="EXT_LED" device="" package3d_urn="urn:adsk.eagle:package:10861658/3"/>
<part name="LED4" library="embedded" library_urn="urn:adsk.eagle:library:10681391" deviceset="EXT_LED" device="" package3d_urn="urn:adsk.eagle:package:10861658/3"/>
<part name="P+5" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="+5V" device=""/>
</parts>
<sheets>
<sheet>
<plain>
<wire x1="-111.76" y1="76.2" x2="35.56" y2="76.2" width="0.8128" layer="199"/>
<wire x1="35.56" y1="76.2" x2="187.96" y2="76.2" width="0.8128" layer="199"/>
<wire x1="187.96" y1="76.2" x2="187.96" y2="0" width="0.8128" layer="199"/>
<wire x1="187.96" y1="0" x2="187.96" y2="-104.14" width="0.8128" layer="199"/>
<wire x1="187.96" y1="-104.14" x2="35.56" y2="-104.14" width="0.8128" layer="199"/>
<wire x1="35.56" y1="-104.14" x2="-111.76" y2="-104.14" width="0.8128" layer="199"/>
<wire x1="-111.76" y1="-104.14" x2="-111.76" y2="0" width="0.8128" layer="199"/>
<wire x1="-111.76" y1="0" x2="-111.76" y2="76.2" width="0.8128" layer="199"/>
<wire x1="35.56" y1="76.2" x2="35.56" y2="0" width="0.8128" layer="199"/>
<wire x1="35.56" y1="0" x2="35.56" y2="-104.14" width="0.8128" layer="199"/>
<wire x1="-111.76" y1="0" x2="35.56" y2="0" width="0.8128" layer="199"/>
<text x="-109.22" y="71.12" size="3.81" layer="199">Connector</text>
<text x="-109.22" y="-5.08" size="3.81" layer="199">Hall Effect Sensor</text>
<wire x1="35.56" y1="0" x2="187.96" y2="0" width="0.8128" layer="199"/>
<text x="38.1" y="71.12" size="3.81" layer="199">External LEDs</text>
</plain>
<instances>
<instance part="C1" gate="G$1" x="-53.34" y="55.88" smashed="yes" rot="R90">
<attribute name="NAME" x="-53.721" y="57.404" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="-48.641" y="57.404" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="JP1" gate="G$1" x="-53.34" y="43.18" smashed="yes">
<attribute name="VALUE" x="-59.69" y="33.02" size="1.778" layer="96"/>
<attribute name="NAME" x="-59.69" y="51.562" size="1.778" layer="95"/>
</instance>
<instance part="P+1" gate="1" x="-73.66" y="53.34" smashed="yes">
<attribute name="VALUE" x="-71.12" y="53.34" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND1" gate="1" x="-30.48" y="53.34" smashed="yes" rot="R180">
<attribute name="VALUE" x="-27.94" y="55.88" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+2" gate="1" x="-76.2" y="-30.48" smashed="yes" rot="R90">
<attribute name="VALUE" x="-76.2" y="-27.94" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+3" gate="1" x="-76.2" y="-53.34" smashed="yes" rot="R90">
<attribute name="VALUE" x="-76.2" y="-50.8" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+4" gate="1" x="-76.2" y="-76.2" smashed="yes" rot="R90">
<attribute name="VALUE" x="-76.2" y="-73.66" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="HE1" gate="G$1" x="-48.26" y="-35.56" smashed="yes">
<attribute name="NAME" x="-48.26" y="-25.4" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="-55.88" y="-45.72" size="1.778" layer="96"/>
</instance>
<instance part="HE2" gate="G$1" x="-48.26" y="-81.28" smashed="yes">
<attribute name="NAME" x="-48.26" y="-71.12" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="-55.88" y="-91.44" size="1.778" layer="96"/>
</instance>
<instance part="HE3" gate="G$1" x="-48.26" y="-58.42" smashed="yes">
<attribute name="NAME" x="-48.26" y="-48.26" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="-55.88" y="-68.58" size="1.778" layer="96"/>
</instance>
<instance part="LED1" gate="G$1" x="109.22" y="45.72" smashed="yes">
<attribute name="NAME" x="109.22" y="50.8" size="1.778" layer="95" rot="R180"/>
</instance>
<instance part="LED2" gate="G$1" x="109.22" y="38.1" smashed="yes">
<attribute name="NAME" x="109.22" y="43.18" size="1.778" layer="95" rot="R180"/>
</instance>
<instance part="LED3" gate="G$1" x="109.22" y="30.48" smashed="yes">
<attribute name="NAME" x="109.22" y="35.56" size="1.778" layer="95" rot="R180"/>
</instance>
<instance part="LED4" gate="G$1" x="109.22" y="20.32" smashed="yes">
<attribute name="NAME" x="109.22" y="25.4" size="1.778" layer="95" rot="R180"/>
</instance>
<instance part="P+5" gate="1" x="91.44" y="50.8" smashed="yes">
<attribute name="VALUE" x="93.98" y="50.8" size="1.778" layer="96" rot="R90"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="GND" class="0">
<segment>
<pinref part="C1" gate="G$1" pin="2"/>
<wire x1="-48.26" y1="55.88" x2="-40.64" y2="55.88" width="0.1524" layer="91"/>
<wire x1="-40.64" y1="55.88" x2="-40.64" y2="48.26" width="0.1524" layer="91"/>
<wire x1="-40.64" y1="48.26" x2="-48.26" y2="48.26" width="0.1524" layer="91"/>
<junction x="-40.64" y="48.26"/>
<pinref part="JP1" gate="G$1" pin="2"/>
<pinref part="GND1" gate="1" pin="GND"/>
<wire x1="-40.64" y1="48.26" x2="-30.48" y2="48.26" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="48.26" x2="-30.48" y2="50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="-35.56" y1="-58.42" x2="-30.48" y2="-58.42" width="0.1524" layer="91"/>
<label x="-30.48" y="-58.42" size="1.778" layer="95"/>
<pinref part="HE3" gate="G$1" pin="GND"/>
</segment>
<segment>
<wire x1="-35.56" y1="-35.56" x2="-30.48" y2="-35.56" width="0.1524" layer="91"/>
<label x="-30.48" y="-35.56" size="1.778" layer="95"/>
<pinref part="HE1" gate="G$1" pin="GND"/>
</segment>
<segment>
<wire x1="-35.56" y1="-81.28" x2="-30.48" y2="-81.28" width="0.1524" layer="91"/>
<label x="-30.48" y="-81.28" size="1.778" layer="95"/>
<pinref part="HE2" gate="G$1" pin="GND"/>
</segment>
</net>
<net name="SENSOR1" class="0">
<segment>
<wire x1="-60.96" y1="-40.64" x2="-73.66" y2="-40.64" width="0.1524" layer="91"/>
<label x="-73.66" y="-40.64" size="1.778" layer="95"/>
<pinref part="HE1" gate="G$1" pin="OUT"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="9"/>
<wire x1="-55.88" y1="38.1" x2="-73.66" y2="38.1" width="0.1524" layer="91"/>
<label x="-73.66" y="38.1" size="1.778" layer="95"/>
</segment>
</net>
<net name="SENSOR3" class="0">
<segment>
<wire x1="-60.96" y1="-63.5" x2="-73.66" y2="-63.5" width="0.1524" layer="91"/>
<label x="-73.66" y="-63.5" size="1.778" layer="95"/>
<pinref part="HE3" gate="G$1" pin="OUT"/>
</segment>
<segment>
<pinref part="JP1" gate="G$1" pin="7"/>
<wire x1="-55.88" y1="40.64" x2="-73.66" y2="40.64" width="0.1524" layer="91"/>
<label x="-73.66" y="40.64" size="1.778" layer="95"/>
</segment>
</net>
<net name="+5V" class="0">
<segment>
<pinref part="C1" gate="G$1" pin="1"/>
<wire x1="-55.88" y1="55.88" x2="-63.5" y2="55.88" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="55.88" x2="-63.5" y2="48.26" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="48.26" x2="-55.88" y2="48.26" width="0.1524" layer="91"/>
<junction x="-63.5" y="48.26"/>
<pinref part="JP1" gate="G$1" pin="1"/>
<pinref part="P+1" gate="1" pin="+5V"/>
<wire x1="-63.5" y1="48.26" x2="-73.66" y2="48.26" width="0.1524" layer="91"/>
<wire x1="-73.66" y1="48.26" x2="-73.66" y2="50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="-60.96" y1="-30.48" x2="-73.66" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="P+2" gate="1" pin="+5V"/>
<pinref part="HE1" gate="G$1" pin="VCC"/>
</segment>
<segment>
<wire x1="-60.96" y1="-53.34" x2="-73.66" y2="-53.34" width="0.1524" layer="91"/>
<pinref part="P+3" gate="1" pin="+5V"/>
<pinref part="HE3" gate="G$1" pin="VCC"/>
</segment>
<segment>
<wire x1="-60.96" y1="-76.2" x2="-73.66" y2="-76.2" width="0.1524" layer="91"/>
<pinref part="P+4" gate="1" pin="+5V"/>
<pinref part="HE2" gate="G$1" pin="VCC"/>
</segment>
<segment>
<pinref part="LED1" gate="G$1" pin="+"/>
<wire x1="104.14" y1="45.72" x2="91.44" y2="45.72" width="0.1524" layer="91"/>
<pinref part="P+5" gate="1" pin="+5V"/>
<wire x1="91.44" y1="45.72" x2="91.44" y2="48.26" width="0.1524" layer="91"/>
<pinref part="LED2" gate="G$1" pin="+"/>
<wire x1="104.14" y1="38.1" x2="91.44" y2="38.1" width="0.1524" layer="91"/>
<wire x1="91.44" y1="38.1" x2="91.44" y2="45.72" width="0.1524" layer="91"/>
<junction x="91.44" y="45.72"/>
<pinref part="LED3" gate="G$1" pin="+"/>
<wire x1="104.14" y1="30.48" x2="91.44" y2="30.48" width="0.1524" layer="91"/>
<wire x1="91.44" y1="30.48" x2="91.44" y2="38.1" width="0.1524" layer="91"/>
<junction x="91.44" y="38.1"/>
<pinref part="LED4" gate="G$1" pin="+"/>
<wire x1="104.14" y1="20.32" x2="91.44" y2="20.32" width="0.1524" layer="91"/>
<wire x1="91.44" y1="20.32" x2="91.44" y2="30.48" width="0.1524" layer="91"/>
<junction x="91.44" y="30.48"/>
</segment>
</net>
<net name="SENSOR2" class="0">
<segment>
<pinref part="JP1" gate="G$1" pin="10"/>
<wire x1="-48.26" y1="38.1" x2="-30.48" y2="38.1" width="0.1524" layer="91"/>
<label x="-30.48" y="38.1" size="1.778" layer="95"/>
</segment>
<segment>
<wire x1="-60.96" y1="-86.36" x2="-73.66" y2="-86.36" width="0.1524" layer="91"/>
<label x="-73.66" y="-86.36" size="1.778" layer="95"/>
<pinref part="HE2" gate="G$1" pin="OUT"/>
</segment>
</net>
<net name="LED2_PIN" class="0">
<segment>
<pinref part="JP1" gate="G$1" pin="6"/>
<wire x1="-48.26" y1="43.18" x2="-30.48" y2="43.18" width="0.1524" layer="91"/>
<label x="-30.48" y="43.18" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="LED2" gate="G$1" pin="-"/>
<wire x1="114.3" y1="38.1" x2="129.54" y2="38.1" width="0.1524" layer="91"/>
<label x="129.54" y="38.1" size="1.778" layer="95"/>
</segment>
</net>
<net name="LED4_PIN" class="0">
<segment>
<pinref part="JP1" gate="G$1" pin="4"/>
<wire x1="-48.26" y1="45.72" x2="-30.48" y2="45.72" width="0.1524" layer="91"/>
<label x="-30.48" y="45.72" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="LED4" gate="G$1" pin="-"/>
<wire x1="114.3" y1="20.32" x2="129.54" y2="20.32" width="0.1524" layer="91"/>
<label x="129.54" y="20.32" size="1.778" layer="95"/>
</segment>
</net>
<net name="LED3_PIN" class="0">
<segment>
<pinref part="JP1" gate="G$1" pin="3"/>
<wire x1="-55.88" y1="45.72" x2="-73.66" y2="45.72" width="0.1524" layer="91"/>
<label x="-73.66" y="45.72" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="LED3" gate="G$1" pin="-"/>
<wire x1="114.3" y1="30.48" x2="129.54" y2="30.48" width="0.1524" layer="91"/>
<label x="129.54" y="30.48" size="1.778" layer="95"/>
</segment>
</net>
<net name="LED1_PIN" class="0">
<segment>
<pinref part="JP1" gate="G$1" pin="5"/>
<wire x1="-55.88" y1="43.18" x2="-73.66" y2="43.18" width="0.1524" layer="91"/>
<label x="-73.66" y="43.18" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="LED1" gate="G$1" pin="-"/>
<wire x1="114.3" y1="45.72" x2="129.54" y2="45.72" width="0.1524" layer="91"/>
<label x="129.54" y="45.72" size="1.778" layer="95"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
<compatibility>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports the association of 3D packages
with devices in libraries, schematics, and board files. Those 3D
packages will not be understood (or retained) with this version.
</note>
</compatibility>
</eagle>
